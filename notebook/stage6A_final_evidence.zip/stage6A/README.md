# Stage 6A - Full Decode and Observed Pareto

Status: COMPLETED

## Environment

- Model: GPT-2 FP32, SDPA
- GPU: Tesla T4
- PyTorch: 2.10.0+cu128
- Transformers: 5.0.0
- NumPy: 2.0.2
- Codec: Adaptive FineZip v3

## Dataset

- enwik8: first 1,000,000 bytes
- GPT-2 tokens: 286,273
- All methods verified byte-exact and token-exact.

## Completed experiments

- Five fixed context configurations: 32, 64, 128, 256, 512.
- Four adaptive DP configurations:
  lambda = 1000, 5000, 12000, 40000.
- Full decode: 9/9 PASS.
- SHA-256 verification: 9/9 PASS.
- Compression ratio, BPB, encode/decode time,
  GPU memory and header overhead.

## Main results

| Method | Compressed B | Ratio | Encode s | Decode s |
|---|---:|---:|---:|---:|
| Fixed-32 | 300576 | 3.3269 | 28.56 | 838.80 |
| Fixed-64 | 271704 | 3.6805 | 28.98 | 1662.71 |
| Fixed-128 | 246976 | 4.0490 | 28.59 | 3157.68 |
| Fixed-256 | 228006 | 4.3858 | 29.05 | 6356.69 |
| Fixed-512 | 213691 | 4.6797 | 29.47 | 12950.87 |
| Adaptive-DP-1000 | 216534 | 4.6182 | 176.24 | 10103.99 |
| Adaptive-DP-5000 | 238128 | 4.1994 | 174.89 | 3939.29 |
| Adaptive-DP-12000 | 258127 | 3.8741 | 175.29 | 2104.71 |
| Adaptive-DP-40000 | 288012 | 3.4721 | 176.71 | 1020.19 |

## Findings

1. All nine configurations achieved byte-exact lossless
   compression and decompression.
2. Larger context improves compression but increases
   decoding time.
3. Adaptive context provides intermediate operating points.
4. All nine measured points are non-dominated with respect
   to BPB and observed decoding time.
5. Adaptive-DP-1000 increases compressed size by 1.33%
   compared with Fixed-512.
6. Its observed decoding time is 21.98% lower,
   but measurements belong to different Kaggle sessions.
7. Adaptive DP encoding is approximately six times slower
   than Fixed-512.
8. Adaptive superiority at matched measured decoding cost
   has not yet been established.

## Limitations

- Fixed decoding: Session01.
- Adaptive decoding: Session02.
- Cross-session timing comparisons are exploratory.
- Repeated and paired timing measurements are required.
- Pareto analysis does not include encoding time.

## Files

- results/: CSV and JSON measurements and metadata.
- plots/: six figures, each in PNG and PDF.
- code/: executed notebook history.
- artifacts/: compressed and reconstructed files.

## Next stage

Stage 7: hardware-calibrated Decode-Aware Adaptive DP.
