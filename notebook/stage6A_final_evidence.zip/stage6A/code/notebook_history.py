# Executed input 0


# Executed input 1
#Stage 6A — Cell 1: Clone source và kiểm tra GPU
get_ipython().run_line_magic('cd', '/kaggle/working')

get_ipython().system('git clone https://github.com/ThaoTo2806/FineZip28.git')
get_ipython().system('pip install -q transformers accelerate sentencepiece')
get_ipython().system('nvidia-smi')

get_ipython().system('git -C /kaggle/working/FineZip28 rev-parse HEAD')

# Executed input 2
#Stage 6A — Cell 2: Kiểm tra dữ liệu và thư viện
from pathlib import Path
import torch
import transformers
import numpy as np
import hashlib
import json

ROOT = Path("/kaggle/working/FineZip28")
INPUT = Path("/kaggle/input/datasets/thothanh28")
STAGE = Path("/kaggle/working/stage6A")

for folder in ["code", "results", "plots", "artifacts"]:
    (STAGE / folder).mkdir(parents=True, exist_ok=True)

print("=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)
print("GPU count:", torch.cuda.device_count())

print("\n=== SOURCE FILES ===")

files = [
    "update/adaptive_context_finezip_v3.py",
    "update/stage5_tools.py",
    "stage5_session_D.json",
    "adaptive_lambda1000_v3.fzac",
    "notebook/finezip_experiment2/data/enwik8",
    "notebook/finezip_experiment2/data/baseline_1mb.txt"
]

for name in files:
    p = ROOT / name
    print(f"{'OK' if p.exists() else 'MISSING'} | {name}")
    if p.exists():
        print(f"    Size: {p.stat().st_size:,} bytes")

print("\n=== DATASET SHA-256 ===")

data_path = ROOT / "notebook/finezip_experiment2/data/baseline_1mb.txt"
raw = data_path.read_bytes()

print("Original bytes:", len(raw))
print("SHA-256:", hashlib.sha256(raw).hexdigest())

print("\n=== EXISTING KAGGLE INPUT ===")

for p in sorted(INPUT.rglob("*")):
    if p.is_file() and p.suffix in [".json", ".gpz", ".txt"]:
        print(f"{p.relative_to(INPUT)} | {p.stat().st_size:,} B")

print("\n=== OUTPUT FOLDER ===")
print(STAGE)
print("CELL 2 DONE")

# Executed input 3
#Stage 6A — Cell 3: Load GPT-2 và kiểm tra tokenizer
import sys
import time
import torch
import numpy as np
from transformers import AutoTokenizer

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

print("=== LOAD TOKENIZER ===")

tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.model_max_length = 10**9

text = raw.decode("utf-8", errors="strict")

tokens = np.asarray(
    tokenizer.encode(text, add_special_tokens=False),
    dtype=np.int64
)

reconstructed = tokenizer.decode(
    tokens.tolist(),
    clean_up_tokenization_spaces=False
).encode("utf-8")

print("Original bytes:", len(raw))
print("Characters:", len(text))
print("Tokens:", len(tokens))
print("Tokenizer byte-exact:", reconstructed == raw)

assert reconstructed == raw, "Tokenizer roundtrip failed"

print("\n=== LOAD GPT-2 ===")

t0 = time.perf_counter()

lm = fz.HFLM(
    name="gpt2",
    device="cuda:0",
    max_batch_tokens=1024,
    eps=None
)

torch.cuda.synchronize()

print("Model load time:", round(time.perf_counter() - t0, 2), "s")

cfg, env = lm.describe()

print("\n=== MODEL CONFIG ===")
print(json.dumps(cfg, indent=2))

print("\n=== ENVIRONMENT ===")
print(json.dumps(env, indent=2))

print("\n=== EFFECTIVE BATCH PLAN ===")

for L in fz.CTX_SIZES:
    print(f"Context {L:3d} | Batch {lm.batch_size(L, 8)}")

print("\nGPU allocated:",
      round(torch.cuda.memory_allocated(0) / 1024**2, 2),
      "MiB")

print("\nCELL 3 DONE")

# Executed input 4
#Stage 6A — Cell 4: Kiểm thử Full Decode và SHA-256
import gc
import time
import hashlib
import json

# Tạo dữ liệu pilot 10 KB, bảo đảm UTF-8 hợp lệ
pilot_raw = raw[:10_000].decode(
    "utf-8", errors="ignore"
).encode("utf-8")

pilot_tokens = np.asarray(
    tokenizer.encode(
        pilot_raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

print("=== PILOT DATASET ===")
print("Bytes:", len(pilot_raw))
print("Tokens:", len(pilot_tokens))

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

pilot_results = []

policies = [
    ("Fixed-512", fz.FixedPolicy(512)),
    ("Adaptive-DP-1000", fz.DPPolicy(lam=1000))
]

for name, policy in policies:

    print(f"\n=== {name} ===", flush=True)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    # ENCODE
    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        pilot_tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    encode_s = time.perf_counter() - t0
    encode_peak = torch.cuda.max_memory_allocated(0) / 1024**2

    print("Compressed bytes:", len(blob))
    print("Encode time:", round(encode_s, 3), "s")

    # Lưu artifact
    (STAGE / "artifacts" / f"pilot_{name}.fzac").write_bytes(blob)

    # FULL DECODE
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded_tokens = fz.decode(blob, lm)

    torch.cuda.synchronize()

    decode_s = time.perf_counter() - t0
    decode_peak = torch.cuda.max_memory_allocated(0) / 1024**2

    decoded_raw = tokenizer.decode(
        decoded_tokens.tolist(),
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(np.array_equal(
        pilot_tokens, decoded_tokens
    ))

    byte_exact = pilot_raw == decoded_raw

    result = {
        "method": name,
        "original_bytes": len(pilot_raw),
        "tokens": len(pilot_tokens),
        "compressed_bytes": len(blob),
        "ratio": len(pilot_raw) / len(blob),
        "bpb": 8 * len(blob) / len(pilot_raw),
        "encode_seconds": encode_s,
        "decode_seconds": decode_s,
        "encode_peak_mib": encode_peak,
        "decode_peak_mib": decode_peak,
        "token_exact": token_exact,
        "byte_exact": byte_exact,
        "original_sha256": sha256_bytes(pilot_raw),
        "decoded_sha256": sha256_bytes(decoded_raw),
        "chunk_counts": {
            str(L): sum(l == L for _, l in leaves)
            for L in fz.CTX_SIZES
        }
    }

    pilot_results.append(result)

    # Checkpoint ngay sau mỗi cấu hình
    (STAGE / "results" / "pilot_results.json").write_text(
        json.dumps(pilot_results, indent=2)
    )

    print(json.dumps(result, indent=2), flush=True)

    assert token_exact and byte_exact, f"{name}: LOSSLESS FAILED"

print("\n=== CELL 4 DONE ===")

# Executed input 5
#Stage 6A — Cell 5: Encode toàn bộ cấu hình trên enwik8 1 MB
import gc
import pandas as pd
from collections import Counter

configs = [
    ("Fixed-32", lambda: fz.FixedPolicy(32)),
    ("Fixed-64", lambda: fz.FixedPolicy(64)),
    ("Fixed-128", lambda: fz.FixedPolicy(128)),
    ("Fixed-256", lambda: fz.FixedPolicy(256)),
    ("Fixed-512", lambda: fz.FixedPolicy(512)),
    ("Adaptive-DP-1000", lambda: fz.DPPolicy(lam=1000)),
    ("Adaptive-DP-5000", lambda: fz.DPPolicy(lam=5000)),
    ("Adaptive-DP-12000", lambda: fz.DPPolicy(lam=12000)),
    ("Adaptive-DP-40000", lambda: fz.DPPolicy(lam=40000))
]

result_path = STAGE / "results" / "encode_1mb.json"

encode_results = (
    json.loads(result_path.read_text())
    if result_path.exists() else []
)

for name, make_policy in configs:

    artifact_path = STAGE / "artifacts" / f"{name}_1mb.fzac"

    if (
        artifact_path.exists()
        and any(r["method"] == name for r in encode_results)
    ):
        print(f"SKIP: {name} — already completed")
        continue

    print(f"\n=== {name} ===", flush=True)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    policy = make_policy()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    encode_s = time.perf_counter() - t0
    peak_mib = torch.cuda.max_memory_allocated(0) / 1024**2

    counts = Counter(L for _, L in leaves)

    effective_L = (
        sum(L**2 for _, L in leaves)
        / sum(L for _, L in leaves)
    )

    artifact_path.write_bytes(blob)

    result = {
        "method": name,
        "original_bytes": len(raw),
        "original_sha256": sha256_bytes(raw),
        "tokens": len(tokens),
        "compressed_bytes": len(blob),
        "ratio": len(raw) / len(blob),
        "bpb": 8 * len(blob) / len(raw),
        "encode_seconds": encode_s,
        "encode_peak_mib": peak_mib,
        "effective_L": effective_L,
        "total_chunks": len(leaves),
        "chunk_counts": {
            str(L): counts.get(L, 0)
            for L in fz.CTX_SIZES
        },
        "encode_stats": dict(fz.encode.last_stats),
        "artifact_sha256": sha256_bytes(blob),
        "full_decode": "PENDING"
    }

    encode_results = [
        r for r in encode_results
        if r["method"] != name
    ]

    encode_results.append(result)

    # Lưu checkpoint sau mỗi cấu hình
    result_path.write_text(
        json.dumps(encode_results, indent=2)
    )

    pd.DataFrame(encode_results).to_csv(
        STAGE / "results" / "encode_1mb.csv",
        index=False
    )

    print("Compressed:", len(blob), "bytes")
    print("Ratio:", round(result["ratio"], 4))
    print("Encode:", round(encode_s, 2), "s")
    print("GPU peak:", round(peak_mib, 2), "MiB")
    print("Effective L:", round(effective_L, 2))
    print("Chunks:", dict(sorted(counts.items())))
    print("Artifact saved:", artifact_path.name, flush=True)

print("\n=== ENCODE SUMMARY ===")

display(pd.DataFrame(encode_results)[[
    "method",
    "compressed_bytes",
    "ratio",
    "bpb",
    "encode_seconds",
    "encode_peak_mib",
    "effective_L"
]].round(4))

print("\nCELL 5 DONE")

# Executed input 6
#Stage 6A — Cell 6: Full Decode Fixed-32
import gc
import time
import pandas as pd

def full_decode_benchmark(name):

    artifact_path = STAGE / "artifacts" / f"{name}_1mb.fzac"
    result_path = STAGE / "results" / "decode_1mb.json"

    results = (
        json.loads(result_path.read_text())
        if result_path.exists() else []
    )

    blob = artifact_path.read_bytes()

    enc = next(
        r for r in encode_results
        if r["method"] == name
    )

    assert sha256_bytes(blob) == enc["artifact_sha256"], \
        "Artifact checksum mismatch"

    print(f"=== FULL DECODE: {name} ===", flush=True)
    print("Compressed bytes:", len(blob))
    print("Original bytes:", len(raw))
    print("Effective L:", round(enc["effective_L"], 4))
    print("GPU:", torch.cuda.get_device_name(0))

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded_tokens = fz.decode(blob, lm)

    torch.cuda.synchronize()

    decode_s = time.perf_counter() - t0
    peak_mib = torch.cuda.max_memory_allocated(0) / 1024**2

    decoded_raw = tokenizer.decode(
        decoded_tokens.tolist(),
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(tokens, decoded_tokens)
    )

    byte_exact = raw == decoded_raw

    result = {
        **enc,
        "decode_seconds": decode_s,
        "decode_minutes": decode_s / 60,
        "decode_peak_mib": peak_mib,
        "decode_bytes_per_second": len(raw) / decode_s,
        "decoded_bytes": len(decoded_raw),
        "decoded_tokens": len(decoded_tokens),
        "token_exact": token_exact,
        "byte_exact": byte_exact,
        "decoded_sha256": sha256_bytes(decoded_raw),
        "full_decode": "PASS" if token_exact and byte_exact else "FAIL",
        "total_seconds": enc["encode_seconds"] + decode_s,
        "gpu_id": 0,
        "gpu_name": torch.cuda.get_device_name(0)
    }

    results = [
        r for r in results
        if r["method"] != name
    ]

    results.append(result)

    result_path.write_text(
        json.dumps(results, indent=2)
    )

    pd.DataFrame(results).to_csv(
        STAGE / "results" / "decode_1mb.csv",
        index=False
    )

    (STAGE / "artifacts" / f"{name}_decoded.txt").write_bytes(
        decoded_raw
    )

    print("\n=== DECODE RESULT ===")
    print(json.dumps(result, indent=2))

    print("\nCheckpoint saved:", result_path)
    print("STATUS:", result["full_decode"])

    assert token_exact and byte_exact, "LOSSLESS FAILED"

    return result


fixed32_result = full_decode_benchmark("Fixed-32")

print("\nCELL 6 DONE")

# Executed input 7
#Stage 6A — Cell 7: Full Decode Fixed-64
fixed64_result = full_decode_benchmark("Fixed-64")

print("\nCELL 7 DONE")

# Executed input 8
#Stage 6A — Cell 8: Full Decode Fixed-128
fixed128_result = full_decode_benchmark("Fixed-128")

print("\nCELL 8 DONE")

# Executed input 9
#Stage 6A — Cell 9: Full Decode Fixed-256
fixed256_result = full_decode_benchmark("Fixed-256")

print("\nCELL 9 DONE")

# Executed input 10
#Stage 6A — Cell 10: Full Decode Fixed-512
fixed512_result = full_decode_benchmark("Fixed-512")

print("\nCELL 10 DONE")