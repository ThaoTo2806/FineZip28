# Executed input 0


# Executed input 1
#Cell R1 — Clone source và kiểm tra môi trường
get_ipython().run_line_magic('cd', '/kaggle/working')

get_ipython().system('git clone https://github.com/ThaoTo2806/FineZip28.git')
get_ipython().system('git -C /kaggle/working/FineZip28 checkout 62f09e3105296d62c39e8d95cf8b8775e63f2677')

get_ipython().system('pip install -q transformers==5.0.0 accelerate sentencepiece')

get_ipython().system('nvidia-smi')
get_ipython().system('git -C /kaggle/working/FineZip28 rev-parse HEAD')

# Executed input 2
#Stage 6A — Cell R2: Khôi phục checkpoint và kiểm tra SHA-256
from pathlib import Path
import shutil
import json
import hashlib
import pandas as pd

ROOT = Path("/kaggle/working/FineZip28")
STAGE = Path("/kaggle/working/stage6A")

EVIDENCE = Path(
    "/kaggle/input/datasets/thothanh28/"
    "stage6a-part1-evidence/stage6A"
)

ARTIFACTS = Path(
    "/kaggle/input/datasets/thothanh28/"
    "stage6a-part1-artifacts/stage6A/artifacts"
)

assert EVIDENCE.exists(), "Missing evidence input"
assert ARTIFACTS.exists(), "Missing artifacts input"

# Khôi phục checkpoint
shutil.copytree(EVIDENCE, STAGE, dirs_exist_ok=True)

shutil.copytree(
    ARTIFACTS,
    STAGE / "artifacts",
    dirs_exist_ok=True
)

print("=== RESTORE CHECKPOINT ===")

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

encode_results = json.loads(
    (STAGE / "results/encode_1mb.json").read_text()
)

decode_results = json.loads(
    (STAGE / "results/decode_1mb.json").read_text()
)

metadata = json.loads(
    (STAGE / "results/session_part1.json").read_text()
)

assert len(encode_results) == 9
assert len(decode_results) == 5

print("\n=== VERIFY ENCODE ARTIFACTS ===")

for r in encode_results:

    name = r["method"]

    p = STAGE / "artifacts" / f"{name}_1mb.fzac"

    assert p.exists(), f"Missing: {name}"

    assert sha256_bytes(p.read_bytes()) == r["artifact_sha256"], \
        f"Checksum mismatch: {name}"

    print(f"PASS | {name:22s} | {p.stat().st_size:,} B")

print("\n=== VERIFY COMPLETED FULL DECODE ===")

for r in decode_results:

    name = r["method"]

    p = STAGE / "artifacts" / f"{name}_decoded.txt"

    assert p.exists()
    assert r["full_decode"] == "PASS"
    assert r["byte_exact"] and r["token_exact"]

    assert sha256_bytes(p.read_bytes()) == \
        metadata["original_sha256"]

    print(f"PASS | {name:22s} | SHA-256 verified")

print("\n=== COMPLETED RESULTS ===")

display(pd.DataFrame(decode_results)[[
    "method",
    "compressed_bytes",
    "ratio",
    "encode_seconds",
    "decode_seconds",
    "byte_exact",
    "full_decode"
]].round(4))

print("\n=== PENDING ===")

for name in metadata["pending"]:
    print("PENDING:", name)

print("\nEncode restored: 9/9")
print("Full decode restored: 5/9")
print("Previous session:", metadata["session_id"])
print("CHECKPOINT RESTORE: PASS")
print("CELL R2 DONE")

# Executed input 3
#Stage 6A — Cell R3: Khôi phục GPT-2 và kiểm tra tương thích
import sys
import time
import gc
import torch
import numpy as np
import transformers
from transformers import AutoTokenizer

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

SESSION_ID = "Stage6A-Session02"

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

print("=== ENVIRONMENT ===")
print("Session:", SESSION_ID)
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)
print("GPU:", torch.cuda.get_device_name(0))

# Khôi phục dữ liệu gốc
data_path = ROOT / "notebook/finezip_experiment2/data/baseline_1mb.txt"
raw = data_path.read_bytes()

assert sha256_bytes(raw) == metadata["original_sha256"]

tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.model_max_length = 10**9

tokens = np.asarray(
    tokenizer.encode(
        raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

assert len(tokens) == metadata["tokens"]

assert tokenizer.decode(
    tokens.tolist(),
    clean_up_tokenization_spaces=False
).encode("utf-8") == raw

print("\n=== DATASET ===")
print("Bytes:", len(raw))
print("Tokens:", len(tokens))
print("SHA-256: PASS")
print("Tokenizer roundtrip: PASS")

# Load model
print("\n=== LOAD GPT-2 ===")

lm = fz.HFLM(
    name="gpt2",
    device="cuda:0",
    max_batch_tokens=1024,
    eps=None
)

cfg, env = lm.describe()

print(json.dumps(cfg, indent=2))
print(json.dumps(env, indent=2))

assert cfg == metadata["model_config"], \
    "Model configuration mismatch"

print("\nEnvironment identical:", env == metadata["environment"])

# Kiểm tra tương thích header của cả 9 artifact
print("\n=== ARTIFACT COMPATIBILITY ===")

for r in encode_results:

    name = r["method"]
    blob = (
        STAGE / "artifacts" / f"{name}_1mb.fzac"
    ).read_bytes()

    header = fz._read_header(blob)

    assert header["fp"] == fz._fingerprint(lm)[0], \
        f"Fingerprint mismatch: {name}"

    print(f"PASS | {name}")

# Kiểm tra nhanh Adaptive-DP-1000
print("\n=== QUICK CHECK ===", flush=True)

blob = (
    STAGE / "artifacts/Adaptive-DP-1000_1mb.fzac"
).read_bytes()

ok = fz.quick_check(blob, lm, tokens)

assert ok, "Quick check failed"

# Lưu metadata session mới
session2 = {
    "session_id": SESSION_ID,
    "model_config": cfg,
    "environment": env,
    "transformers_version": transformers.__version__,
    "numpy_version": np.__version__,
    "original_sha256": sha256_bytes(raw),
    "artifact_compatibility": True,
    "quick_check": bool(ok)
}

(STAGE / "results/session_part2.json").write_text(
    json.dumps(session2, indent=2)
)

print("\nMODEL COMPATIBILITY: PASS")
print("CELL R3 DONE")

# Executed input 4
#Stage 6A — Cell R4: Khôi phục hàm Full Decode Benchmark
from datetime import datetime, timezone

# Bổ sung session ID cho kết quả Part 1
result_path = STAGE / "results/decode_1mb.json"

decode_results = json.loads(result_path.read_text())

for r in decode_results:
    r.setdefault("encode_session_id", "Stage6A-Session01")
    r.setdefault("decode_session_id", "Stage6A-Session01")

result_path.write_text(json.dumps(decode_results, indent=2))

pd.DataFrame(decode_results).to_csv(
    STAGE / "results/decode_1mb.csv",
    index=False
)

# Khôi phục hàm benchmark
def full_decode_benchmark(name):

    artifact_path = STAGE / "artifacts" / f"{name}_1mb.fzac"
    result_path = STAGE / "results/decode_1mb.json"

    results = json.loads(result_path.read_text())

    # Không chạy lại cấu hình đã PASS
    previous = next(
        (r for r in results
         if r["method"] == name
         and r["full_decode"] == "PASS"),
        None
    )

    if previous is not None:
        print(f"SKIP: {name} already completed")
        return previous

    blob = artifact_path.read_bytes()

    enc = next(
        r for r in encode_results
        if r["method"] == name
    )

    assert sha256_bytes(blob) == enc["artifact_sha256"]

    print(f"=== FULL DECODE: {name} ===", flush=True)
    print("Session:", SESSION_ID)
    print("Compressed bytes:", len(blob))
    print("Original bytes:", len(raw))
    print("Effective L:", round(enc["effective_L"], 4))
    print("GPU:", torch.cuda.get_device_name(0))

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    started_at = datetime.now(timezone.utc).isoformat()

    t0 = time.perf_counter()

    decoded_tokens = fz.decode(blob, lm)

    torch.cuda.synchronize()

    decode_s = time.perf_counter() - t0
    peak_mib = torch.cuda.max_memory_allocated(0) / 1024**2

    decoded_raw = tokenizer.decode(
        decoded_tokens.tolist(),
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(np.array_equal(tokens, decoded_tokens))
    byte_exact = raw == decoded_raw

    result = {
        **enc,
        "encode_session_id": "Stage6A-Session01",
        "decode_session_id": SESSION_ID,
        "started_at": started_at,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "decode_seconds": decode_s,
        "decode_minutes": decode_s / 60,
        "decode_peak_mib": peak_mib,
        "decode_bytes_per_second": len(raw) / decode_s,
        "decoded_bytes": len(decoded_raw),
        "decoded_tokens": len(decoded_tokens),
        "token_exact": token_exact,
        "byte_exact": byte_exact,
        "decoded_sha256": sha256_bytes(decoded_raw),
        "full_decode": "PASS" if token_exact and byte_exact else "FAIL",
        "total_seconds": enc["encode_seconds"] + decode_s,
        "gpu_id": 0,
        "gpu_name": torch.cuda.get_device_name(0)
    }

    results = [
        r for r in results
        if r["method"] != name
    ]

    results.append(result)

    # Lưu checkpoint
    result_path.write_text(json.dumps(results, indent=2))

    pd.DataFrame(results).to_csv(
        STAGE / "results/decode_1mb.csv",
        index=False
    )

    (STAGE / "artifacts" / f"{name}_decoded.txt").write_bytes(
        decoded_raw
    )

    print("\n=== DECODE RESULT ===")
    print(json.dumps(result, indent=2))

    print("\nCheckpoint saved:", result_path)
    print("STATUS:", result["full_decode"])

    assert token_exact and byte_exact, "LOSSLESS FAILED"

    return result

print("=== BENCHMARK FUNCTION RESTORED ===")
print("Session:", SESSION_ID)
print("Full decode completed:", len(decode_results), "/ 9")
print("Ready for Cell 11")
print("CELL R4 DONE")

# Executed input 5
#Stage 6A — Cell 11: Full Decode Adaptive-DP-1000
adaptive1000_result = full_decode_benchmark("Adaptive-DP-1000")

print("\nCELL 11 DONE")

# Executed input 6
#Stage 6A — Cell 12: Full Decode Adaptive-DP-5000
adaptive5000_result = full_decode_benchmark("Adaptive-DP-5000")

print("\nCELL 12 DONE")

# Executed input 7
#Stage 6A — Cell 13: Full Decode Adaptive-DP-12000
adaptive12000_result = full_decode_benchmark("Adaptive-DP-12000")

print("\nCELL 13 DONE")

# Executed input 8
#Stage 6A — Cell 14: Full Decode Adaptive-DP-40000
adaptive40000_result = full_decode_benchmark("Adaptive-DP-40000")

print("\nCELL 14 DONE")

# Executed input 9
#Stage 6A — Cell 15: Tổng hợp kết quả và vẽ biểu đồ
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pathlib import Path

RESULTS = STAGE / "results"
PLOTS = STAGE / "plots"

PLOTS.mkdir(exist_ok=True)

df = pd.DataFrame(
    json.loads(
        (RESULTS / "decode_1mb.json").read_text()
    )
)

assert len(df) == 9
assert df["byte_exact"].all()
assert df["token_exact"].all()
assert df["full_decode"].eq("PASS").all()

df["family"] = np.where(
    df["method"].str.startswith("Fixed"),
    "Fixed",
    "Adaptive"
)

df["decode_minutes"] = df["decode_seconds"] / 60
df["header_pct"] = df["encode_stats"].apply(
    lambda x: 100 * x["header_bytes"] / x["total_bytes"]
)

# ==================== PARETO ====================

def is_pareto_optimal(i):

    x = df.loc[i, "decode_seconds"]
    y = df.loc[i, "bpb"]

    dominated = (
        (df["decode_seconds"] <= x)
        & (df["bpb"] <= y)
        & (
            (df["decode_seconds"] < x)
            | (df["bpb"] < y)
        )
    )

    return not dominated.any()

df["observed_pareto"] = [
    is_pareto_optimal(i)
    for i in df.index
]

columns = [
    "method",
    "family",
    "compressed_bytes",
    "ratio",
    "bpb",
    "effective_L",
    "encode_seconds",
    "decode_seconds",
    "decode_minutes",
    "total_seconds",
    "encode_peak_mib",
    "decode_peak_mib",
    "header_pct",
    "byte_exact",
    "full_decode",
    "observed_pareto",
    "encode_session_id",
    "decode_session_id"
]

summary = df[columns].copy()

summary.to_csv(
    RESULTS / "stage6A_final_summary.csv",
    index=False
)

summary.to_json(
    RESULTS / "stage6A_final_summary.json",
    orient="records",
    indent=2
)

styles = {
    "Fixed": ("#2563eb", "o"),
    "Adaptive": ("#dc2626", "s")
}

def save_plot(name):

    plt.tight_layout()

    plt.savefig(
        PLOTS / f"{name}.png",
        dpi=300,
        bbox_inches="tight"
    )

    plt.savefig(
        PLOTS / f"{name}.pdf",
        bbox_inches="tight"
    )

    plt.show()
    plt.close()


# FIGURE 1: Pareto

plt.figure(figsize=(10, 6))

for family, (color, marker) in styles.items():

    g = df[df["family"] == family].sort_values(
        "decode_seconds"
    )

    plt.plot(
        g["decode_seconds"],
        g["bpb"],
        color=color,
        marker=marker,
        linestyle="--",
        label=family
    )

    for _, r in g.iterrows():

        plt.annotate(
            r["method"].replace("Adaptive-DP", "DP"),
            (r["decode_seconds"], r["bpb"]),
            xytext=(5, 7),
            textcoords="offset points",
            fontsize=8
        )

plt.xlabel("Decoding time (seconds)")
plt.ylabel("Bits per byte (BPB)")
plt.title(
    "Observed compression-decoding trade-off\n"
    "enwik8 1 MB — separate measurement sessions"
)
plt.grid(alpha=0.25)
plt.legend()

save_plot("01_observed_pareto")


# FIGURE 2: Effective context vs decode

plt.figure(figsize=(9, 6))

for family, (color, marker) in styles.items():

    g = df[df["family"] == family]

    plt.scatter(
        g["effective_L"],
        g["decode_seconds"],
        color=color,
        marker=marker,
        s=70,
        label=family
    )

plt.xlabel("Effective context length")
plt.ylabel("Decoding time (seconds)")
plt.title("Effective context vs decoding time")
plt.grid(alpha=0.25)
plt.legend()

save_plot("02_context_vs_decode")


# FIGURE 3: Encoding time

colors = [
    styles[f][0] for f in df["family"]
]

plt.figure(figsize=(11, 6))

plt.bar(
    df["method"],
    df["encode_seconds"],
    color=colors
)

plt.xticks(rotation=45, ha="right")
plt.ylabel("Encoding time (seconds)")
plt.title("Encoding overhead of Adaptive Context")
plt.grid(axis="y", alpha=0.25)

save_plot("03_encode_time")


# FIGURE 4: GPU memory

plt.figure(figsize=(11, 6))

x = np.arange(len(df))
width = 0.36

plt.bar(
    x - width/2,
    df["encode_peak_mib"],
    width,
    label="Encode"
)

plt.bar(
    x + width/2,
    df["decode_peak_mib"],
    width,
    label="Decode"
)

plt.xticks(x, df["method"], rotation=45, ha="right")
plt.ylabel("Peak allocated GPU memory (MiB)")
plt.title("GPU memory consumption")
plt.legend()
plt.grid(axis="y", alpha=0.25)

save_plot("04_gpu_memory")


# FIGURE 5: Chunk distribution

plt.figure(figsize=(11, 6))

bottom = np.zeros(len(df))

for L in [32, 64, 128, 256, 512]:

    # Tỷ lệ token đã padding thuộc mỗi context
    values = df["chunk_counts"].apply(
        lambda c:
        100 * int(c[str(L)]) * L /
        sum(int(k) * int(v) for k, v in c.items())
    ).to_numpy()

    plt.bar(
        df["method"],
        values,
        bottom=bottom,
        label=f"L={L}"
    )

    bottom += values

plt.xticks(rotation=45, ha="right")
plt.ylabel("Token allocation (%)")
plt.title("Context-length distribution")
plt.legend()

save_plot("05_chunk_distribution")


# FIGURE 6: Metadata overhead

plt.figure(figsize=(11, 6))

plt.bar(
    df["method"],
    df["header_pct"],
    color=colors
)

plt.xticks(rotation=45, ha="right")
plt.ylabel("Header overhead (%)")
plt.title("Codec v3 header overhead")

save_plot("06_header_overhead")


# ==================== FINAL SUMMARY ====================

print("=== STAGE 6A FINAL SUMMARY ===")

display(summary.round(4))

print("\n=== OBSERVED PARETO POINTS ===")

display(
    summary[summary["observed_pareto"]][[
        "method",
        "bpb",
        "decode_seconds",
        "decode_session_id"
    ]].round(4)
)

print("\n=== GENERATED FIGURES ===")

for p in sorted(PLOTS.glob("*")):
    print(p.name)

print("\nFull decode: 9/9")
print("Byte-exact: 9/9")
print("CELL 15 DONE")