# ==================== CELL 1 ====================
#Stage 8 — Cell 1: Clone source và kiểm tra Input
%cd /kaggle/working

!git clone https://github.com/ThaoTo2806/FineZip28.git

!git -C /kaggle/working/FineZip28 checkout 62f09e3105296d62c39e8d95cf8b8775e63f2677

!pip install -q transformers==5.0.0 accelerate sentencepiece

!nvidia-smi

!git -C /kaggle/working/FineZip28 rev-parse HEAD

print("\n=== STAGE 7 INPUT ===")

!find /kaggle/input -iname "frozen_rank_table.npy"
!find /kaggle/input -iname "decode_cost_config.json"
!find /kaggle/input -iname "stage7_final_summary.csv"
!find /kaggle/input -iname "stage7_notebook_history.py"

print("\nSTAGE 8 - CELL 1 DONE")

# ==================== CELL 2 ====================
#Stage 8 — Cell 2: Khôi phục thuật toán và cấu hình đã hiệu chuẩn
from pathlib import Path
import sys
import json
import shutil
import hashlib
import numpy as np
import pandas as pd
import torch
import transformers

ROOT = Path("/kaggle/working/FineZip28")
STAGE = Path("/kaggle/working/stage8")

INPUT = Path("/kaggle/input/datasets/thothanh28")

EVIDENCE7 = (
    INPUT / "stage7-final-evidence/stage7"
)

ARTIFACTS7 = (
    INPUT / "stage7-final-artifacts/stage7/artifacts"
)

for folder in [
    "code",
    "results",
    "plots",
    "artifacts",
    "datasets",
    "reference"
]:
    (STAGE / folder).mkdir(
        parents=True,
        exist_ok=True
    )

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

SESSION_ID = "Stage8-Session01"

print("=== ENVIRONMENT ===")

print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)

# ==================== RESTORE STAGE 7 ====================

required_files = [
    EVIDENCE7 / "results/decode_cost_config.json",
    EVIDENCE7 / "results/stage7_final_summary.csv",
    EVIDENCE7 / "results/stage7_pair_comparison.csv",
    EVIDENCE7 / "code/stage7_notebook_history.py",
    ARTIFACTS7 / "frozen_rank_table.npy"
]

print("\n=== REQUIRED FILES ===")

for p in required_files:

    assert p.exists(), f"Missing: {p}"

    shutil.copy2(
        p,
        STAGE / "reference" / p.name
    )

    print(
        f"PASS | {p.name} | "
        f"{p.stat().st_size:,} B"
    )

# ==================== RESTORE COST MODELS ====================

cost_config = json.loads(
    (
        STAGE / "reference/decode_cost_config.json"
    ).read_text()
)

OLD_C = cost_config["old_quadratic_c"]
NEW_C = cost_config["fitted_quadratic_c"]

measured_cost = {
    int(k): float(v)
    for k, v in cost_config[
        "measured_chunk_seconds"
    ].items()
}

batch_plan = {
    int(k): int(v)
    for k, v in cost_config["batch_plan"].items()
}

rank_table = np.load(
    STAGE / "reference/frozen_rank_table.npy"
)

RMAX = 4096
ALPHA = 0.5

assert rank_table.shape == (4097,)
assert np.isfinite(rank_table).all()

DENSE_LAMBDAS = np.concatenate([
    [0.0],
    np.geomspace(0.01, 10000, 121)
])

TARGETS = [64, 128]

print("\n=== FROZEN STAGE 7 CONFIGURATION ===")

print("Old quadratic:", OLD_C)
print("Fitted quadratic:", NEW_C)
print("Rank table shape:", rank_table.shape)
print("Lambda candidates:", len(DENSE_LAMBDAS))
print("Target contexts:", TARGETS)
print("Batch plan:", batch_plan)

print("\n=== MEASURED COST ===")

for L in fz.CTX_SIZES:
    print(
        f"L={L:3d} | "
        f"{measured_cost[L]:.6f} s/chunk"
    )

print("\n=== STAGE 7 REFERENCE ===")

reference_df = pd.read_csv(
    STAGE / "reference/stage7_pair_comparison.csv"
)

display(reference_df[[
    "context",
    "size_saving_pct",
    "mean_paired_decode_saving_pct",
    "encode_slowdown",
    "byte_exact"
]].round(4))

# ==================== SAVE PROTOCOL ====================

protocol = {
    "stage": 8,
    "session_id": SESSION_ID,
    "source": "Frozen Stage 7 BC-DP",
    "contexts": list(fz.CTX_SIZES),
    "targets": TARGETS,
    "objectives": ["NLL", "Rank"],
    "time_models": ["Fitted", "Measured"],
    "lambda_candidates": len(DENSE_LAMBDAS),
    "rank_proxy_ref": 128,
    "rank_proxy_rmax": RMAX,
    "rank_proxy_alpha": ALPHA,
    "rank_table_sha256": hashlib.sha256(
        (
            STAGE / "reference/frozen_rank_table.npy"
        ).read_bytes()
    ).hexdigest(),
    "batch_plan": batch_plan,
    "retune_on_test": False
}

(STAGE / "results/protocol.json").write_text(
    json.dumps(protocol, indent=2)
)

print("\nFROZEN CONFIGURATION: PASS")
print("CELL 2 DONE")

# ==================== CELL 3 ====================
#Stage 8 — Cell 3: Chuẩn bị 6 dataset benchmark
import requests
import platform
import sysconfig
import hashlib
import json
import numpy as np
import pandas as pd
from pathlib import Path

DATA_DIR = STAGE / "datasets"
DATA_DIR.mkdir(exist_ok=True)

TARGET_BYTES = 100_000

datasets = {}
dataset_manifest = []

# ==================== HELPER FUNCTIONS ====================

def download_bytes(url):

    response = requests.get(
        url,
        timeout=120
    )

    response.raise_for_status()

    return response.content


def utf8_slice(data, size=TARGET_BYTES):

    block = data[:size]

    # Chỉ xử lý biên UTF-8 bị cắt,
    # không bỏ ký tự lỗi trong phần nội dung.

    for trim_start in range(4):

        for trim_end in range(4):

            candidate = block[
                trim_start:
                len(block) - trim_end
            ]

            try:
                candidate.decode("utf-8", errors="strict")
                return candidate
            except UnicodeDecodeError:
                continue

    raise ValueError("Invalid UTF-8 data")


def register_dataset(name, data, source, category,
                     independent=True):

    assert len(data) >= TARGET_BYTES, (
        f"{name}: insufficient data ({len(data)} B)"
    )

    prepared = utf8_slice(data)

    path = DATA_DIR / f"{name}.txt"

    path.write_bytes(prepared)

    datasets[name] = prepared

    record = {
        "dataset": name,
        "category": category,
        "source": source,
        "source_bytes": len(data),
        "source_sha256": hashlib.sha256(
            data
        ).hexdigest(),
        "bytes": len(prepared),
        "sha256": hashlib.sha256(
            prepared
        ).hexdigest(),
        "independent_corpus": independent,
        "path": str(path)
    }

    dataset_manifest.append(record)

    print(
        f"PASS | {name:15s} | "
        f"{len(prepared):,} bytes",
        flush=True
    )


# ==================== 1. ENWIK8 NEW ====================

print("=== PREPARE DATASETS ===\n")

enwik8_path = (
    ROOT
    / "notebook/finezip_experiment2/data/enwik8"
)

with enwik8_path.open("rb") as f:

    f.seek(5_000_000)

    enwik8_raw = f.read(TARGET_BYTES + 4)

register_dataset(
    name="enwik8_new",
    data=enwik8_raw,
    source="enwik8, byte offset 5000000",
    category="Wikipedia"
)


# ==================== 2. ENGLISH TEXT ====================

english_url = (
    "https://www.gutenberg.org/files/"
    "1342/1342-0.txt"
)

english_raw = download_bytes(english_url)

register_dataset(
    name="english",
    data=english_raw,
    source=english_url,
    category="English literature"
)


# ==================== 3. PYTHON SOURCE ====================

stdlib = Path(
    sysconfig.get_path("stdlib")
)

python_files = [
    "argparse.py",
    "ast.py",
    "tokenize.py",
    "pathlib.py",
    "inspect.py",
    "functools.py"
]

python_parts = []
python_sources = []

for name in python_files:

    path = stdlib / name

    if path.is_file():

        python_parts.append(
            path.read_bytes()
        )

        python_sources.append(name)

python_raw = b"\n\n".join(
    python_parts
)

register_dataset(
    name="python_code",
    data=python_raw,
    source={
        "python_version": platform.python_version(),
        "stdlib_files": python_sources
    },
    category="Source code"
)


# ==================== 4. CSV DATASET ====================

csv_url = (
    "https://raw.githubusercontent.com/"
    "mwaskom/seaborn-data/master/diamonds.csv"
)

csv_raw = download_bytes(csv_url)

register_dataset(
    name="csv_data",
    data=csv_raw,
    source=csv_url,
    category="Structured CSV"
)


# ==================== 5. VIETNAMESE ====================

vi_base = (
    "https://raw.githubusercontent.com/"
    "UniversalDependencies/UD_Vietnamese-VTB/"
    "r2.15/"
)

vi_files = [
    "vi_vtb-ud-train.conllu",
    "vi_vtb-ud-dev.conllu",
    "vi_vtb-ud-test.conllu"
]

vi_sentences = []
vi_sources = []

for name in vi_files:

    url = vi_base + name

    content = download_bytes(url).decode("utf-8")

    sentences = [
        line[len("# text = "):]
        for line in content.splitlines()
        if line.startswith("# text = ")
    ]

    vi_sentences.extend(sentences)
    vi_sources.append(url)

vi_raw = "\n".join(
    vi_sentences
).encode("utf-8")

register_dataset(
    name="vietnamese",
    data=vi_raw,
    source=vi_sources,
    category="Vietnamese natural text"
)


# ==================== 6. MIXED DATASET ====================

mixed_parts = []

for name in [
    "enwik8_new",
    "english",
    "python_code",
    "csv_data",
    "vietnamese"
]:

    part = utf8_slice(
        datasets[name],
        size=20_100
    )

    mixed_parts.append(part)

mixed_raw = b"\n\n".join(
    mixed_parts
)

register_dataset(
    name="mixed",
    data=mixed_raw,
    source="20 KB portions of five Stage 8 datasets",
    category="Heterogeneous text",
    independent=False
)


# ==================== SAVE MANIFEST ====================

(STAGE / "results/dataset_manifest.json").write_text(
    json.dumps(
        dataset_manifest,
        indent=2,
        ensure_ascii=False
    ),
    encoding="utf-8"
)

dataset_df = pd.DataFrame(
    dataset_manifest
)

dataset_df.to_csv(
    STAGE / "results/dataset_manifest.csv",
    index=False
)

print("\n=== DATASET SUMMARY ===")

display(dataset_df[[
    "dataset",
    "category",
    "bytes",
    "independent_corpus",
    "sha256"
]])

assert len(datasets) == 6

print("\nTotal datasets: 6/6")
print("Total bytes:", sum(
    len(data) for data in datasets.values()
))

print("DATASET PREPARATION: PASS")
print("CELL 3 DONE")

# ==================== CELL 4 ====================
#Stage 8 — Cell 3: Chuẩn bị 6 dataset benchmark
import requests
import platform
import sysconfig
import hashlib
import json
import numpy as np
import pandas as pd
from pathlib import Path

DATA_DIR = STAGE / "datasets"
DATA_DIR.mkdir(exist_ok=True)

TARGET_BYTES = 100_000

datasets = {}
dataset_manifest = []

# ==================== HELPER FUNCTIONS ====================

def download_bytes(url):

    response = requests.get(
        url,
        timeout=120
    )

    response.raise_for_status()

    return response.content


def utf8_slice(data, size=TARGET_BYTES):

    block = data[:size]

    # Chỉ xử lý biên UTF-8 bị cắt,
    # không bỏ ký tự lỗi trong phần nội dung.

    for trim_start in range(4):

        for trim_end in range(4):

            candidate = block[
                trim_start:
                len(block) - trim_end
            ]

            try:
                candidate.decode("utf-8", errors="strict")
                return candidate
            except UnicodeDecodeError:
                continue

    raise ValueError("Invalid UTF-8 data")


def register_dataset(name, data, source, category,
                     independent=True):

    assert len(data) >= TARGET_BYTES, (
        f"{name}: insufficient data ({len(data)} B)"
    )

    prepared = utf8_slice(data)

    path = DATA_DIR / f"{name}.txt"

    path.write_bytes(prepared)

    datasets[name] = prepared

    record = {
        "dataset": name,
        "category": category,
        "source": source,
        "source_bytes": len(data),
        "source_sha256": hashlib.sha256(
            data
        ).hexdigest(),
        "bytes": len(prepared),
        "sha256": hashlib.sha256(
            prepared
        ).hexdigest(),
        "independent_corpus": independent,
        "path": str(path)
    }

    dataset_manifest.append(record)

    print(
        f"PASS | {name:15s} | "
        f"{len(prepared):,} bytes",
        flush=True
    )


# ==================== 1. ENWIK8 NEW ====================

print("=== PREPARE DATASETS ===\n")

enwik8_path = (
    ROOT
    / "notebook/finezip_experiment2/data/enwik8"
)

with enwik8_path.open("rb") as f:

    f.seek(5_000_000)

    enwik8_raw = f.read(TARGET_BYTES + 4)

register_dataset(
    name="enwik8_new",
    data=enwik8_raw,
    source="enwik8, byte offset 5000000",
    category="Wikipedia"
)


# ==================== 2. ENGLISH TEXT ====================

english_url = (
    "https://www.gutenberg.org/files/"
    "1342/1342-0.txt"
)

english_raw = download_bytes(english_url)

register_dataset(
    name="english",
    data=english_raw,
    source=english_url,
    category="English literature"
)


# ==================== 3. PYTHON SOURCE ====================

stdlib = Path(
    sysconfig.get_path("stdlib")
)

python_files = [
    "argparse.py",
    "ast.py",
    "tokenize.py",
    "pathlib.py",
    "inspect.py",
    "functools.py"
]

python_parts = []
python_sources = []

for name in python_files:

    path = stdlib / name

    if path.is_file():

        python_parts.append(
            path.read_bytes()
        )

        python_sources.append(name)

python_raw = b"\n\n".join(
    python_parts
)

register_dataset(
    name="python_code",
    data=python_raw,
    source={
        "python_version": platform.python_version(),
        "stdlib_files": python_sources
    },
    category="Source code"
)


# ==================== 4. CSV DATASET ====================

csv_url = (
    "https://raw.githubusercontent.com/"
    "mwaskom/seaborn-data/master/diamonds.csv"
)

csv_raw = download_bytes(csv_url)

register_dataset(
    name="csv_data",
    data=csv_raw,
    source=csv_url,
    category="Structured CSV"
)


# ==================== 5. VIETNAMESE ====================

vi_base = (
    "https://raw.githubusercontent.com/"
    "UniversalDependencies/UD_Vietnamese-VTB/"
    "r2.15/"
)

vi_files = [
    "vi_vtb-ud-train.conllu",
    "vi_vtb-ud-dev.conllu",
    "vi_vtb-ud-test.conllu"
]

vi_sentences = []
vi_sources = []

for name in vi_files:

    url = vi_base + name

    content = download_bytes(url).decode("utf-8")

    sentences = [
        line[len("# text = "):]
        for line in content.splitlines()
        if line.startswith("# text = ")
    ]

    vi_sentences.extend(sentences)
    vi_sources.append(url)

vi_raw = "\n".join(
    vi_sentences
).encode("utf-8")

register_dataset(
    name="vietnamese",
    data=vi_raw,
    source=vi_sources,
    category="Vietnamese natural text"
)


# ==================== 6. MIXED DATASET ====================

mixed_parts = []

for name in [
    "enwik8_new",
    "english",
    "python_code",
    "csv_data",
    "vietnamese"
]:

    part = utf8_slice(
        datasets[name],
        size=20_100
    )

    mixed_parts.append(part)

mixed_raw = b"\n\n".join(
    mixed_parts
)

register_dataset(
    name="mixed",
    data=mixed_raw,
    source="20 KB portions of five Stage 8 datasets",
    category="Heterogeneous text",
    independent=False
)


# ==================== SAVE MANIFEST ====================

(STAGE / "results/dataset_manifest.json").write_text(
    json.dumps(
        dataset_manifest,
        indent=2,
        ensure_ascii=False
    ),
    encoding="utf-8"
)

dataset_df = pd.DataFrame(
    dataset_manifest
)

dataset_df.to_csv(
    STAGE / "results/dataset_manifest.csv",
    index=False
)

print("\n=== DATASET SUMMARY ===")

display(dataset_df[[
    "dataset",
    "category",
    "bytes",
    "independent_corpus",
    "sha256"
]])

assert len(datasets) == 6

print("\nTotal datasets: 6/6")
print("Total bytes:", sum(
    len(data) for data in datasets.values()
))

print("DATASET PREPARATION: PASS")
print("CELL 3 DONE")

# ==================== CELL 5 ====================
#Stage 8 — Cell 3 (Fix): Tải lại dữ liệu tiếng Anh
english_urls = [
    "https://raw.githubusercontent.com/"
    "GITenberg/Pride-and-Prejudice_1342/master/1342-0.txt",

    "https://www.gutenberg.org/cache/epub/1342/pg1342.txt"
]

english_raw = None

for url in english_urls:

    try:
        content = download_bytes(url)

        assert len(content) >= TARGET_BYTES

        content.decode("utf-8", errors="strict")

        english_raw = content
        english_url = url

        print("DOWNLOAD: PASS")
        print("Source:", url)
        print("Downloaded bytes:", len(content))

        break

    except Exception as e:

        print("FAILED:", url)
        print("Reason:", str(e))

assert english_raw is not None, \
    "All English download sources failed"

register_dataset(
    name="english",
    data=english_raw,
    source=english_url,
    category="English literature"
)

print("\nPrepared datasets:", list(datasets.keys()))
print("CELL 3 FIX DONE")

# ==================== CELL 6 ====================
#Stage 8 — Cell 4: Prepare Remaining Datasets
# Stage 8 — Cell 4: Prepare Remaining Datasets

print("=== PREPARE REMAINING DATASETS ===")

# 1. Python source code
stdlib = Path(sysconfig.get_path("stdlib"))

python_files = [
    "argparse.py",
    "ast.py",
    "tokenize.py",
    "inspect.py",
    "functools.py"
]

python_parts = []
python_sources = []

for name in python_files:
    path = stdlib / name
    if path.is_file():
        python_parts.append(path.read_bytes())
        python_sources.append(name)

python_raw = b"\n\n".join(python_parts)

if "python_code" not in datasets:
    register_dataset(
        "python_code",
        python_raw,
        {
            "python_version": platform.python_version(),
            "stdlib_files": python_sources
        },
        "Source code"
    )

# 2. Structured CSV
csv_url = (
    "https://raw.githubusercontent.com/"
    "mwaskom/seaborn-data/master/diamonds.csv"
)

if "csv_data" not in datasets:
    register_dataset(
        "csv_data",
        download_bytes(csv_url),
        csv_url,
        "Structured CSV"
    )

# 3. Vietnamese natural text
vi_base = (
    "https://raw.githubusercontent.com/"
    "UniversalDependencies/UD_Vietnamese-VTB/r2.15/"
)

vi_files = [
    "vi_vtb-ud-train.conllu",
    "vi_vtb-ud-dev.conllu",
    "vi_vtb-ud-test.conllu"
]

if "vietnamese" not in datasets:
    vi_sentences = []
    vi_sources = []

    for name in vi_files:
        url = vi_base + name
        content = download_bytes(url).decode("utf-8")

        sentences = [
            line[len("# text = "):]
            for line in content.splitlines()
            if line.startswith("# text = ")
        ]

        vi_sentences.extend(sentences)
        vi_sources.append(url)

        print(f"{name}: {len(sentences):,} sentences")

    vi_raw = "\n".join(vi_sentences).encode("utf-8")

    print(f"Vietnamese source: {len(vi_raw):,} bytes")

    assert len(vi_raw) >= TARGET_BYTES, \
        "Insufficient Vietnamese natural text"

    register_dataset(
        "vietnamese",
        vi_raw,
        vi_sources,
        "Vietnamese natural text"
    )

# 4. Heterogeneous mixed dataset
mixed_names = [
    "enwik8_new",
    "english",
    "python_code",
    "csv_data",
    "vietnamese"
]

if "mixed" not in datasets:
    mixed_parts = [
        utf8_slice(datasets[name], size=20_100)
        for name in mixed_names
    ]

    mixed_raw = b"\n\n".join(mixed_parts)

    register_dataset(
        "mixed",
        mixed_raw,
        {
            "components": mixed_names,
            "component_target_bytes": 20_100,
            "derived_dataset": True
        },
        "Heterogeneous text",
        independent=False
    )

# 5. Verify and save metadata
print("\n=== DATASET VERIFICATION ===")

assert len(datasets) == 6

for name, raw in datasets.items():
    decoded_text = raw.decode("utf-8", errors="strict")

    assert decoded_text.encode("utf-8") == raw

    saved = (DATA_DIR / f"{name}.txt").read_bytes()
    assert saved == raw

    print(
        f"PASS | {name:15s} | "
        f"{len(raw):,} bytes | UTF-8 exact"
    )

manifest_df = pd.DataFrame(dataset_manifest)

manifest_df.to_csv(
    STAGE / "results/dataset_manifest.csv",
    index=False
)

(STAGE / "results/dataset_manifest.json").write_text(
    json.dumps(
        dataset_manifest,
        ensure_ascii=False,
        indent=2
    ),
    encoding="utf-8"
)

print("\n=== FINAL DATASET MANIFEST ===")

display(manifest_df[
    ["dataset", "category", "bytes", "independent_corpus"]
])

print("\nDatasets: 6/6")
print("Manifest saved: PASS")
print("CELL 4 DONE")

# ==================== CELL 7 ====================
# Stage 8 — Cell 5: Load GPT-2 & Dataset Tokenization

import time
import math
import torch
import hashlib
import numpy as np
import pandas as pd

from collections import Counter
from transformers import AutoTokenizer, AutoModelForCausalLM

DEVICE = "cuda:0"
MODEL_NAME = "gpt2"

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

print("=== LOAD TOKENIZER ===")

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

dataset_tokens = {}
tokenization_records = []

def shannon_entropy(values):
    counts = np.asarray(
        list(Counter(values).values()),
        dtype=np.float64
    )
    probs = counts / counts.sum()
    return float(-np.sum(probs * np.log2(probs)))

print("\n=== DATASET TOKENIZATION ===")

for name, raw in datasets.items():

    text = raw.decode("utf-8", errors="strict")

    start = time.perf_counter()

    ids = tokenizer.encode(
        text,
        add_special_tokens=False,
        verbose=False
    )

    elapsed = time.perf_counter() - start

    restored = tokenizer.decode(
        ids,
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    byte_exact = restored == raw

    assert byte_exact, f"Tokenizer mismatch: {name}"

    tokens = np.asarray(ids, dtype=np.int64)
    dataset_tokens[name] = tokens

    np.save(
        STAGE / "artifacts" / f"{name}_tokens.npy",
        tokens
    )

    unique_tokens = len(set(ids))

    record = {
        "dataset": name,
        "original_bytes": len(raw),
        "characters": len(text),
        "tokens": len(ids),
        "unique_tokens": unique_tokens,
        "bytes_per_token": len(raw) / len(ids),
        "byte_entropy": shannon_entropy(raw),
        "token_entropy": shannon_entropy(ids),
        "token_repetition_pct":
            100 * (1 - unique_tokens / len(ids)),
        "tokenization_seconds": elapsed,
        "byte_exact": byte_exact,
        "sha256": hashlib.sha256(raw).hexdigest()
    }

    tokenization_records.append(record)

    print(
        f"PASS | {name:15s} | "
        f"Tokens: {len(ids):,} | "
        f"Byte entropy: {record['byte_entropy']:.4f} | "
        f"Token entropy: {record['token_entropy']:.4f}"
    )

tokenization_df = pd.DataFrame(tokenization_records)

tokenization_df.to_csv(
    STAGE / "results/dataset_tokenization.csv",
    index=False
)

(STAGE / "results/dataset_tokenization.json").write_text(
    json.dumps(
        tokenization_records,
        ensure_ascii=False,
        indent=2
    ),
    encoding="utf-8"
)

print("\n=== LOAD GPT-2 ===")

torch.cuda.empty_cache()

start = time.perf_counter()

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.float32,
    attn_implementation="sdpa"
).to(DEVICE)

model.eval()

torch.cuda.synchronize()

print(
    f"Model load time: "
    f"{time.perf_counter() - start:.3f} s"
)

model_config = {
    "name": MODEL_NAME,
    "vocab_size": model.config.vocab_size,
    "bos_token_id": tokenizer.bos_token_id,
    "dtype": str(next(model.parameters()).dtype),
    "attention": model.config._attn_implementation,
    "gpu": torch.cuda.get_device_name(0),
    "torch": torch.__version__,
    "tf32": torch.backends.cuda.matmul.allow_tf32,
    "matmul_precision": torch.get_float32_matmul_precision(),
    "adapter_sha256": None
}

assert model_config["vocab_size"] == 50257
assert model_config["dtype"] == "torch.float32"
assert model_config["attention"] == "sdpa"

(STAGE / "results/model_config.json").write_text(
    json.dumps(model_config, indent=2),
    encoding="utf-8"
)

print("\n=== MODEL CONFIG ===")
print(json.dumps(model_config, indent=2))

print("\n=== TOKENIZATION SUMMARY ===")

display(tokenization_df[
    [
        "dataset",
        "original_bytes",
        "tokens",
        "unique_tokens",
        "bytes_per_token",
        "byte_entropy",
        "token_entropy",
        "token_repetition_pct",
        "byte_exact"
    ]
].round(4))

assert len(dataset_tokens) == 6
assert tokenization_df["byte_exact"].all()

print(
    f"\nGPU allocated: "
    f"{torch.cuda.memory_allocated(0) / 1024**2:.2f} MiB"
)

print("Tokenizer byte-exact: 6/6")
print("MODEL CONFIGURATION: PASS")
print("CELL 5 DONE")

# ==================== CELL 8 ====================
# Stage 8 — Cell 6: Inspect Frozen Stage 7 Implementation

import ast
import inspect
import hashlib
from pathlib import Path

history_path = (
    EVIDENCE7 / "code" / "stage7_notebook_history.py"
)

assert history_path.is_file()

history_text = history_path.read_text(encoding="utf-8")

print("=== STAGE 7 IMPLEMENTATION ===")
print("Source:", history_path.name)
print("Bytes:", history_path.stat().st_size)
print(
    "SHA-256:",
    hashlib.sha256(history_path.read_bytes()).hexdigest()
)

print("\n=== STAGE 7 FUNCTIONS ===")

try:
    tree = ast.parse(history_text)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            args = ast.unparse(node.args)

            print(
                f"Line {node.lineno:4d} | "
                f"{node.name}({args})"
            )

except SyntaxError:
    for i, line in enumerate(
        history_text.splitlines(), start=1
    ):
        if line.strip().startswith("def "):
            print(f"Line {i:4d} | {line.strip()}")

print("\n=== FINEZIP CODEC API ===")

for name in [
    "HFLM",
    "FixedPolicy",
    "DPPolicy",
    "encode",
    "decode",
    "quick_check",
    "pad_tokens",
    "layout_to_flags"
]:
    obj = getattr(fz, name, None)

    if obj is not None:
        print(f"PASS | {name}{inspect.signature(obj)}")
    else:
        print(f"MISSING | {name}")

print("\n=== ANALYSIS AND DP API ===")

for name in [
    "analyze",
    "cost_ac",
    "cost_rank_proxy",
    "TreeDP"
]:
    obj = getattr(s5, name, None)

    if obj is not None:
        print(f"PASS | {name}{inspect.signature(obj)}")
    else:
        print(f"MISSING | {name}")

print("\n=== FROZEN BENCHMARK PARAMETERS ===")
print("Rank table shape:", rank_table.shape)
print("Lambda candidates:", len(DENSE_LAMBDAS))
print("Target contexts:", TARGETS)
print("Measured decode cost:", measured_cost)
print("Batch plan:", batch_plan)

assert len(DENSE_LAMBDAS) == 122
assert rank_table.shape == (4097,)
assert len(dataset_tokens) == 6

print("\n=== BENCHMARK PLAN ===")

for name, tokens in dataset_tokens.items():
    print(
        f"{name:15s} | {len(tokens):>6,} tokens "
        "| Fixed-64, BC-64, Fixed-128, BC-128"
    )

print("\nDatasets: 6")
print("Methods per dataset: 4")
print("Total configurations: 24")
print("CELL 6 DONE")

# ==================== CELL 9 ====================
# Stage 8 — Cell 7: Restore BC-DP Implementation

import ast
import inspect
import hashlib

history_lines = history_text.splitlines()

print("=== ORIGINAL STAGE 7 BUDGET IMPLEMENTATION ===")

# Extract the original budget evaluation and search
for i in range(1890, 2200):
    if i < len(history_lines):
        print(f"{i+1:04d} | {history_lines[i]}")

print("\n=== ORIGINAL HELD-OUT IMPLEMENTATION ===")

# Extract the held-out search and encoding
for i in range(2240, 2580):
    if i < len(history_lines):
        print(f"{i+1:04d} | {history_lines[i]}")

print("\n=== CODEC IMPLEMENTATION ===")

for obj in [
    fz.HFLM.__init__,
    fz.FixedPolicy.__call__,
    fz.pad_tokens,
    s5.TreeDP
]:
    print("\n" + "=" * 60)
    print(inspect.getsource(obj))

print("\n=== SOURCE INTEGRITY ===")

source_hash = hashlib.sha256(
    history_path.read_bytes()
).hexdigest()

assert source_hash == (
    "1ed0957831ed1045cbb4da05492438d373"
    "66219f86cea59789e6e0c8801a0b2e"
)

print("Stage 7 source SHA-256: PASS")
print("Original source modified: False")
print("CELL 7 DONE")

# ==================== CELL 10 ====================
# Stage 8 — Cell 8: Multi-dataset Analysis & BC-DP Search

import bz2
import gc
import time
import hashlib
import json
import ast

# Restore the original Stage 7 evaluation function
history_tree = ast.parse(history_text)

original_function = next(
    node for node in history_tree.body
    if isinstance(node, ast.FunctionDef)
    and node.name == "evaluate_budget_layout"
)

exec(
    compile(
        ast.Module(
            body=[original_function],
            type_ignores=[]
        ),
        filename="stage7_frozen_evaluation",
        mode="exec"
    )
)

print("Stage 7 evaluation function restored: PASS")

# Use original FineZip codec wrapper
del model
gc.collect()
torch.cuda.empty_cache()

lm = fz.HFLM(
    name="gpt2",
    device="cuda:0",
    max_batch_tokens=1024,
    eps=None
)

assert next(lm.model.parameters()).dtype == torch.float32
assert lm.model.config._attn_implementation == "sdpa"
assert lm.bos == 50256
assert lm.V == 50257

LEVELS = tuple(fz.CTX_SIZES)
RMAX = 4096

time_models = {
    "Fitted": lambda L: NEW_C * L**2,
    "Measured": lambda L: measured_cost[L]
}

assert len(DENSE_LAMBDAS) == 122
assert rank_table.shape == (4097,)

stage8_selected = {}
analysis_records = []
selection_records = []

stage_start = time.perf_counter()

for dataset_name, tokens in dataset_tokens.items():

    print("\n" + "=" * 60)
    print(f"DATASET: {dataset_name}")
    print("=" * 60)

    # 1. Original Stage 7 candidate analysis
    toks_pad = fz.pad_tokens(tokens, lm.bos)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    analysis = s5.analyze(
        toks_pad,
        lm,
        batch=8,
        levels=LEVELS
    )

    torch.cuda.synchronize()

    analysis_seconds = time.perf_counter() - t0

    analysis_peak_mib = (
        torch.cuda.max_memory_allocated(0) / 1024**2
    )

    # Save numeric cache and context statistics
    cache = {}

    for L in LEVELS:

        ranks = analysis[L]["ranks"]

        assert ranks.shape == (len(toks_pad) // L, L)

        for key, value in analysis[L].items():
            if isinstance(value, np.ndarray):
                cache[f"L{L}_{key}"] = value

        analysis_records.append({
            "dataset": dataset_name,
            "context": int(L),
            "chunks": int(ranks.shape[0]),
            "scored_tokens": int(ranks.size),
            "mean_rank": float(ranks.mean()),
            "median_rank": float(np.median(ranks)),
            "top1_accuracy_pct": float(
                100 * np.mean(ranks == 0)
            ),
            "analysis_seconds": analysis_seconds,
            "analysis_peak_mib": analysis_peak_mib
        })

    np.savez_compressed(
        STAGE / "artifacts" /
        f"{dataset_name}_analysis.npz",
        **cache
    )

    print(f"Analysis: {analysis_seconds:.3f} s")

    # 2. Frozen NLL and rank objectives
    cost_nll = s5.cost_ac(analysis)
    cost_rank = {}

    for L in LEVELS:

        ranks = analysis[L]["ranks"]

        tail = np.where(
            ranks >= RMAX,
            np.log2(np.maximum(ranks, 1)),
            0.0
        )

        cost_rank[L] = (
            rank_table[
                np.minimum(ranks, RMAX)
            ].sum(axis=1)
            + tail.sum(axis=1)
        )

    objectives = {
        "NLL": cost_nll,
        "Rank": cost_rank
    }

    # 3. Fixed-context reference budgets
    fixed_reference = {}

    for L in TARGETS:

        leaves = fz.FixedPolicy(L)(
            toks_pad, lm, 8
        )

        fixed_reference[L] = evaluate_budget_layout(
            leaves,
            analysis,
            len(toks_pad)
        )

    # 4. Frozen 488-configuration search
    search_rows = []
    search_layouts = {}
    evaluated = {}

    t0 = time.perf_counter()

    for objective_name, cost in objectives.items():

        for time_name in ["Fitted", "Measured"]:

            for lam in DENSE_LAMBDAS:

                policy = s5.TreeDP(
                    cost=cost,
                    lam=float(lam),
                    t_chunk=time_models[time_name]
                )

                leaves = policy(toks_pad)

                key = hashlib.sha256(
                    np.asarray(
                        leaves, dtype=np.int64
                    ).tobytes()
                ).hexdigest()

                if key not in evaluated:

                    evaluated[key] = (
                        evaluate_budget_layout(
                            leaves,
                            analysis,
                            len(toks_pad)
                        )
                    )

                    search_layouts[key] = leaves

                search_rows.append({
                    "dataset": dataset_name,
                    "objective": objective_name,
                    "time_model": time_name,
                    "lambda": float(lam),
                    **evaluated[key]
                })

            print(
                f"PASS | {objective_name}-{time_name}",
                flush=True
            )

    search_seconds = time.perf_counter() - t0

    search_df = pd.DataFrame(search_rows)

    assert len(search_df) == 488

    search_df.to_csv(
        STAGE / "results" /
        f"{dataset_name}_search_all.csv",
        index=False
    )

    # 5. Select candidate within fixed decode budget
    stage8_selected[dataset_name] = {}

    for L in TARGETS:

        ref = fixed_reference[L]

        feasible = search_df[
            search_df["predicted_decode_s"]
            <= ref["predicted_decode_s"]
        ]

        assert not feasible.empty

        best = feasible.sort_values([
            "variable_bytes",
            "predicted_decode_s"
        ]).iloc[0]

        fixed_bytes = int(ref["variable_bytes"])
        adaptive_bytes = int(best["variable_bytes"])

        fixed_seconds = float(ref["predicted_decode_s"])
        adaptive_seconds = float(best["predicted_decode_s"])

        selected = {
            "dataset": dataset_name,
            "baseline": f"Fixed-{L}",
            "context": int(L),
            "objective": str(best["objective"]),
            "time_model": str(best["time_model"]),
            "lambda": float(best["lambda"]),
            "layout_sha256": str(best["layout_sha256"]),
            "fixed_variable_bytes": fixed_bytes,
            "adaptive_variable_bytes": adaptive_bytes,
            "proxy_size_saving_pct":
                100 * (1 - adaptive_bytes / fixed_bytes),
            "fixed_budget_s": fixed_seconds,
            "adaptive_pred_decode_s": adaptive_seconds,
            "pred_decode_saving_pct":
                100 * (1 - adaptive_seconds / fixed_seconds),
            "effective_L": float(best["effective_L"]),
            "analysis_seconds": analysis_seconds,
            "search_seconds": search_seconds,
            "analysis_peak_mib": analysis_peak_mib,
            "unique_layouts": len(evaluated)
        }

        chosen_leaves = search_layouts[
            best["layout_sha256"]
        ]

        stage8_selected[dataset_name][L] = {
            "selection": selected,
            "leaves": [
                [int(start), int(length)]
                for start, length in chosen_leaves
            ]
        }

        selection_records.append(selected)

        print(
            f"BC-{L:3d} | "
            f"Proxy saving: "
            f"{selected['proxy_size_saving_pct']:.4f}% | "
            f"Pred decode saving: "
            f"{selected['pred_decode_saving_pct']:.4f}%"
        )

    # 6. Save checkpoint after each dataset
    (STAGE / "artifacts" /
     "stage8_selected_layouts.json").write_text(
        json.dumps(stage8_selected, indent=2)
    )

    pd.DataFrame(selection_records).to_csv(
        STAGE / "results/selected_candidates.csv",
        index=False
    )

    pd.DataFrame(analysis_records).to_csv(
        STAGE / "results/context_analysis.csv",
        index=False
    )

    print(
        f"Search: {search_seconds:.3f} s | "
        f"Unique layouts: {len(evaluated)}"
    )

    print(f"CHECKPOINT: {dataset_name} PASS")

    del analysis, cache, search_layouts, evaluated
    gc.collect()

# 7. Summary
selection_df = pd.DataFrame(selection_records)

assert len(stage8_selected) == 6
assert len(selection_df) == 12

print("\n=== MULTI-DATASET SEARCH SUMMARY ===")

display(selection_df[[
    "dataset",
    "baseline",
    "objective",
    "time_model",
    "lambda",
    "proxy_size_saving_pct",
    "pred_decode_saving_pct",
    "effective_L"
]].round(4))

print("\n=== FINAL STATUS ===")
print("Datasets analyzed: 6/6")
print("Search configurations:", 6 * 488)
print("Selected adaptive layouts: 12/12")
print(
    "Total elapsed:",
    round((time.perf_counter() - stage_start) / 60, 2),
    "minutes"
)
print("Checkpoints saved: PASS")
print("CELL 8 DONE")

# ==================== CELL 11 ====================
# Stage 8 — Cell 9: Full Encode Benchmark

import time
import gc
import json
import hashlib
import torch
import pandas as pd

ENCODE_JSON = STAGE / "results/encode_benchmark.json"
ENCODE_CSV = STAGE / "results/encode_benchmark.csv"

encode_records = []

# Restore checkpoint if available
if ENCODE_JSON.is_file():
    encode_records = json.loads(
        ENCODE_JSON.read_text()
    )

    print(
        "Restored encode records:",
        len(encode_records)
    )

completed = {
    (r["dataset"], r["method"]): r
    for r in encode_records
}

def encode_stage8(
    dataset_name,
    method,
    context,
    policy,
    family,
    selection=None
):

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    artifact_path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}.fzac"
    )

    key = (dataset_name, method)

    # Skip verified completed configurations
    if key in completed:

        record = completed[key]

        assert artifact_path.is_file()

        assert hashlib.sha256(
            artifact_path.read_bytes()
        ).hexdigest() == record["artifact_sha256"]

        print(f"SKIP | {dataset_name} | {method}")
        return record

    print(
        f"\n=== ENCODE: {dataset_name} | {method} ===",
        flush=True
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    encode_seconds = time.perf_counter() - t0

    codec_peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    counts = {
        int(L): int(sum(
            length == L
            for _, length in leaves
        ))
        for L in LEVELS
    }

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    padded_tokens = sum(
        int(L) for _, L in leaves
    )

    effective_L = (
        sum(int(L)**2 for _, L in leaves)
        / padded_tokens
    )

    overhead = 0.0
    analysis_peak = 0.0

    if family == "Adaptive":

        overhead = (
            selection["analysis_seconds"]
            + selection["search_seconds"]
        )

        analysis_peak = selection[
            "analysis_peak_mib"
        ]

        # Verify that the encoded layout is unchanged
        layout_hash = hashlib.sha256(
            np.asarray(
                leaves, dtype=np.int64
            ).tobytes()
        ).hexdigest()

        assert layout_hash == selection[
            "layout_sha256"
        ]

        assert predicted_decode_s <= (
            selection["fixed_budget_s"] + 1e-8
        )

    artifact_path.write_bytes(blob)

    artifact_sha = hashlib.sha256(
        blob
    ).hexdigest()

    # Verify saved artifact
    assert hashlib.sha256(
        artifact_path.read_bytes()
    ).hexdigest() == artifact_sha

    record = {
        "dataset": dataset_name,
        "method": method,
        "family": family,
        "baseline": f"Fixed-{context}",
        "context": int(context),
        "original_bytes": len(raw),
        "original_sha256": hashlib.sha256(
            raw
        ).hexdigest(),
        "tokens": len(tokens),
        "padded_tokens": padded_tokens,
        "compressed_bytes": len(blob),
        "ratio": len(raw) / len(blob),
        "bpb": 8 * len(blob) / len(raw),
        "effective_L": effective_L,
        "encode_seconds": encode_seconds,
        "analysis_search_seconds": overhead,
        "total_encode_seconds":
            encode_seconds + overhead,
        "codec_peak_mib": codec_peak_mib,
        "encode_peak_mib": max(
            codec_peak_mib,
            analysis_peak
        ),
        "predicted_decode_s": predicted_decode_s,
        "chunk_counts": counts,
        "selection": selection,
        "artifact_path": str(artifact_path),
        "artifact_sha256": artifact_sha,
        "encode_session_id": SESSION_ID,
        "gpu_name": torch.cuda.get_device_name(0),
        "full_decode": "PENDING"
    }

    encode_records.append(record)
    completed[key] = record

    # Save after every configuration
    ENCODE_JSON.write_text(
        json.dumps(encode_records, indent=2)
    )

    pd.DataFrame(encode_records).to_csv(
        ENCODE_CSV,
        index=False
    )

    print("Compressed:", len(blob), "bytes")
    print("Ratio:", round(record["ratio"], 4))
    print("BPB:", round(record["bpb"], 4))
    print(
        "Total encode:",
        round(record["total_encode_seconds"], 3),
        "s"
    )
    print(
        "Predicted decode:",
        round(predicted_decode_s, 3),
        "s"
    )
    print(
        "GPU peak:",
        round(record["encode_peak_mib"], 2),
        "MiB"
    )
    print(
        f"Checkpoint: {len(encode_records)}/24 PASS"
    )

    return record


# ==================== RUN BENCHMARK ====================

start_stage = time.perf_counter()

for dataset_name in datasets:

    print("\n" + "=" * 60)
    print("DATASET:", dataset_name)
    print("=" * 60)

    for L in TARGETS:

        # Fixed baseline
        encode_stage8(
            dataset_name=dataset_name,
            method=f"Fixed-{L}",
            context=L,
            policy=fz.FixedPolicy(L),
            family="Fixed"
        )

        # Frozen adaptive layout
        chosen = stage8_selected[
            dataset_name
        ][L]

        chosen_leaves = [
            (int(start), int(length))
            for start, length in chosen["leaves"]
        ]

        def preset_policy(
            toks,
            model,
            batch,
            leaves=chosen_leaves
        ):
            return leaves

        encode_stage8(
            dataset_name=dataset_name,
            method=f"BC-vs-Fixed-{L}",
            context=L,
            policy=preset_policy,
            family="Adaptive",
            selection=chosen["selection"]
        )


# ==================== ENCODE SUMMARY ====================

encode_df = pd.DataFrame(encode_records)

assert len(encode_df) == 24

assert not encode_df.duplicated(
    ["dataset", "method"]
).any()

print("\n=== FULL ENCODE SUMMARY ===")

display(encode_df[[
    "dataset",
    "method",
    "compressed_bytes",
    "ratio",
    "bpb",
    "effective_L",
    "total_encode_seconds",
    "encode_peak_mib",
    "predicted_decode_s"
]].round(4))


# ==================== PAIRED COMPARISON ====================

pair_records = []

for dataset_name in datasets:

    for L in TARGETS:

        fixed = completed[
            (dataset_name, f"Fixed-{L}")
        ]

        adaptive = completed[
            (dataset_name, f"BC-vs-Fixed-{L}")
        ]

        pair_records.append({
            "dataset": dataset_name,
            "context": int(L),
            "fixed_bytes":
                fixed["compressed_bytes"],
            "adaptive_bytes":
                adaptive["compressed_bytes"],
            "size_saving_pct": 100 * (
                1 - adaptive["compressed_bytes"]
                / fixed["compressed_bytes"]
            ),
            "fixed_pred_decode_s":
                fixed["predicted_decode_s"],
            "adaptive_pred_decode_s":
                adaptive["predicted_decode_s"],
            "pred_decode_saving_pct": 100 * (
                1 - adaptive["predicted_decode_s"]
                / fixed["predicted_decode_s"]
            ),
            "fixed_encode_s":
                fixed["total_encode_seconds"],
            "adaptive_encode_s":
                adaptive["total_encode_seconds"],
            "encode_slowdown":
                adaptive["total_encode_seconds"]
                / fixed["total_encode_seconds"]
        })

encode_pair_df = pd.DataFrame(pair_records)

encode_pair_df.to_csv(
    STAGE / "results/encode_pair_comparison.csv",
    index=False
)

print("\n=== PAIRED ENCODE COMPARISON ===")

display(encode_pair_df.round(4))

print("\n=== FINAL STATUS ===")
print("Encode configurations: 24/24")
print("Paired comparisons: 12/12")
print(
    "Positive compression savings:",
    int((encode_pair_df["size_saving_pct"] > 0).sum()),
    "/ 12"
)
print(
    "Estimated sequential decode time:",
    round(
        encode_df["predicted_decode_s"].sum()
        / 3600, 2
    ),
    "hours"
)
print(
    "Cell elapsed:",
    round(
        (time.perf_counter() - start_stage) / 60,
        2
    ),
    "minutes"
)

print("Artifacts and checkpoints: PASS")
print("CELL 9 DONE")

# ==================== CELL 12 ====================
# Stage 8 — Cell 10: Initialize Full Decode Benchmark

import gc
import time
import json
import hashlib
import numpy as np
import pandas as pd
import torch

DECODE_JSON = STAGE / "results/decode_benchmark.json"
DECODE_CSV = STAGE / "results/decode_benchmark.csv"

encode_records = json.loads(
    ENCODE_JSON.read_text()
)

encode_lookup = {
    (r["dataset"], r["method"]): r
    for r in encode_records
}

assert len(encode_lookup) == 24

# ==================== VERIFY ARTIFACTS ====================

print("=== VERIFY ENCODE ARTIFACTS ===")

for (dataset_name, method), record in encode_lookup.items():

    path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}.fzac"
    )

    assert path.is_file()

    blob = path.read_bytes()

    assert len(blob) == record["compressed_bytes"]

    assert hashlib.sha256(
        blob
    ).hexdigest() == record["artifact_sha256"]

    assert hashlib.sha256(
        datasets[dataset_name]
    ).hexdigest() == record["original_sha256"]

    print(
        f"PASS | {dataset_name:15s} | "
        f"{method:16s} | {len(blob):,} B"
    )


# ==================== RESTORE CHECKPOINT ====================

decode_records = (
    json.loads(DECODE_JSON.read_text())
    if DECODE_JSON.is_file()
    else []
)


# ==================== FULL DECODE FUNCTION ====================

def decode_stage8(dataset_name, method, repeat=1):

    global decode_records

    enc = encode_lookup[(dataset_name, method)]

    previous = next(
        (
            r for r in decode_records
            if r["dataset"] == dataset_name
            and r["method"] == method
            and r["repeat"] == repeat
            and r["full_decode"] == "PASS"
        ),
        None
    )

    path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}.fzac"
    )

    blob = path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == enc["artifact_sha256"]

    if previous is not None:

        assert previous["original_sha256"] == \
            enc["original_sha256"]

        assert previous["artifact_sha256"] == \
            enc["artifact_sha256"]

        print(
            f"SKIP | {dataset_name} | "
            f"{method} | repeat={repeat}"
        )

        return previous

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    print(
        f"\n=== FULL DECODE: "
        f"{dataset_name} | {method} ===",
        flush=True
    )

    print("Session:", SESSION_ID)
    print("Repeat:", repeat)
    print("Compressed bytes:", len(blob))

    print(
        "Predicted decode seconds:",
        round(enc["predicted_decode_s"], 4)
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    # Same codec and timing protocol as Stage 7
    t0 = time.perf_counter()

    decoded = fz.decode(blob, lm)

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LOSSLESS VERIFICATION ====================

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, tokens)
    )

    byte_exact = decoded_raw == raw

    decoded_sha256 = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    sha_exact = (
        decoded_sha256
        == enc["original_sha256"]
    )

    passed = token_exact and byte_exact and sha_exact

    result = {
        **enc,
        "repeat": repeat,
        "decode_session_id": SESSION_ID,
        "decode_gpu_id": 0,
        "decode_gpu_name": torch.cuda.get_device_name(0),
        "decode_seconds": elapsed,
        "decode_minutes": elapsed / 60,
        "decode_peak_mib": peak_mib,
        "decode_bytes_per_second": len(raw) / elapsed,
        "decoded_bytes": len(decoded_raw),
        "decoded_tokens": len(decoded),
        "prediction_error_pct": 100 * abs(
            enc["predicted_decode_s"] - elapsed
        ) / elapsed,
        "total_seconds": (
            enc["total_encode_seconds"] + elapsed
        ),
        "token_exact": token_exact,
        "byte_exact": byte_exact,
        "sha_exact": sha_exact,
        "decoded_sha256": decoded_sha256,
        "full_decode": "PASS" if passed else "FAIL"
    }

    # ==================== CHECKPOINT ====================

    decode_records = [
        r for r in decode_records
        if not (
            r["dataset"] == dataset_name
            and r["method"] == method
            and r["repeat"] == repeat
        )
    ]

    decode_records.append(result)

    temp_path = DECODE_JSON.with_suffix(".tmp")

    temp_path.write_text(
        json.dumps(decode_records, indent=2)
    )

    temp_path.replace(DECODE_JSON)

    pd.DataFrame(decode_records).to_csv(
        DECODE_CSV,
        index=False
    )

    (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}_decoded.txt"
    ).write_bytes(decoded_raw)

    print("Actual decode:", round(elapsed, 4), "s")
    print("Decode minutes:", round(elapsed / 60, 4))
    print("GPU peak:", round(peak_mib, 4), "MiB")
    print("Token exact:", token_exact)
    print("Byte exact:", byte_exact)
    print("SHA-256 exact:", sha_exact)
    print("SHA-256:", decoded_sha256)
    print("STATUS:", result["full_decode"])

    completed_configs = {
        (r["dataset"], r["method"])
        for r in decode_records
        if r["full_decode"] == "PASS"
    }

    print(
        f"Checkpoint: {len(completed_configs)}/24"
    )

    assert passed, "Lossless verification failed"

    return result


# ==================== DATASET BENCHMARK FUNCTION ====================

def benchmark_dataset_stage8(dataset_name, repeat=1):

    rows = []

    for L in TARGETS:

        fixed = decode_stage8(
            dataset_name,
            f"Fixed-{L}",
            repeat
        )

        adaptive = decode_stage8(
            dataset_name,
            f"BC-vs-Fixed-{L}",
            repeat
        )

        rows.append({
            "dataset": dataset_name,
            "context": L,
            "repeat": repeat,
            "fixed_bytes": fixed["compressed_bytes"],
            "adaptive_bytes": adaptive["compressed_bytes"],
            "size_saving_pct": 100 * (
                1 - adaptive["compressed_bytes"]
                / fixed["compressed_bytes"]
            ),
            "fixed_decode_s": fixed["decode_seconds"],
            "adaptive_decode_s": adaptive["decode_seconds"],
            "decode_saving_pct": 100 * (
                1 - adaptive["decode_seconds"]
                / fixed["decode_seconds"]
            ),
            "fixed_total_s": fixed["total_seconds"],
            "adaptive_total_s": adaptive["total_seconds"],
            "total_time_saving_pct": 100 * (
                1 - adaptive["total_seconds"]
                / fixed["total_seconds"]
            ),
            "fixed_decode_peak_mib": fixed["decode_peak_mib"],
            "adaptive_decode_peak_mib": adaptive["decode_peak_mib"],
            "byte_exact": (
                fixed["byte_exact"]
                and adaptive["byte_exact"]
            )
        })

    comparison = pd.DataFrame(rows)

    comparison.to_csv(
        STAGE / "results" /
        f"{dataset_name}_pair_comparison_repeat{repeat}.csv",
        index=False
    )

    print("\n=== PAIRED FULL DECODE COMPARISON ===")

    display(comparison.round(4))

    assert comparison["byte_exact"].all()

    print(f"DATASET {dataset_name}: 4/4 PASS")

    return comparison


# ==================== BENCHMARK PLAN ====================

print("\n=== ESTIMATED DECODE TIME ===")

for dataset_name in datasets:

    seconds = sum(
        r["predicted_decode_s"]
        for r in encode_records
        if r["dataset"] == dataset_name
    )

    print(
        f"{dataset_name:15s} | "
        f"{seconds / 60:.2f} minutes"
    )

completed_configs = {
    (r["dataset"], r["method"])
    for r in decode_records
    if r["full_decode"] == "PASS"
}

print("\n=== FINAL STATUS ===")
print("Encode artifacts: 24/24 PASS")
print("Decode benchmark function: READY")
print(f"Full decode: {len(completed_configs)}/24")
print("Next: enwik8_new")
print("CELL 10 DONE")

# ==================== CELL 13 ====================
# Stage 8 — Cell 11: Full Decode Wikipedia

stage8_enwik8 = benchmark_dataset_stage8(
    dataset_name="enwik8_new",
    repeat=1
)

print("\nCELL 11 DONE")

# ==================== CELL 14 ====================
# Stage 8 — Cell 12: Full Decode English

stage8_english = benchmark_dataset_stage8(
    dataset_name="english",
    repeat=1
)

print("\nCELL 12 DONE")

# ==================== CELL 15 ====================
# Stage 8 — Cell 13: Full Decode Python Code

stage8_python = benchmark_dataset_stage8(
    dataset_name="python_code",
    repeat=1
)

print("\nCELL 13 DONE")

# ==================== CELL 16 ====================
# Stage 8 — Cell 14: Full Decode CSV Data

stage8_csv = benchmark_dataset_stage8(
    dataset_name="csv_data",
    repeat=1
)

print("\nCELL 14 DONE")

# ==================== CELL 17 ====================
# Stage 8 — Cell 15: Full Decode Vietnamese

stage8_vietnamese = benchmark_dataset_stage8(
    dataset_name="vietnamese",
    repeat=1
)

print("\nCELL 15 DONE")

# ==================== CELL 18 ====================
# Stage 8 — Cell 16: Full Decode Mixed Dataset

stage8_mixed = benchmark_dataset_stage8(
    dataset_name="mixed",
    repeat=1
)

print("\nCELL 16 DONE")

# ==================== CELL 19 ====================
# Stage 8 — Cell 17: Final Summary & Publication Figures

import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pathlib import Path
from matplotlib.ticker import PercentFormatter

RESULTS_DIR = STAGE / "results"
PLOTS_DIR = STAGE / "plots"

PLOTS_DIR.mkdir(parents=True, exist_ok=True)

# ==================== LOAD AND VERIFY ====================

final_records = json.loads(
    (RESULTS_DIR / "decode_benchmark.json").read_text()
)

final_df = pd.DataFrame(final_records)

assert len(final_df) == 24
assert not final_df.duplicated(
    ["dataset", "method", "repeat"]
).any()

assert final_df["byte_exact"].all()
assert final_df["token_exact"].all()
assert final_df["sha_exact"].all()
assert (final_df["full_decode"] == "PASS").all()

for r in final_records:

    name = r["dataset"]
    method = r["method"]

    blob_path = (
        STAGE / "artifacts" /
        f"{name}_{method}.fzac"
    )

    decoded_path = (
        STAGE / "artifacts" /
        f"{name}_{method}_decoded.txt"
    )

    assert hashlib.sha256(
        blob_path.read_bytes()
    ).hexdigest() == r["artifact_sha256"]

    assert hashlib.sha256(
        decoded_path.read_bytes()
    ).hexdigest() == r["original_sha256"]

print("Full decode: 24/24 PASS")
print("Artifact integrity: 24/24 PASS")

# ==================== PAIRED COMPARISON ====================

pair_rows = []

for dataset_name in datasets:

    for L in TARGETS:

        fixed = final_df[
            (final_df["dataset"] == dataset_name)
            & (final_df["method"] == f"Fixed-{L}")
        ].iloc[0]

        adaptive = final_df[
            (final_df["dataset"] == dataset_name)
            & (
                final_df["method"]
                == f"BC-vs-Fixed-{L}"
            )
        ].iloc[0]

        decode_gain = (
            fixed["decode_seconds"]
            - adaptive["decode_seconds"]
        )

        encode_overhead = (
            adaptive["total_encode_seconds"]
            - fixed["total_encode_seconds"]
        )

        break_even = (
            max(
                1,
                int(np.ceil(
                    encode_overhead / decode_gain
                ))
            )
            if decode_gain > 0
            else None
        )

        fixed_layout = fz.FixedPolicy(L)(
            fz.pad_tokens(
                dataset_tokens[dataset_name],
                lm.bos
            ),
            lm,
            8
        )

        adaptive_layout = stage8_selected[
            dataset_name
        ][L]["leaves"]

        layout_identical = np.array_equal(
            np.asarray(fixed_layout),
            np.asarray(adaptive_layout)
        )

        pair_rows.append({
            "dataset": dataset_name,
            "context": int(L),

            "fixed_bytes":
                int(fixed["compressed_bytes"]),

            "adaptive_bytes":
                int(adaptive["compressed_bytes"]),

            "fixed_bpb":
                float(fixed["bpb"]),

            "adaptive_bpb":
                float(adaptive["bpb"]),

            "size_saving_pct": 100 * (
                1 - adaptive["compressed_bytes"]
                / fixed["compressed_bytes"]
            ),

            "fixed_encode_s":
                float(fixed["total_encode_seconds"]),

            "adaptive_encode_s":
                float(adaptive["total_encode_seconds"]),

            "encode_slowdown":
                adaptive["total_encode_seconds"]
                / fixed["total_encode_seconds"],

            "fixed_decode_s":
                float(fixed["decode_seconds"]),

            "adaptive_decode_s":
                float(adaptive["decode_seconds"]),

            "decode_saving_pct": 100 * (
                1 - adaptive["decode_seconds"]
                / fixed["decode_seconds"]
            ),

            "fixed_total_s":
                float(fixed["total_seconds"]),

            "adaptive_total_s":
                float(adaptive["total_seconds"]),

            "total_time_saving_pct": 100 * (
                1 - adaptive["total_seconds"]
                / fixed["total_seconds"]
            ),

            "fixed_decode_peak_mib":
                float(fixed["decode_peak_mib"]),

            "adaptive_decode_peak_mib":
                float(adaptive["decode_peak_mib"]),

            "decode_memory_change_pct": 100 * (
                adaptive["decode_peak_mib"]
                / fixed["decode_peak_mib"] - 1
            ),

            "fixed_effective_L":
                float(fixed["effective_L"]),

            "adaptive_effective_L":
                float(adaptive["effective_L"]),

            "break_even_decodes": break_even,

            "layout_identical":
                bool(layout_identical),

            "artifact_identical": bool(
                fixed["artifact_sha256"]
                == adaptive["artifact_sha256"]
            ),

            "byte_exact": bool(
                fixed["byte_exact"]
                and adaptive["byte_exact"]
            ),

            "both_improved": bool(
                adaptive["compressed_bytes"]
                < fixed["compressed_bytes"]
                and decode_gain > 0
            ),

            "repeats": 1
        })

pair_df = pd.DataFrame(pair_rows)

assert len(pair_df) == 12

# ==================== SAVE FINAL TABLES ====================

final_df.to_csv(
    RESULTS_DIR / "stage8_final_summary.csv",
    index=False
)

final_df.to_json(
    RESULTS_DIR / "stage8_final_summary.json",
    orient="records",
    indent=2
)

pair_df.to_csv(
    RESULTS_DIR / "stage8_pair_comparison.csv",
    index=False
)

pair_df.to_json(
    RESULTS_DIR / "stage8_pair_comparison.json",
    orient="records",
    indent=2
)

# Independent datasets only
independent_df = pair_df[
    pair_df["dataset"] != "mixed"
].copy()

aggregate_rows = []

for scope, data in [
    ("All datasets", pair_df),
    ("Independent corpora", independent_df)
]:

    for context in TARGETS:

        subset = data[data["context"] == context]

        aggregate_rows.append({
            "scope": scope,
            "context": context,
            "pairs": len(subset),

            "mean_size_saving_pct":
                subset["size_saving_pct"].mean(),

            "median_size_saving_pct":
                subset["size_saving_pct"].median(),

            "mean_decode_saving_pct":
                subset["decode_saving_pct"].mean(),

            "median_decode_saving_pct":
                subset["decode_saving_pct"].median(),

            "mean_total_time_saving_pct":
                subset["total_time_saving_pct"].mean(),

            "mean_encode_slowdown":
                subset["encode_slowdown"].mean(),

            "size_improved": int(
                (subset["size_saving_pct"] > 0).sum()
            ),

            "decode_improved": int(
                (subset["decode_saving_pct"] > 0).sum()
            ),

            "both_improved": int(
                subset["both_improved"].sum()
            )
        })

aggregate_df = pd.DataFrame(aggregate_rows)

aggregate_df.to_csv(
    RESULTS_DIR / "stage8_aggregate_summary.csv",
    index=False
)

# ==================== PUBLICATION PLOT SETTINGS ====================

plt.rcParams.update({
    "figure.dpi": 130,
    "savefig.dpi": 300,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42
})

dataset_order = list(datasets.keys())

labels = {
    "enwik8_new": "Wikipedia",
    "english": "English",
    "python_code": "Python",
    "csv_data": "CSV",
    "vietnamese": "Vietnamese",
    "mixed": "Mixed"
}

colors = {
    64: "#2563EB",
    128: "#EA580C"
}

def save_stage8_plot(fig, name):

    fig.tight_layout()

    for ext in ["png", "pdf"]:

        fig.savefig(
            PLOTS_DIR / f"{name}.{ext}",
            bbox_inches="tight"
        )

    plt.close(fig)


def paired_bar(metric, ylabel, title, filename):

    fig, ax = plt.subplots(figsize=(9, 4.8))

    x = np.arange(len(dataset_order))
    width = 0.36

    for i, L in enumerate(TARGETS):

        subset = (
            pair_df[pair_df["context"] == L]
            .set_index("dataset")
            .loc[dataset_order]
        )

        offset = (i - 0.5) * width

        ax.bar(
            x + offset,
            subset[metric],
            width,
            color=colors[L],
            label=f"BC-{L}"
        )

    ax.set_xticks(
        x,
        [labels[n] for n in dataset_order]
    )

    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.grid(axis="y", alpha=0.25)
    ax.legend()

    save_stage8_plot(fig, filename)


# ==================== FIGURE 1 ====================

paired_bar(
    "size_saving_pct",
    "Compressed size reduction (%)",
    "Compression savings across datasets",
    "01_compression_savings"
)

# ==================== FIGURE 2 ====================

paired_bar(
    "decode_saving_pct",
    "Decode time reduction (%)",
    "Measured decoding improvements",
    "02_decode_savings"
)

# ==================== FIGURE 3 ====================

paired_bar(
    "total_time_saving_pct",
    "Total time reduction (%)",
    "End-to-end time trade-off",
    "03_total_time_savings"
)

# ==================== FIGURE 4 ====================

paired_bar(
    "encode_slowdown",
    "Adaptive / fixed encoding time",
    "Adaptive encoding overhead",
    "04_encode_overhead"
)

# ==================== FIGURE 5 ====================

paired_bar(
    "decode_memory_change_pct",
    "GPU memory change (%)",
    "Peak decoding GPU memory",
    "05_decode_memory"
)

# ==================== FIGURE 6 ====================

fig, ax = plt.subplots(figsize=(8, 6))

for L in TARGETS:

    subset = pair_df[pair_df["context"] == L]

    ax.scatter(
        subset["size_saving_pct"],
        subset["decode_saving_pct"],
        color=colors[L],
        s=70,
        label=f"BC-{L}"
    )

    for _, r in subset.iterrows():

        ax.annotate(
            f"{labels[r['dataset']]}-{L}",
            (
                r["size_saving_pct"],
                r["decode_saving_pct"]
            ),
            xytext=(5, 5),
            textcoords="offset points",
            fontsize=8
        )

ax.axhline(0, color="gray", linewidth=0.8)
ax.axvline(0, color="gray", linewidth=0.8)

ax.set_xlabel("Compressed size reduction (%)")
ax.set_ylabel("Decode time reduction (%)")
ax.set_title("Joint compression–decoding trade-off")
ax.legend()
ax.grid(alpha=0.2)

save_stage8_plot(fig, "06_joint_tradeoff")

# ==================== FIGURE 7 ====================

fig, ax = plt.subplots(figsize=(6, 6))

for family, marker in [
    ("Fixed", "o"),
    ("Adaptive", "^")
]:

    subset = final_df[
        final_df["family"] == family
    ]

    ax.scatter(
        subset["predicted_decode_s"],
        subset["decode_seconds"],
        marker=marker,
        label=family,
        alpha=0.8
    )

upper = max(
    final_df["predicted_decode_s"].max(),
    final_df["decode_seconds"].max()
) * 1.05

ax.plot(
    [0, upper],
    [0, upper],
    "--",
    color="gray",
    label="Perfect prediction"
)

ax.set_xlim(0, upper)
ax.set_ylim(0, upper)

ax.set_xlabel("Predicted decode time (s)")
ax.set_ylabel("Measured decode time (s)")
ax.set_title("Latency prediction on unseen corpora")
ax.legend()
ax.grid(alpha=0.2)

save_stage8_plot(fig, "07_latency_prediction")

# ==================== FIGURE 8 ====================

fig, axes = plt.subplots(
    2, 3,
    figsize=(12, 7)
)

for ax, name in zip(
    axes.ravel(),
    dataset_order
):

    subset = final_df[
        final_df["dataset"] == name
    ]

    for _, r in subset.iterrows():

        ax.scatter(
            r["bpb"],
            r["decode_seconds"],
            color=colors[r["context"]],
            marker=(
                "o"
                if r["family"] == "Fixed"
                else "^"
            ),
            s=60
        )

    ax.set_title(labels[name])
    ax.set_xlabel("Bits per byte")
    ax.set_ylabel("Decode time (s)")
    ax.grid(alpha=0.2)

from matplotlib.lines import Line2D

fig.legend(
    handles=[
        Line2D(
            [0], [0],
            marker="o",
            color="black",
            linestyle="None",
            label="Fixed"
        ),
        Line2D(
            [0], [0],
            marker="^",
            color="black",
            linestyle="None",
            label="Adaptive"
        ),
        Line2D(
            [0], [0],
            color=colors[64],
            label="Context 64"
        ),
        Line2D(
            [0], [0],
            color=colors[128],
            label="Context 128"
        )
    ],
    loc="upper center",
    ncol=4
)

fig.subplots_adjust(top=0.88)

save_stage8_plot(fig, "08_dataset_pareto")

# ==================== FIGURE 9 ====================

token_df = pd.read_csv(
    RESULTS_DIR / "dataset_tokenization.csv"
)

token_df = (
    token_df.set_index("dataset")
    .loc[dataset_order]
    .reset_index()
)

fig, axes = plt.subplots(
    1, 2,
    figsize=(11, 4.5)
)

axes[0].bar(
    [labels[n] for n in dataset_order],
    token_df["tokens"],
    color="#2563EB"
)

axes[0].set_ylabel("Number of GPT-2 tokens")
axes[0].set_title("Tokenizer fragmentation")

axes[1].bar(
    [labels[n] for n in dataset_order],
    token_df["token_entropy"],
    color="#0D9488"
)

axes[1].set_ylabel("Empirical entropy (bits/token)")
axes[1].set_title("Token frequency entropy")

for ax in axes:
    ax.tick_params(axis="x", rotation=30)
    ax.grid(axis="y", alpha=0.2)

save_stage8_plot(fig, "09_dataset_characteristics")

# ==================== FIGURE 10 ====================

fig, axes = plt.subplots(
    1, 2,
    figsize=(12, 4.8),
    sharey=True
)

context_levels = [32, 64, 128, 256, 512]

context_colors = [
    "#CBD5E1",
    "#2563EB",
    "#16A34A",
    "#EA580C",
    "#9333EA"
]

for ax, target in zip(axes, TARGETS):

    bottom = np.zeros(len(dataset_order))

    for L, color in zip(
        context_levels,
        context_colors
    ):

        values = []

        for name in dataset_order:

            row = final_df[
                (final_df["dataset"] == name)
                & (
                    final_df["method"]
                    == f"BC-vs-Fixed-{target}"
                )
            ].iloc[0]

            counts = row["chunk_counts"]

            count = counts.get(str(L), 0)

            values.append(
                100 * int(count) * L
                / row["padded_tokens"]
            )

        ax.bar(
            [labels[n] for n in dataset_order],
            values,
            bottom=bottom,
            color=color,
            label=str(L)
        )

        bottom += np.asarray(values)

    ax.set_title(f"BC-{target}")
    ax.tick_params(axis="x", rotation=30)
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.2)

axes[0].set_ylabel("Share of padded tokens (%)")
axes[1].legend(title="Context length")

save_stage8_plot(fig, "10_context_distribution")

# ==================== FINAL METADATA ====================

metadata = {
    "stage": "Stage 8",
    "experiment": "Multi-dataset benchmark",
    "source_commit":
        "62f09e3105296d62c39e8d95cf8b8775e63f2677",

    "datasets": 6,
    "independent_corpora": 5,
    "derived_corpora": 1,
    "total_benchmark_bytes": 600000,

    "target_contexts": TARGETS,
    "encode_configurations": 24,
    "full_decode_configurations": 24,
    "paired_comparisons": 12,
    "repeats_per_configuration": 1,

    "lossless_pass": int(
        final_df["byte_exact"].sum()
    ),

    "size_improved_pairs": int(
        (pair_df["size_saving_pct"] > 0).sum()
    ),

    "decode_improved_pairs": int(
        (pair_df["decode_saving_pct"] > 0).sum()
    ),

    "both_improved_pairs": int(
        pair_df["both_improved"].sum()
    ),

    "total_time_improved_pairs": int(
        (pair_df["total_time_saving_pct"] > 0).sum()
    ),

    "mean_size_saving_pct": float(
        pair_df["size_saving_pct"].mean()
    ),

    "mean_decode_saving_pct": float(
        pair_df["decode_saving_pct"].mean()
    ),

    "mean_prediction_error_pct": float(
        final_df["prediction_error_pct"].mean()
    ),

    "mean_encode_slowdown": float(
        pair_df["encode_slowdown"].mean()
    ),

    "measured_total_decode_hours": float(
        final_df["decode_seconds"].sum() / 3600
    ),

    "timing_limitations": [
        "One full decode measurement per configuration",
        "Small timing differences may reflect GPU variability",
        "Mixed is not an independent corpus"
    ],

    "session_id": SESSION_ID
}

(RESULTS_DIR / "stage8_metadata.json").write_text(
    json.dumps(metadata, indent=2)
)

# ==================== FINAL OUTPUT ====================

print("\n=== STAGE 8 FINAL PAIRED COMPARISON ===")

display(pair_df.round(4))

print("\n=== AGGREGATE SUMMARY ===")

display(aggregate_df.round(4))

print("\n=== STAGE 8 METADATA ===")

print(json.dumps(metadata, indent=2))

print("\n=== IDENTICAL LAYOUT CHECK ===")

display(pair_df[
    pair_df["layout_identical"]
][[
    "dataset",
    "context",
    "layout_identical",
    "artifact_identical",
    "decode_saving_pct"
]])

print("\n=== GENERATED FIGURES ===")

png_files = sorted(PLOTS_DIR.glob("*.png"))
pdf_files = sorted(PLOTS_DIR.glob("*.pdf"))

for p in sorted(PLOTS_DIR.iterdir()):

    if p.suffix in [".png", ".pdf"]:
        print(p.name)

assert len(png_files) == 10
assert len(pdf_files) == 10

print("\nPNG files: 10/10")
print("PDF files: 10/10")
print("Lossless: 24/24")
print("CELL 17 DONE")

# ==================== CELL 20 ====================
# Stage 8 — Cell 18: ZIP Final Evidence & Artifacts

import json
import hashlib
import zipfile
import shutil

from pathlib import Path
from IPython.display import FileLink, display

WORKING = Path("/kaggle/working")

EVIDENCE_ZIP = WORKING / "stage8_final_evidence.zip"
ARTIFACTS_ZIP = WORKING / "stage8_final_artifacts.zip"

# ==================== VERIFY RESULTS ====================

records = json.loads(
    (STAGE / "results/decode_benchmark.json").read_text()
)

assert len(records) == 24

assert all(
    r["full_decode"] == "PASS"
    and r["token_exact"]
    and r["byte_exact"]
    and r["sha_exact"]
    for r in records
)

print("Results: 24/24 PASS")

for r in records:

    name = r["dataset"]
    method = r["method"]

    artifact = (
        STAGE / "artifacts" /
        f"{name}_{method}.fzac"
    )

    decoded = (
        STAGE / "artifacts" /
        f"{name}_{method}_decoded.txt"
    )

    assert hashlib.sha256(
        artifact.read_bytes()
    ).hexdigest() == r["artifact_sha256"]

    assert hashlib.sha256(
        decoded.read_bytes()
    ).hexdigest() == r["original_sha256"]

print("Artifact integrity: 24/24 PASS")

# ==================== VERIFY FIGURES ====================

png_files = sorted(
    (STAGE / "plots").glob("*.png")
)

pdf_files = sorted(
    (STAGE / "plots").glob("*.pdf")
)

assert len(png_files) == 10
assert len(pdf_files) == 10

print("Figures: 20/20 PASS")

# ==================== SAVE NOTEBOOK CODE ====================

CODE_DIR = STAGE / "code"

CODE_DIR.mkdir(
    parents=True,
    exist_ok=True
)

ip = get_ipython()

history = ip.history_manager.input_hist_raw

history_path = (
    CODE_DIR / "stage8_notebook_history.py"
)

history_path.write_text(
    "\n\n".join(
        f"# ==================== CELL {i} ====================\n"
        + source
        for i, source in enumerate(history)
        if source.strip()
    ),
    encoding="utf-8"
)

# Store original source snapshots outside the repository
for filename in [
    "adaptive_context_finezip_v3.py",
    "stage5_tools.py"
]:

    source = ROOT / "update" / filename

    assert source.is_file()

    shutil.copy2(
        source,
        CODE_DIR / filename
    )

print("Notebook history: SAVED")
print("Codec source snapshots: SAVED")
print("Original source modified: False")

# ==================== ZIP FUNCTION ====================

def create_stage8_zip(zip_path, folders):

    files = []

    for folder in folders:

        directory = STAGE / folder

        assert directory.is_dir(), directory

        files.extend(
            p for p in directory.rglob("*")
            if p.is_file()
            and "__pycache__" not in p.parts
            and p.suffix != ".pyc"
        )

    files = sorted(set(files))

    assert files

    with zipfile.ZipFile(
        zip_path,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9
    ) as z:

        for path in files:

            archive_name = (
                Path("stage8") /
                path.relative_to(STAGE)
            )

            z.write(
                path,
                arcname=str(archive_name)
            )

    with zipfile.ZipFile(zip_path, "r") as z:

        assert z.testzip() is None

        names = z.namelist()

        assert len(names) == len(files)

        # Verify extracted bytes against source files
        for path in files:

            archive_name = str(
                Path("stage8") /
                path.relative_to(STAGE)
            )

            assert hashlib.sha256(
                z.read(archive_name)
            ).hexdigest() == hashlib.sha256(
                path.read_bytes()
            ).hexdigest()

    print(f"\nZIP: {zip_path.name}")
    print("Files:", len(files))

    print(
        "Size:",
        round(zip_path.stat().st_size / 1024**2, 3),
        "MB"
    )

    print(
        "SHA-256:",
        hashlib.sha256(
            zip_path.read_bytes()
        ).hexdigest()
    )

    print("Integrity: PASS")

    display(
        FileLink(zip_path.name)
    )

    return names


# ==================== EVIDENCE ZIP ====================

evidence_names = create_stage8_zip(
    EVIDENCE_ZIP,
    folders=[
        "results",
        "plots",
        "code",
        "reference"
    ]
)

assert sum(
    name.endswith(".png")
    for name in evidence_names
) == 10

assert sum(
    name.endswith(".pdf")
    for name in evidence_names
) == 10

print("PNG included: 10/10")
print("PDF included: 10/10")

# ==================== ARTIFACTS ZIP ====================

artifact_names = create_stage8_zip(
    ARTIFACTS_ZIP,
    folders=[
        "artifacts",
        "datasets"
    ]
)

assert sum(
    name.endswith(".fzac")
    for name in artifact_names
) == 24

assert sum(
    name.endswith("_decoded.txt")
    for name in artifact_names
) == 24

print("Compressed artifacts included: 24/24")
print("Decoded artifacts included: 24/24")

# ==================== FINAL STATUS ====================

print("\n=== STAGE 8 COMPLETED ===")
print("Datasets: 6/6")
print("Search configurations: 2928/2928")
print("Encode: 24/24")
print("Full decode: 24/24")
print("Lossless: 24/24")
print("Figures: 20/20")
print("ZIP archives: 2/2 PASS")
print("CELL 18 DONE")