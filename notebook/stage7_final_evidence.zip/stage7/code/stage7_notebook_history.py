# Executed input 0


# Executed input 1
#Stage 7 — Cell 1: Clone source và kiểm tra GPU
get_ipython().run_line_magic('cd', '/kaggle/working')

get_ipython().system('git clone https://github.com/ThaoTo2806/FineZip28.git')

get_ipython().system('git -C /kaggle/working/FineZip28 checkout 62f09e3105296d62c39e8d95cf8b8775e63f2677')

get_ipython().system('pip install -q transformers==5.0.0 accelerate sentencepiece')

get_ipython().system('nvidia-smi')

get_ipython().system('git -C /kaggle/working/FineZip28 rev-parse HEAD')

print("\n=== STAGE 6A INPUT ===")

get_ipython().system('find /kaggle/input -iname "stage6A_final_summary.csv"')
get_ipython().system('find /kaggle/input -iname "Adaptive-DP-1000_1mb.fzac"')

print("\nSTAGE 7 - CELL 1 DONE")

# Executed input 2
#Stage 7 — Cell 2: Kiểm tra Input và khôi phục evidence
from pathlib import Path
import json
import shutil
import hashlib
import pandas as pd
import torch
import transformers
import numpy as np

ROOT = Path("/kaggle/working/FineZip28")
INPUT = Path("/kaggle/input/datasets/thothanh28")
STAGE = Path("/kaggle/working/stage7")

for folder in [
    "code", "results", "plots", "artifacts", "reference"
]:
    (STAGE / folder).mkdir(parents=True, exist_ok=True)

print("=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)

print("\n=== STAGE 6A DATASETS ===")

for p in sorted(INPUT.glob("stage6a*")):

    print(f"\nDataset: {p.name}")

    for f in sorted(p.rglob("*")):
        if f.is_file() and f.suffix in [
            ".json", ".csv", ".zip", ".md"
        ]:
            print(f.relative_to(p), "|", f.stat().st_size, "B")

print("\n=== SEARCH FINAL EVIDENCE ===")

candidates = list(
    INPUT.rglob("stage6A_final_summary.csv")
)

if candidates:

    evidence_path = candidates[0]
    reference = evidence_path.parent

    shutil.copytree(
        reference,
        STAGE / "reference",
        dirs_exist_ok=True
    )

    stage6_df = pd.read_csv(evidence_path)

    print("Evidence found:", evidence_path)
    print("Rows:", len(stage6_df))

    display(stage6_df[[
        "method",
        "effective_L",
        "bpb",
        "decode_seconds",
        "decode_session_id"
    ]])

    print("EVIDENCE: PASS")

else:

    print("Final summary CSV not found.")
    print("Check whether stage6a-final-evidence is attached.")

print("\n=== VERIFY ORIGINAL DATA ===")

raw = (
    ROOT / "notebook/finezip_experiment2/data/baseline_1mb.txt"
).read_bytes()

original_sha = hashlib.sha256(raw).hexdigest()

print("Bytes:", len(raw))
print("SHA-256:", original_sha)

assert len(raw) == 1_000_000

assert original_sha == (
    "369b688978f649681136198fb96db14c1616756260c55fb4b65e9bc049552cad"
)

print("DATASET: PASS")
print("\nCELL 2 DONE")

# Executed input 3
#Stage 7 — Cell 2: Kiểm tra Input và khôi phục evidence
from pathlib import Path
import json
import shutil
import hashlib
import pandas as pd
import torch
import transformers
import numpy as np

ROOT = Path("/kaggle/working/FineZip28")
INPUT = Path("/kaggle/input/datasets/thothanh28")
STAGE = Path("/kaggle/working/stage7")

for folder in [
    "code", "results", "plots", "artifacts", "reference"
]:
    (STAGE / folder).mkdir(parents=True, exist_ok=True)

print("=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)

print("\n=== STAGE 6A DATASETS ===")

for p in sorted(INPUT.glob("stage6a*")):

    print(f"\nDataset: {p.name}")

    for f in sorted(p.rglob("*")):
        if f.is_file() and f.suffix in [
            ".json", ".csv", ".zip", ".md"
        ]:
            print(f.relative_to(p), "|", f.stat().st_size, "B")

print("\n=== SEARCH FINAL EVIDENCE ===")

candidates = list(
    INPUT.rglob("stage6A_final_summary.csv")
)

if candidates:

    evidence_path = candidates[0]
    reference = evidence_path.parent

    shutil.copytree(
        reference,
        STAGE / "reference",
        dirs_exist_ok=True
    )

    stage6_df = pd.read_csv(evidence_path)

    print("Evidence found:", evidence_path)
    print("Rows:", len(stage6_df))

    display(stage6_df[[
        "method",
        "effective_L",
        "bpb",
        "decode_seconds",
        "decode_session_id"
    ]])

    print("EVIDENCE: PASS")

else:

    print("Final summary CSV not found.")
    print("Check whether stage6a-final-evidence is attached.")

print("\n=== VERIFY ORIGINAL DATA ===")

raw = (
    ROOT / "notebook/finezip_experiment2/data/baseline_1mb.txt"
).read_bytes()

original_sha = hashlib.sha256(raw).hexdigest()

print("Bytes:", len(raw))
print("SHA-256:", original_sha)

assert len(raw) == 1_000_000

assert original_sha == (
    "369b688978f649681136198fb96db14c1616756260c55fb4b65e9bc049552cad"
)

print("DATASET: PASS")
print("\nCELL 2 DONE")

# Executed input 4
#Stage 7 — Cell 3: Load GPT-2 và chuẩn bị dữ liệu hiệu chuẩn
import sys
import time
import gc
import hashlib
from transformers import AutoTokenizer

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

SESSION_ID = "Stage7-Session01"

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

# ==================== TOKENIZER ====================

tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.model_max_length = 10**9

tokens = np.asarray(
    tokenizer.encode(
        raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

assert len(tokens) == 286273

assert tokenizer.decode(
    tokens.tolist(),
    clean_up_tokenization_spaces=False
).encode("utf-8") == raw

print("=== TEST DATASET ===")
print("Bytes:", len(raw))
print("Tokens:", len(tokens))
print("Byte-exact: PASS")

# ==================== CALIBRATION DATA ====================

enwik8_path = (
    ROOT / "notebook/finezip_experiment2/data/enwik8"
)

with enwik8_path.open("rb") as f:
    f.seek(2_000_000)
    calibration_raw = f.read(100_000)

calibration_raw = calibration_raw.decode(
    "utf-8", errors="ignore"
).encode("utf-8")

calibration_tokens = np.asarray(
    tokenizer.encode(
        calibration_raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

print("\n=== CALIBRATION DATASET ===")
print("Source offset:", 2_000_000)
print("Bytes:", len(calibration_raw))
print("Tokens:", len(calibration_tokens))
print("SHA-256:", hashlib.sha256(
    calibration_raw
).hexdigest())

# ==================== MODEL ====================

print("\n=== LOAD GPT-2 ===")

lm = fz.HFLM(
    name="gpt2",
    device="cuda:0",
    max_batch_tokens=1024,
    eps=None
)

cfg, env = lm.describe()

print(json.dumps(cfg, indent=2))
print(json.dumps(env, indent=2))

print("\n=== BATCH PLAN ===")

batch_plan = {
    L: lm.batch_size(L, 8)
    for L in fz.CTX_SIZES
}

print(batch_plan)

assert batch_plan == {
    32: 8,
    64: 8,
    128: 8,
    256: 4,
    512: 2
}

# ==================== SAVE METADATA ====================

metadata = {
    "session_id": SESSION_ID,
    "model_config": cfg,
    "environment": env,
    "transformers_version": transformers.__version__,
    "numpy_version": np.__version__,
    "test_bytes": len(raw),
    "test_tokens": len(tokens),
    "test_sha256": hashlib.sha256(raw).hexdigest(),
    "calibration_offset": 2_000_000,
    "calibration_bytes": len(calibration_raw),
    "calibration_tokens": len(calibration_tokens),
    "calibration_sha256": hashlib.sha256(
        calibration_raw
    ).hexdigest(),
    "batch_plan": batch_plan
}

(STAGE / "results/environment.json").write_text(
    json.dumps(metadata, indent=2)
)

np.save(
    STAGE / "artifacts/calibration_tokens.npy",
    calibration_tokens
)

print("\nGPU allocated:",
      round(torch.cuda.memory_allocated(0) / 1024**2, 2),
      "MiB")

print("\nCELL 3 DONE")

# Executed input 5
#Stage 7 — Cell 4: Đo latency giải nén thực tế
import random
import time
import gc
from datetime import datetime, timezone

REPEATS = 5
SEED = 42

rng = np.random.default_rng(SEED)

latency_path = STAGE / "results/latency_calibration.json"

latency_results = []

# ==================== PREPARE REAL TOKEN RANKS ====================

calibration_batches = {}

for L in fz.CTX_SIZES:

    B = batch_plan[L]

    starts = rng.choice(
        len(calibration_tokens) - L + 1,
        size=B,
        replace=False
    ).tolist()

    inp, tgt = fz.make_batch(
        calibration_tokens,
        starts,
        L,
        lm.bos
    )

    _, ranks, _ = lm.score(inp, tgt)

    calibration_batches[L] = {
        "starts": starts,
        "targets": tgt,
        "rank_dict": {
            s: ranks[i]
            for i, s in enumerate(starts)
        },
        "batch": B
    }

print("Calibration batches prepared: PASS")

# ==================== WARM-UP ====================

print("\n=== WARM-UP ===")

for L in fz.CTX_SIZES:

    item = calibration_batches[L]

    recovered = fz._decode_group(
        item["starts"],
        L,
        item["rank_dict"],
        {},
        lm
    )

    assert np.array_equal(
        recovered,
        item["targets"]
    ), f"Warm-up mismatch: L={L}"

    print(f"L={L:3d} | Warm-up PASS", flush=True)

# ==================== LATENCY BENCHMARK ====================

print("\n=== LATENCY BENCHMARK ===")

for repeat in range(REPEATS):

    order = list(fz.CTX_SIZES)

    random.Random(SEED + repeat).shuffle(order)

    print(
        f"\n--- Repeat {repeat + 1}/{REPEATS} ---",
        flush=True
    )

    for L in order:

        item = calibration_batches[L]

        B = item["batch"]

        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(0)
        torch.cuda.synchronize()

        t0 = time.perf_counter()

        recovered = fz._decode_group(
            item["starts"],
            L,
            item["rank_dict"],
            {},
            lm
        )

        torch.cuda.synchronize()

        elapsed = time.perf_counter() - t0

        exact = bool(np.array_equal(
            recovered,
            item["targets"]
        ))

        result = {
            "context": L,
            "batch_size": B,
            "repeat": repeat + 1,
            "batch_decode_seconds": elapsed,
            "seconds_per_chunk": elapsed / B,
            "seconds_per_token": elapsed / (B * L),
            "tokens_per_second": B * L / elapsed,
            "peak_gpu_mib": (
                torch.cuda.max_memory_allocated(0)
                / 1024**2
            ),
            "token_exact": exact,
            "session_id": SESSION_ID,
            "timestamp": datetime.now(
                timezone.utc
            ).isoformat()
        }

        latency_results.append(result)

        latency_path.write_text(
            json.dumps(latency_results, indent=2)
        )

        print(
            f"L={L:3d} | B={B} | "
            f"Batch={elapsed:.4f}s | "
            f"Chunk={elapsed/B:.4f}s | "
            f"Lossless={exact}",
            flush=True
        )

        assert exact, f"Decode mismatch at L={L}"

# ==================== STATISTICAL SUMMARY ====================

latency_df = pd.DataFrame(latency_results)

latency_df.to_csv(
    STAGE / "results/latency_calibration_raw.csv",
    index=False
)

latency_summary = (
    latency_df
    .groupby(["context", "batch_size"])
    .agg(
        repeats=("repeat", "count"),
        median_batch_s=(
            "batch_decode_seconds", "median"
        ),
        mean_batch_s=(
            "batch_decode_seconds", "mean"
        ),
        std_batch_s=(
            "batch_decode_seconds", "std"
        ),
        median_chunk_s=(
            "seconds_per_chunk", "median"
        ),
        median_token_s=(
            "seconds_per_token", "median"
        ),
        peak_gpu_mib=("peak_gpu_mib", "max"),
        lossless=("token_exact", "all")
    )
    .reset_index()
)

latency_summary["cv_pct"] = (
    100
    * latency_summary["std_batch_s"]
    / latency_summary["mean_batch_s"]
)

latency_summary.to_csv(
    STAGE / "results/latency_summary.csv",
    index=False
)

latency_summary.to_json(
    STAGE / "results/latency_summary.json",
    orient="records",
    indent=2
)

print("\n=== LATENCY CALIBRATION SUMMARY ===")

display(latency_summary.round(6))

assert len(latency_results) == 25
assert latency_df["token_exact"].all()

print("\nMeasurements: 25/25")
print("Token-exact: 25/25")
print("CELL 4 DONE")

# Executed input 6
#Stage 7 — Cell 5: Kiểm chứng mô hình chi phí giải nén
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================== LOAD LATENCY ====================

latency_summary = pd.read_csv(
    STAGE / "results/latency_summary.csv"
)

L_values = latency_summary["context"].to_numpy(
    dtype=float
)

measured = latency_summary["median_chunk_s"].to_numpy(
    dtype=float
)

# Quadratic cost cũ (Stage 5)
OLD_C = 1.02e-4

# Fit quadratic cost theo sai số tương đối
NEW_C = float(np.median(
    measured / L_values**2
))

measured_cost = {
    int(L): float(t)
    for L, t in zip(L_values, measured)
}

latency_summary["old_quadratic_s"] = (
    OLD_C * L_values**2
)

latency_summary["fitted_quadratic_s"] = (
    NEW_C * L_values**2
)

latency_summary["old_error_pct"] = (
    100 *
    np.abs(
        latency_summary["old_quadratic_s"]
        - measured
    ) / measured
)

latency_summary["fitted_error_pct"] = (
    100 *
    np.abs(
        latency_summary["fitted_quadratic_s"]
        - measured
    ) / measured
)

print("=== COST MODEL COMPARISON ===")

print("Old quadratic c:", OLD_C)
print("Fitted quadratic c:", NEW_C)

display(latency_summary[[
    "context",
    "batch_size",
    "median_chunk_s",
    "old_quadratic_s",
    "fitted_quadratic_s",
    "old_error_pct",
    "fitted_error_pct"
]].round(6))

# ==================== VALIDATE ON STAGE 6A ====================

previous_results = json.loads(
    (STAGE / "reference/decode_1mb.json").read_text()
)

prediction_rows = []

for r in previous_results:

    counts = {
        int(L): int(n)
        for L, n in r["chunk_counts"].items()
    }

    actual = float(r["decode_seconds"])

    pred_old = sum(
        n * OLD_C * L**2
        for L, n in counts.items()
    )

    pred_fitted = sum(
        n * NEW_C * L**2
        for L, n in counts.items()
    )

    pred_measured = sum(
        n * measured_cost[L]
        for L, n in counts.items()
    )

    prediction_rows.append({
        "method": r["method"],
        "actual_decode_s": actual,
        "old_quadratic_s": pred_old,
        "fitted_quadratic_s": pred_fitted,
        "measured_latency_s": pred_measured,
        "old_error_pct": (
            100 * abs(pred_old - actual) / actual
        ),
        "fitted_error_pct": (
            100 * abs(pred_fitted - actual) / actual
        ),
        "measured_error_pct": (
            100 * abs(pred_measured - actual) / actual
        ),
        "actual_session": r["decode_session_id"],
        "calibration_session": SESSION_ID
    })

prediction_df = pd.DataFrame(prediction_rows)

print("\n=== STAGE 6A LATENCY PREDICTION ===")

display(prediction_df.round(4))

# ==================== MAPE ====================

mape = {
    "old_quadratic": float(
        prediction_df["old_error_pct"].mean()
    ),
    "fitted_quadratic": float(
        prediction_df["fitted_error_pct"].mean()
    ),
    "measured_latency": float(
        prediction_df["measured_error_pct"].mean()
    )
}

print("\n=== MEAN ABSOLUTE PERCENTAGE ERROR ===")

for name, value in mape.items():
    print(f"{name:22s}: {value:.4f}%")

# ==================== SAVE RESULTS ====================

latency_summary.to_csv(
    STAGE / "results/cost_model_comparison.csv",
    index=False
)

prediction_df.to_csv(
    STAGE / "results/latency_prediction_stage6A.csv",
    index=False
)

cost_config = {
    "old_quadratic_c": OLD_C,
    "fitted_quadratic_c": NEW_C,
    "measured_chunk_seconds": measured_cost,
    "batch_plan": batch_plan,
    "mape_pct": mape,
    "calibration_session": SESSION_ID,
    "validation_data": "Stage 6A historical measurements",
    "cross_session_validation": True
}

(STAGE / "results/decode_cost_config.json").write_text(
    json.dumps(cost_config, indent=2)
)

# ==================== FIGURE 1 ====================

plt.figure(figsize=(9, 6))

plt.plot(
    L_values,
    measured,
    "o-",
    label="Measured latency"
)

plt.plot(
    L_values,
    OLD_C * L_values**2,
    "s--",
    label="Old quadratic"
)

plt.plot(
    L_values,
    NEW_C * L_values**2,
    "^--",
    label="Fitted quadratic"
)

plt.xscale("log", base=2)
plt.yscale("log")

plt.xticks(
    L_values,
    [str(int(L)) for L in L_values]
)

plt.xlabel("Context length")
plt.ylabel("Decoding time per chunk (s)")
plt.title("Decoding cost model calibration")
plt.grid(alpha=0.25)
plt.legend()
plt.tight_layout()

for ext in ["png", "pdf"]:
    plt.savefig(
        STAGE / "plots" /
        f"01_latency_cost_calibration.{ext}",
        dpi=300,
        bbox_inches="tight"
    )

plt.show()
plt.close()

# ==================== FIGURE 2 ====================

plt.figure(figsize=(10, 6))

for column, label, marker in [
    ("old_quadratic_s", "Old quadratic", "s"),
    ("fitted_quadratic_s", "Fitted quadratic", "^"),
    ("measured_latency_s", "Measured latency", "o")
]:
    plt.scatter(
        prediction_df["actual_decode_s"],
        prediction_df[column],
        label=label,
        marker=marker,
        s=60
    )

max_time = max(
    prediction_df["actual_decode_s"].max(),
    prediction_df[[
        "old_quadratic_s",
        "fitted_quadratic_s",
        "measured_latency_s"
    ]].to_numpy().max()
)

plt.plot(
    [0, max_time],
    [0, max_time],
    "k--",
    label="Ideal prediction"
)

plt.xlabel("Historical decoding time (s)")
plt.ylabel("Predicted decoding time (s)")
plt.title("Cross-session decoding latency prediction")
plt.legend()
plt.grid(alpha=0.25)
plt.tight_layout()

for ext in ["png", "pdf"]:
    plt.savefig(
        STAGE / "plots" /
        f"02_latency_prediction.{ext}",
        dpi=300,
        bbox_inches="tight"
    )

plt.show()
plt.close()

print("\nCost models saved: PASS")
print("Figures saved: 4/4")
print("CELL 5 DONE")

# Executed input 7
#Stage 7 — Cell 6: Xây dựng cache phân tích context
import time
import json
import numpy as np
import pandas as pd
from pathlib import Path

CACHE_PATH = STAGE / "artifacts/calibration_analysis.npz"

calibration_pad = fz.pad_tokens(
    calibration_tokens,
    lm.bos
)

print("=== CALIBRATION DATA ===")
print("Original tokens:", len(calibration_tokens))
print("Padded tokens:", len(calibration_pad))

# ==================== ANALYZE CONTEXT ====================

torch.cuda.synchronize()

t0 = time.perf_counter()

analysis_cal = s5.analyze(
    calibration_pad,
    lm,
    batch=8,
    levels=fz.CTX_SIZES
)

torch.cuda.synchronize()

analysis_seconds = time.perf_counter() - t0

# ==================== VALIDATE CACHE ====================

cache = {}
analysis_rows = []

for L in fz.CTX_SIZES:

    bits = np.asarray(analysis_cal[L]["bits"])
    ranks = np.asarray(analysis_cal[L]["ranks"])

    expected_chunks = len(calibration_pad) // L

    assert bits.shape == (expected_chunks,)
    assert ranks.shape == (expected_chunks, L)
    assert np.isfinite(bits).all()
    assert (bits >= 0).all()
    assert (ranks >= 0).all()
    assert (ranks < lm.V).all()

    cache[f"bits_{L}"] = bits
    cache[f"ranks_{L}"] = ranks

    analysis_rows.append({
        "context": L,
        "chunks": expected_chunks,
        "scored_tokens": ranks.size,
        "total_nll_bits": float(bits.sum()),
        "mean_bits_per_token": (
            float(bits.sum()) / ranks.size
        ),
        "mean_rank": float(ranks.mean()),
        "median_rank": float(np.median(ranks)),
        "top1_accuracy_pct": (
            100 * float((ranks == 0).mean())
        )
    })

    print(
        f"PASS | L={L:3d} | "
        f"Chunks={expected_chunks:5d} | "
        f"Ranks shape={ranks.shape}"
    )

# ==================== SAVE CACHE ====================

np.savez_compressed(
    CACHE_PATH,
    **cache
)

# ==================== SAVE SUMMARY ====================

analysis_df = pd.DataFrame(analysis_rows)

analysis_df.to_csv(
    STAGE / "results/calibration_analysis.csv",
    index=False
)

cache_metadata = {
    "session_id": SESSION_ID,
    "analysis_seconds": analysis_seconds,
    "calibration_tokens": len(calibration_tokens),
    "padded_tokens": len(calibration_pad),
    "calibration_sha256": hashlib.sha256(
        calibration_raw
    ).hexdigest(),
    "cache_sha256": hashlib.sha256(
        CACHE_PATH.read_bytes()
    ).hexdigest(),
    "model_config": cfg,
    "batch_plan": batch_plan,
    "context_sizes": list(fz.CTX_SIZES)
}

(STAGE / "results/calibration_cache_metadata.json").write_text(
    json.dumps(cache_metadata, indent=2)
)

print("\n=== ANALYSIS SUMMARY ===")

display(analysis_df.round(4))

print("\nAnalysis time:", round(analysis_seconds, 3), "s")
print("Cache size:", round(
    CACHE_PATH.stat().st_size / 1024**2, 4
), "MiB")

print("Cache saved:", CACHE_PATH)
print("CACHE VALIDATION: PASS")
print("CELL 6 DONE")

# Executed input 8
#Stage 7 — Cell 7: Quét hàm mục tiêu Decode-Aware DP
import bz2
import json
import time
import hashlib
import numpy as np
import pandas as pd

# ==================== LOAD COST CONFIG ====================

cost_config = json.loads(
    (STAGE / "results/decode_cost_config.json").read_text()
)

OLD_C = cost_config["old_quadratic_c"]
NEW_C = cost_config["fitted_quadratic_c"]

measured_cost = {
    int(k): float(v)
    for k, v in cost_config[
        "measured_chunk_seconds"
    ].items()
}

LEVELS = list(fz.CTX_SIZES)

# ==================== COMPRESSION OBJECTIVES ====================

cost_nll = s5.cost_ac(analysis_cal)

cost_rank = s5.cost_rank_proxy(
    analysis_cal,
    ref=128
)

objectives = {
    "NLL": cost_nll,
    "Rank": cost_rank
}

# ==================== DECODING OBJECTIVES ====================

time_models = {
    "Old": lambda L: OLD_C * L**2,
    "Fitted": lambda L: NEW_C * L**2,
    "Measured": lambda L: measured_cost[L]
}

# ==================== CACHE-BASED EVALUATION ====================

def evaluate_cached_layout(leaves, analysis, n_pad):

    # Chỉ đánh giá layout hợp lệ
    cursor = 0
    counts = {L: 0 for L in LEVELS}
    rank_parts = []

    for start, L in leaves:

        assert start == cursor
        assert L in LEVELS
        assert start % L == 0
        assert start + L <= n_pad

        rank_parts.append(
            analysis[L]["ranks"][start // L]
        )

        counts[L] += 1
        cursor += L

    assert cursor == n_pad

    ranks = np.concatenate(rank_parts).astype("<u2")

    assert len(ranks) == n_pad

    # BZip2 trên rank stream lấy từ cache
    payload = bz2.compress(
        ranks.tobytes(),
        compresslevel=9
    )

    flags = fz.layout_to_flags(
        leaves,
        n_pad
    )

    layout_bytes = (len(flags) + 7) // 8

    # Chưa bao gồm header cố định của codec
    proxy_bytes = len(payload) + layout_bytes

    predicted_decode = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    effective_L = (
        sum(counts[L] * L**2 for L in LEVELS)
        / n_pad
    )

    layout_hash = hashlib.sha256(
        np.asarray(
            leaves,
            dtype=np.int64
        ).tobytes()
    ).hexdigest()

    return {
        "payload_bytes": len(payload),
        "layout_bytes": layout_bytes,
        "estimated_variable_bytes": proxy_bytes,
        "estimated_bpb": (
            8 * proxy_bytes / len(calibration_raw)
        ),
        "predicted_decode_s": predicted_decode,
        "effective_L": effective_L,
        "chunk_counts": counts,
        "layout_sha256": layout_hash
    }


# ==================== FIXED BASELINES ====================

print("=== CALIBRATION FIXED BASELINES ===")

fixed_rows = []

for L in LEVELS:

    leaves = fz.FixedPolicy(L)(
        calibration_pad,
        lm,
        8
    )

    result = evaluate_cached_layout(
        leaves,
        analysis_cal,
        len(calibration_pad)
    )

    fixed_rows.append({
        "method": f"Fixed-{L}",
        "family": "Fixed",
        "lambda": None,
        **result
    })

fixed_df = pd.DataFrame(fixed_rows)

display(fixed_df[[
    "method",
    "estimated_variable_bytes",
    "estimated_bpb",
    "predicted_decode_s",
    "effective_L"
]].round(4))


# ==================== LAMBDA SWEEP ====================

LAMBDAS = np.geomspace(
    0.1,
    1000,
    25
)

sweep_rows = []
layout_cache = {}

t0 = time.perf_counter()

print("\n=== DECODE-AWARE DP SWEEP ===")

for objective_name, objective_cost in objectives.items():

    for time_name, time_fn in time_models.items():

        method = f"{objective_name}-{time_name}"

        for lam in LAMBDAS:

            policy = s5.TreeDP(
                cost=objective_cost,
                lam=float(lam),
                t_chunk=time_fn
            )

            leaves = policy(calibration_pad)

            layout_key = hashlib.sha256(
                np.asarray(
                    leaves,
                    dtype=np.int64
                ).tobytes()
            ).hexdigest()

            if layout_key not in layout_cache:

                layout_cache[layout_key] = (
                    evaluate_cached_layout(
                        leaves,
                        analysis_cal,
                        len(calibration_pad)
                    )
                )

            result = layout_cache[layout_key]

            sweep_rows.append({
                "method": method,
                "family": "Adaptive",
                "compression_objective": objective_name,
                "decode_objective": time_name,
                "lambda": float(lam),
                **result
            })

        print(
            f"PASS | {method:20s} | "
            f"{len(LAMBDAS)} configurations",
            flush=True
        )

sweep_seconds = time.perf_counter() - t0

sweep_df = pd.DataFrame(sweep_rows)

# ==================== SAVE RESULTS ====================

fixed_df.to_csv(
    STAGE / "results/calibration_fixed_proxy.csv",
    index=False
)

sweep_df.to_csv(
    STAGE / "results/calibration_dp_sweep.csv",
    index=False
)

(STAGE / "results/calibration_dp_sweep.json").write_text(
    json.dumps(sweep_rows, indent=2)
)

# ==================== UNIQUE LAYOUTS ====================

print("\n=== SWEEP SUMMARY ===")

summary = (
    sweep_df
    .groupby("method")
    .agg(
        configurations=("lambda", "count"),
        unique_layouts=("layout_sha256", "nunique"),
        min_bytes=("estimated_variable_bytes", "min"),
        max_bytes=("estimated_variable_bytes", "max"),
        min_decode_s=("predicted_decode_s", "min"),
        max_decode_s=("predicted_decode_s", "max"),
        min_effective_L=("effective_L", "min"),
        max_effective_L=("effective_L", "max")
    )
    .reset_index()
)

display(summary.round(4))

summary.to_csv(
    STAGE / "results/calibration_sweep_summary.csv",
    index=False
)

print("\nTotal configurations:", len(sweep_df))
print("Unique adaptive layouts:", len(layout_cache))
print("Sweep time:", round(sweep_seconds, 2), "s")

assert len(sweep_df) == 150

print("SWEEP: PASS")
print("CELL 7 DONE")

# Executed input 9
#Stage 7 — Cell 8: Phân tích Pareto và lựa chọn ứng viên
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json

# ==================== COMBINE RESULTS ====================

all_df = pd.concat(
    [fixed_df, sweep_df],
    ignore_index=True
)

def pareto_mask(data):

    x = data["predicted_decode_s"].to_numpy()
    y = data["estimated_variable_bytes"].to_numpy()

    return [
        not np.any(
            (x <= x[i])
            & (y <= y[i])
            & ((x < x[i]) | (y < y[i]))
        )
        for i in range(len(data))
    ]

all_df["proxy_pareto"] = pareto_mask(all_df)

# Loại các layout trùng nhau khi thống kê
unique_df = all_df.drop_duplicates(
    subset=["layout_sha256"]
).copy()

pareto_df = unique_df[
    unique_df["proxy_pareto"]
].sort_values("predicted_decode_s")

print("=== UNIQUE PARETO LAYOUTS ===")

display(pareto_df[[
    "method",
    "lambda",
    "estimated_variable_bytes",
    "estimated_bpb",
    "predicted_decode_s",
    "effective_L"
]].round(4))

# ==================== MATCHED LATENCY BUDGET ====================

targets = fixed_df[
    fixed_df["method"].isin([
        "Fixed-64",
        "Fixed-128",
        "Fixed-256",
        "Fixed-512"
    ])
]

matched_rows = []

for _, baseline in targets.iterrows():

    budget = float(
        baseline["predicted_decode_s"]
    )

    baseline_bytes = int(
        baseline["estimated_variable_bytes"]
    )

    for method in sorted(
        sweep_df["method"].unique()
    ):

        candidates = sweep_df[
            (sweep_df["method"] == method)
            & (
                sweep_df["predicted_decode_s"]
                <= budget
            )
        ]

        if candidates.empty:
            continue

        best = candidates.sort_values(
            [
                "estimated_variable_bytes",
                "predicted_decode_s"
            ]
        ).iloc[0]

        matched_rows.append({
            "baseline": baseline["method"],
            "method": method,
            "lambda": float(best["lambda"]),
            "budget_seconds": budget,
            "predicted_decode_s": float(
                best["predicted_decode_s"]
            ),
            "baseline_bytes": baseline_bytes,
            "adaptive_bytes": int(
                best["estimated_variable_bytes"]
            ),
            "size_saving_pct": (
                100 * (
                    baseline_bytes
                    - best["estimated_variable_bytes"]
                ) / baseline_bytes
            ),
            "budget_used_pct": (
                100 * best["predicted_decode_s"]
                / budget
            ),
            "effective_L": float(
                best["effective_L"]
            ),
            "layout_sha256": best["layout_sha256"]
        })

matched_df = pd.DataFrame(matched_rows)

print("\n=== MATCHED LATENCY BUDGET ===")

display(
    matched_df.drop(
        columns=["layout_sha256"]
    ).round(4)
)

# ==================== BEST CANDIDATE PER BUDGET ====================

best_df = (
    matched_df
    .sort_values(
        [
            "baseline",
            "adaptive_bytes",
            "predicted_decode_s"
        ]
    )
    .groupby("baseline", as_index=False)
    .first()
)

print("\n=== BEST CANDIDATES ===")

display(
    best_df.drop(
        columns=["layout_sha256"]
    ).round(4)
)

# ==================== SAVE ====================

all_df.to_csv(
    STAGE / "results/calibration_pareto_all.csv",
    index=False
)

pareto_df.to_csv(
    STAGE / "results/calibration_pareto_front.csv",
    index=False
)

matched_df.to_csv(
    STAGE / "results/matched_latency_comparison.csv",
    index=False
)

best_df.to_csv(
    STAGE / "results/best_candidates.csv",
    index=False
)

best_df.to_json(
    STAGE / "results/best_candidates.json",
    orient="records",
    indent=2
)

# ==================== FIGURE 3 ====================

plt.figure(figsize=(11, 7))

for method, group in sweep_df.groupby("method"):

    group = group.sort_values(
        "predicted_decode_s"
    )

    plt.plot(
        group["predicted_decode_s"],
        group["estimated_bpb"],
        marker=".",
        markersize=4,
        alpha=0.7,
        label=method
    )

plt.scatter(
    fixed_df["predicted_decode_s"],
    fixed_df["estimated_bpb"],
    color="black",
    marker="D",
    s=65,
    label="Fixed Context",
    zorder=5
)

plt.xlabel("Predicted decoding time (s)")
plt.ylabel("Estimated BPB")
plt.title(
    "Calibration Pareto comparison\n"
    "Cached rank stream and predicted latency"
)

plt.grid(alpha=0.25)
plt.legend(fontsize=9)
plt.tight_layout()

for ext in ["png", "pdf"]:

    plt.savefig(
        STAGE / "plots" /
        f"03_calibration_pareto.{ext}",
        dpi=300,
        bbox_inches="tight"
    )

plt.show()
plt.close()

print("\n=== FINAL SCREENING STATUS ===")

print("Unique layouts:", len(unique_df))
print("Pareto layouts:", len(pareto_df))
print("Matched comparisons:", len(matched_df))

print(
    "Positive saving configurations:",
    int((matched_df["size_saving_pct"] > 0).sum())
)

print(
    "Best compression saving:",
    round(matched_df["size_saving_pct"].max(), 4),
    "%"
)

print("CELL 8 DONE")

# Executed input 10
#Stage 7 — Cell 9: Independent Validation và Encode thực tế
import time
import json
import hashlib
import numpy as np
import pandas as pd

# ==================== INDEPENDENT VALIDATION DATA ====================

VALIDATION_OFFSET = 3_000_000
VALIDATION_SIZE = 100_000

with enwik8_path.open("rb") as f:
    f.seek(VALIDATION_OFFSET)
    validation_raw = f.read(VALIDATION_SIZE)

validation_raw = validation_raw.decode(
    "utf-8", errors="ignore"
).encode("utf-8")

validation_tokens = np.asarray(
    tokenizer.encode(
        validation_raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

validation_pad = fz.pad_tokens(
    validation_tokens,
    lm.bos
)

assert tokenizer.decode(
    validation_tokens.tolist(),
    clean_up_tokenization_spaces=False
).encode("utf-8") == validation_raw

print("=== INDEPENDENT VALIDATION DATASET ===")
print("Offset:", VALIDATION_OFFSET)
print("Bytes:", len(validation_raw))
print("Tokens:", len(validation_tokens))
print("SHA-256:", hashlib.sha256(
    validation_raw
).hexdigest())

# ==================== FREEZE SELECTED CONFIGURATIONS ====================

selected = pd.read_csv(
    STAGE / "results/best_candidates.csv"
)

print("\n=== FROZEN CANDIDATES ===")

display(selected[[
    "baseline",
    "method",
    "lambda",
    "size_saving_pct"
]])

# ==================== VALIDATION ANALYSIS ====================

torch.cuda.synchronize()
t0 = time.perf_counter()

analysis_val = s5.analyze(
    validation_pad,
    lm,
    batch=8,
    levels=fz.CTX_SIZES
)

torch.cuda.synchronize()

validation_analysis_seconds = (
    time.perf_counter() - t0
)

print(
    "\nValidation analysis:",
    round(validation_analysis_seconds, 3),
    "s"
)

# ==================== NLL OBJECTIVE ====================

val_cost_nll = s5.cost_ac(analysis_val)

# ==================== FROZEN RANK PROXY ====================

# Histogram phải học từ calibration,
# KHÔNG fit lại trên validation.

RMAX = 4096
ALPHA = 0.5

reference_ranks = np.minimum(
    analysis_cal[128]["ranks"].ravel(),
    RMAX
)

hist = np.bincount(
    reference_ranks,
    minlength=RMAX + 1
).astype(float)

rank_table = -np.log2(
    (hist + ALPHA) /
    (hist.sum() + ALPHA * (RMAX + 1))
)

val_cost_rank = {}

for L in fz.CTX_SIZES:

    ranks = analysis_val[L]["ranks"]

    tail = np.where(
        ranks >= RMAX,
        np.log2(np.maximum(ranks, 1)),
        0.0
    )

    val_cost_rank[L] = (
        rank_table[
            np.minimum(ranks, RMAX)
        ].sum(axis=1)
        + tail.sum(axis=1)
    )

val_objectives = {
    "NLL": val_cost_nll,
    "Rank": val_cost_rank
}

# Lưu proxy để tái sử dụng
np.save(
    STAGE / "artifacts/frozen_rank_table.npy",
    rank_table
)

# ==================== ENCODE FUNCTION ====================

validation_results = []

def encode_validation(
    name,
    policy,
    family,
    baseline,
    lam=None,
    objective=None,
    decode_objective=None
):

    print(f"\n=== ENCODE: {name} ===", flush=True)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        validation_tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    encode_s = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    counts = {
        L: sum(l == L for _, l in leaves)
        for L in fz.CTX_SIZES
    }

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in fz.CTX_SIZES
    )

    effective_L = (
        sum(L**2 for _, L in leaves)
        / sum(L for _, L in leaves)
    )

    artifact_path = (
        STAGE / "artifacts"
        / f"validation_{name}.fzac"
    )

    artifact_path.write_bytes(blob)

    result = {
        "method": name,
        "family": family,
        "baseline": baseline,
        "lambda": lam,
        "compression_objective": objective,
        "decode_objective": decode_objective,
        "original_bytes": len(validation_raw),
        "tokens": len(validation_tokens),
        "original_sha256": hashlib.sha256(
            validation_raw
        ).hexdigest(),
        "compressed_bytes": len(blob),
        "ratio": len(validation_raw) / len(blob),
        "bpb": 8 * len(blob) / len(validation_raw),
        "encode_seconds": encode_s,
        "analysis_seconds": (
            validation_analysis_seconds
            if family == "Adaptive" else 0.0
        ),
        "encode_peak_mib": peak_mib,
        "predicted_decode_s": predicted_decode_s,
        "effective_L": effective_L,
        "chunk_counts": counts,
        "artifact_sha256": hashlib.sha256(
            blob
        ).hexdigest(),
        "encode_stats": dict(fz.encode.last_stats),
        "session_id": SESSION_ID,
        "full_decode": "PENDING"
    }

    validation_results.append(result)

    (
        STAGE / "results/validation_encode.json"
    ).write_text(
        json.dumps(validation_results, indent=2)
    )

    print("Compressed bytes:", len(blob))
    print("BPB:", round(result["bpb"], 6))
    print("Encode:", round(encode_s, 3), "s")
    print(
        "Predicted decode:",
        round(predicted_decode_s, 3),
        "s"
    )

    return result

# ==================== FIXED BASELINES ====================

for L in [64, 128, 256, 512]:

    encode_validation(
        name=f"Fixed-{L}",
        policy=fz.FixedPolicy(L),
        family="Fixed",
        baseline=f"Fixed-{L}"
    )

# ==================== FROZEN ADAPTIVE CANDIDATES ====================

for _, row in selected.iterrows():

    objective_name, time_name = (
        row["method"].split("-")
    )

    lam = float(row["lambda"])
    baseline = row["baseline"]

    policy = s5.TreeDP(
        cost=val_objectives[objective_name],
        lam=lam,
        t_chunk=time_models[time_name]
    )

    name = (
        f"DA-{objective_name}-{time_name}"
        f"-vs-{baseline}"
    )

    encode_validation(
        name=name,
        policy=policy,
        family="Adaptive",
        baseline=baseline,
        lam=lam,
        objective=objective_name,
        decode_objective=time_name
    )

# ==================== COMPARISON ====================

val_df = pd.DataFrame(validation_results)

comparison_rows = []

for _, r in val_df[
    val_df["family"] == "Adaptive"
].iterrows():

    baseline = val_df[
        val_df["method"] == r["baseline"]
    ].iloc[0]

    comparison_rows.append({
        "baseline": baseline["method"],
        "adaptive": r["method"],
        "lambda": r["lambda"],
        "fixed_bytes": baseline["compressed_bytes"],
        "adaptive_bytes": r["compressed_bytes"],
        "size_saving_pct": 100 * (
            baseline["compressed_bytes"]
            - r["compressed_bytes"]
        ) / baseline["compressed_bytes"],
        "fixed_pred_decode_s": baseline[
            "predicted_decode_s"
        ],
        "adaptive_pred_decode_s": r[
            "predicted_decode_s"
        ],
        "pred_decode_saving_pct": 100 * (
            baseline["predicted_decode_s"]
            - r["predicted_decode_s"]
        ) / baseline["predicted_decode_s"],
        "adaptive_effective_L": r["effective_L"]
    })

val_compare = pd.DataFrame(comparison_rows)

val_df.to_csv(
    STAGE / "results/validation_encode.csv",
    index=False
)

val_compare.to_csv(
    STAGE / "results/validation_comparison.csv",
    index=False
)

print("\n=== VALIDATION ENCODE SUMMARY ===")

display(val_df[[
    "method",
    "compressed_bytes",
    "ratio",
    "bpb",
    "encode_seconds",
    "predicted_decode_s",
    "effective_L"
]].round(4))

print("\n=== INDEPENDENT VALIDATION COMPARISON ===")

display(val_compare.round(4))

assert len(validation_results) == 8

print("\nEncode: 8/8")
print("Independent validation: PASS")
print("CELL 9 DONE")

# Executed input 11
#Stage 7 — Cell 10: Budget-Constrained Search
import numpy as np
import pandas as pd
import json
import bz2
import hashlib
import time

# ==================== CONFIGURATION ====================

TARGETS = [64, 128, 256, 512]

DENSE_LAMBDAS = np.concatenate([
    [0.0],
    np.geomspace(0.01, 10000, 121)
])

print("Lambda candidates:", len(DENSE_LAMBDAS))

# ==================== ESTIMATE LAYOUT ====================

def evaluate_budget_layout(leaves, analysis, n_pad):

    cursor = 0

    rank_parts = []

    counts = {
        L: 0 for L in fz.CTX_SIZES
    }

    for start, L in leaves:

        assert start == cursor
        assert start + L <= n_pad

        rank_parts.append(
            analysis[L]["ranks"][start // L]
        )

        counts[L] += 1
        cursor += L

    assert cursor == n_pad

    ranks = np.concatenate(
        rank_parts
    ).astype("<u2")

    payload_bytes = len(
        bz2.compress(
            ranks.tobytes(),
            compresslevel=9
        )
    )

    flags = fz.layout_to_flags(
        leaves,
        n_pad
    )

    layout_bytes = (
        len(flags) + 7
    ) // 8

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in fz.CTX_SIZES
    )

    key = hashlib.sha256(
        np.asarray(
            leaves,
            dtype=np.int64
        ).tobytes()
    ).hexdigest()

    return {
        "layout_sha256": key,
        "payload_bytes": payload_bytes,
        "layout_bytes": layout_bytes,
        "variable_bytes": (
            payload_bytes + layout_bytes
        ),
        "predicted_decode_s": predicted_decode_s,
        "effective_L": (
            sum(
                counts[L] * L**2
                for L in fz.CTX_SIZES
            ) / n_pad
        ),
        "chunk_counts": counts
    }


# ==================== FIXED REFERENCE ====================

fixed_reference = {}

for L in TARGETS:

    leaves = fz.FixedPolicy(L)(
        validation_pad,
        lm,
        8
    )

    fixed_reference[L] = evaluate_budget_layout(
        leaves,
        analysis_val,
        len(validation_pad)
    )

# ==================== DENSE CANDIDATE SEARCH ====================

search_rows = []
search_layouts = {}
evaluated_layouts = {}

t0 = time.perf_counter()

for objective_name, objective_cost in val_objectives.items():

    for time_name in ["Fitted", "Measured"]:

        for lam in DENSE_LAMBDAS:

            policy = s5.TreeDP(
                cost=objective_cost,
                lam=float(lam),
                t_chunk=time_models[time_name]
            )

            leaves = policy(validation_pad)

            key = hashlib.sha256(
                np.asarray(
                    leaves,
                    dtype=np.int64
                ).tobytes()
            ).hexdigest()

            if key not in evaluated_layouts:

                evaluated_layouts[key] = (
                    evaluate_budget_layout(
                        leaves,
                        analysis_val,
                        len(validation_pad)
                    )
                )

                search_layouts[key] = leaves

            search_rows.append({
                "objective": objective_name,
                "time_model": time_name,
                "lambda": float(lam),
                **evaluated_layouts[key]
            })

        print(
            f"PASS | {objective_name}-{time_name}",
            flush=True
        )

search_seconds = time.perf_counter() - t0

search_df = pd.DataFrame(search_rows)

# ==================== SELECT AT FIXED BUDGET ====================

budget_results = []

for L in TARGETS:

    ref = fixed_reference[L]

    budget = ref["predicted_decode_s"]

    candidates = search_df[
        search_df["predicted_decode_s"] <= budget
    ].copy()

    assert not candidates.empty

    best = candidates.sort_values([
        "variable_bytes",
        "predicted_decode_s"
    ]).iloc[0]

    budget_results.append({
        "baseline": f"Fixed-{L}",
        "selected_objective": best["objective"],
        "selected_time_model": best["time_model"],
        "selected_lambda": float(best["lambda"]),
        "fixed_variable_bytes": ref["variable_bytes"],
        "adaptive_variable_bytes": int(
            best["variable_bytes"]
        ),
        "size_saving_pct": 100 * (
            ref["variable_bytes"]
            - best["variable_bytes"]
        ) / ref["variable_bytes"],
        "fixed_budget_s": budget,
        "adaptive_pred_decode_s": float(
            best["predicted_decode_s"]
        ),
        "pred_decode_saving_pct": 100 * (
            budget - best["predicted_decode_s"]
        ) / budget,
        "budget_used_pct": (
            100 * best["predicted_decode_s"]
            / budget
        ),
        "effective_L": float(best["effective_L"]),
        "layout_sha256": best["layout_sha256"]
    })

budget_df = pd.DataFrame(budget_results)

# ==================== SAVE SELECTED LAYOUTS ====================

selected_layouts = {}

for r in budget_results:

    key = r["layout_sha256"]

    selected_layouts[
        r["baseline"]
    ] = [
        [int(s), int(L)]
        for s, L in search_layouts[key]
    ]

(STAGE / "artifacts/budget_selected_layouts.json").write_text(
    json.dumps(selected_layouts, indent=2)
)

search_df.to_csv(
    STAGE / "results/budget_search_all.csv",
    index=False
)

budget_df.to_csv(
    STAGE / "results/budget_search_best.csv",
    index=False
)

(STAGE / "results/budget_search_best.json").write_text(
    json.dumps(budget_results, indent=2)
)

# ==================== SUMMARY ====================

print("\n=== BUDGET SEARCH RESULTS ===")

display(
    budget_df.drop(
        columns=["layout_sha256"]
    ).round(4)
)

print("\n=== SEARCH SUMMARY ===")

print("Evaluated configurations:", len(search_df))
print("Unique layouts:", len(evaluated_layouts))
print("Search time:", round(search_seconds, 3), "s")

print(
    "Positive compression savings:",
    int((budget_df["size_saving_pct"] > 0).sum()),
    "/ 4"
)

print(
    "Best size saving:",
    round(budget_df["size_saving_pct"].max(), 4),
    "%"
)

print("CELL 10 DONE")

# Executed input 12
#Stage 7 — Cell 11: Held-out Test
import time
import gc
import json
import hashlib
import numpy as np
import pandas as pd

# ==================== HELD-OUT DATASET ====================

HELDOUT_OFFSET = 4_000_000
HELDOUT_SIZE = 100_000

with enwik8_path.open("rb") as f:
    f.seek(HELDOUT_OFFSET)
    heldout_raw = f.read(HELDOUT_SIZE)

heldout_raw = heldout_raw.decode(
    "utf-8", errors="ignore"
).encode("utf-8")

heldout_tokens = np.asarray(
    tokenizer.encode(
        heldout_raw.decode("utf-8"),
        add_special_tokens=False
    ),
    dtype=np.int64
)

heldout_pad = fz.pad_tokens(
    heldout_tokens,
    lm.bos
)

assert tokenizer.decode(
    heldout_tokens.tolist(),
    clean_up_tokenization_spaces=False
).encode("utf-8") == heldout_raw

heldout_sha = hashlib.sha256(
    heldout_raw
).hexdigest()

print("=== HELD-OUT DATASET ===")
print("Offset:", HELDOUT_OFFSET)
print("Bytes:", len(heldout_raw))
print("Tokens:", len(heldout_tokens))
print("SHA-256:", heldout_sha)

# ==================== CONTEXT ANALYSIS ====================

torch.cuda.reset_peak_memory_stats(0)
torch.cuda.synchronize()

t0 = time.perf_counter()

analysis_test = s5.analyze(
    heldout_pad,
    lm,
    batch=8,
    levels=fz.CTX_SIZES
)

torch.cuda.synchronize()

test_analysis_seconds = (
    time.perf_counter() - t0
)

test_analysis_peak = (
    torch.cuda.max_memory_allocated(0) / 1024**2
)

print(
    "Analysis time:",
    round(test_analysis_seconds, 3),
    "s"
)

# ==================== FROZEN OBJECTIVES ====================

test_cost_nll = s5.cost_ac(analysis_test)

test_cost_rank = {}

for L in fz.CTX_SIZES:

    ranks = analysis_test[L]["ranks"]

    tail = np.where(
        ranks >= RMAX,
        np.log2(np.maximum(ranks, 1)),
        0.0
    )

    test_cost_rank[L] = (
        rank_table[
            np.minimum(ranks, RMAX)
        ].sum(axis=1)
        + tail.sum(axis=1)
    )

test_objectives = {
    "NLL": test_cost_nll,
    "Rank": test_cost_rank
}

# ==================== FIXED REFERENCE ====================

test_fixed = {}

for L in TARGETS:

    leaves = fz.FixedPolicy(L)(
        heldout_pad, lm, 8
    )

    test_fixed[L] = evaluate_budget_layout(
        leaves,
        analysis_test,
        len(heldout_pad)
    )

# ==================== FROZEN BUDGET SEARCH ====================

test_search_rows = []
test_search_layouts = {}
test_evaluated = {}

t0 = time.perf_counter()

for objective_name, cost in test_objectives.items():

    for time_name in ["Fitted", "Measured"]:

        for lam in DENSE_LAMBDAS:

            policy = s5.TreeDP(
                cost=cost,
                lam=float(lam),
                t_chunk=time_models[time_name]
            )

            leaves = policy(heldout_pad)

            key = hashlib.sha256(
                np.asarray(
                    leaves, dtype=np.int64
                ).tobytes()
            ).hexdigest()

            if key not in test_evaluated:

                test_evaluated[key] = (
                    evaluate_budget_layout(
                        leaves,
                        analysis_test,
                        len(heldout_pad)
                    )
                )

                test_search_layouts[key] = leaves

            test_search_rows.append({
                "objective": objective_name,
                "time_model": time_name,
                "lambda": float(lam),
                **test_evaluated[key]
            })

        print(
            f"PASS | {objective_name}-{time_name}",
            flush=True
        )

test_search_seconds = (
    time.perf_counter() - t0
)

test_search_df = pd.DataFrame(
    test_search_rows
)

test_search_df.to_csv(
    STAGE / "results/heldout_search_all.csv",
    index=False
)

# ==================== SELECT BY DECODE BUDGET ====================

test_selected = []

for L in TARGETS:

    ref = test_fixed[L]

    feasible = test_search_df[
        test_search_df["predicted_decode_s"]
        <= ref["predicted_decode_s"]
    ]

    assert not feasible.empty

    best = feasible.sort_values([
        "variable_bytes",
        "predicted_decode_s"
    ]).iloc[0]

    test_selected.append({
        "baseline": f"Fixed-{L}",
        "objective": best["objective"],
        "time_model": best["time_model"],
        "lambda": float(best["lambda"]),
        "layout_sha256": best["layout_sha256"],
        "fixed_proxy_bytes": ref["variable_bytes"],
        "adaptive_proxy_bytes": int(
            best["variable_bytes"]
        ),
        "predicted_budget_s": ref[
            "predicted_decode_s"
        ]
    })

# ==================== REAL CODEC ENCODE ====================

heldout_results = []

def encode_heldout(
    name,
    policy,
    family,
    baseline,
    selection=None
):

    print(f"\n=== ENCODE: {name} ===", flush=True)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        heldout_tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    encode_seconds = (
        time.perf_counter() - t0
    )

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    counts = {
        L: sum(l == L for _, l in leaves)
        for L in fz.CTX_SIZES
    }

    predicted = sum(
        counts[L] * measured_cost[L]
        for L in fz.CTX_SIZES
    )

    overhead = (
        test_analysis_seconds + test_search_seconds
        if family == "Adaptive" else 0.0
    )

    path = (
        STAGE / "artifacts"
        / f"heldout_{name}.fzac"
    )

    path.write_bytes(blob)

    result = {
        "method": name,
        "family": family,
        "baseline": baseline,
        "original_bytes": len(heldout_raw),
        "original_sha256": heldout_sha,
        "tokens": len(heldout_tokens),
        "compressed_bytes": len(blob),
        "bpb": 8 * len(blob) / len(heldout_raw),
        "ratio": len(heldout_raw) / len(blob),
        "encode_seconds": encode_seconds,
        "analysis_search_seconds": overhead,
        "total_encode_seconds": (
            encode_seconds + overhead
        ),
        "encode_peak_mib": max(
            peak_mib,
            test_analysis_peak
            if family == "Adaptive" else 0
        ),
        "predicted_decode_s": predicted,
        "effective_L": (
            sum(L**2 for _, L in leaves)
            / sum(L for _, L in leaves)
        ),
        "chunk_counts": counts,
        "selection": selection,
        "artifact_sha256": hashlib.sha256(
            blob
        ).hexdigest(),
        "session_id": SESSION_ID,
        "full_decode": "PENDING"
    }

    heldout_results.append(result)

    (STAGE / "results/heldout_encode.json").write_text(
        json.dumps(heldout_results, indent=2)
    )

    print("Compressed bytes:", len(blob))
    print("Total encode:", round(
        result["total_encode_seconds"], 3
    ), "s")
    print("Predicted decode:", round(predicted, 3), "s")

# Fixed baselines
for L in TARGETS:

    encode_heldout(
        name=f"Fixed-{L}",
        policy=fz.FixedPolicy(L),
        family="Fixed",
        baseline=f"Fixed-{L}"
    )

# Adaptive candidates
for r in test_selected:

    chosen_leaves = test_search_layouts[
        r["layout_sha256"]
    ]

    def preset_policy(
        toks, model, batch,
        leaves=chosen_leaves
    ):
        return leaves

    encode_heldout(
        name=f"BC-vs-{r['baseline']}",
        policy=preset_policy,
        family="Adaptive",
        baseline=r["baseline"],
        selection=r
    )

# ==================== FINAL COMPARISON ====================

heldout_df = pd.DataFrame(heldout_results)

test_compare_rows = []

for _, r in heldout_df[
    heldout_df["family"] == "Adaptive"
].iterrows():

    ref = heldout_df[
        heldout_df["method"] == r["baseline"]
    ].iloc[0]

    test_compare_rows.append({
        "baseline": r["baseline"],
        "adaptive": r["method"],
        "fixed_bytes": int(ref["compressed_bytes"]),
        "adaptive_bytes": int(r["compressed_bytes"]),
        "size_saving_pct": 100 * (
            ref["compressed_bytes"]
            - r["compressed_bytes"]
        ) / ref["compressed_bytes"],
        "fixed_pred_decode_s": ref[
            "predicted_decode_s"
        ],
        "adaptive_pred_decode_s": r[
            "predicted_decode_s"
        ],
        "pred_decode_saving_pct": 100 * (
            ref["predicted_decode_s"]
            - r["predicted_decode_s"]
        ) / ref["predicted_decode_s"],
        "fixed_encode_s": ref["total_encode_seconds"],
        "adaptive_encode_s": r["total_encode_seconds"]
    })

test_compare_df = pd.DataFrame(
    test_compare_rows
)

heldout_df.to_csv(
    STAGE / "results/heldout_encode.csv",
    index=False
)

test_compare_df.to_csv(
    STAGE / "results/heldout_comparison.csv",
    index=False
)

print("\n=== HELD-OUT COMPARISON ===")

display(test_compare_df.round(4))

print("\nSearch configurations:", len(test_search_df))
print("Unique layouts:", len(test_evaluated))
print("Search seconds:", round(test_search_seconds, 3))

assert len(heldout_results) == 8

print("Encode: 8/8")
print("CELL 11 DONE")

# Executed input 13
#Stage 7 — Cell 12: Full Decode đối chứng Fixed-64 và BC-64
import time
import gc
import json
import hashlib
import numpy as np
import pandas as pd

DECODE_PATH = (
    STAGE / "results/heldout_decode.json"
)

def decode_heldout(name, repeat=1):

    results = (
        json.loads(DECODE_PATH.read_text())
        if DECODE_PATH.exists() else []
    )

    previous = next(
        (
            r for r in results
            if r["method"] == name
            and r["repeat"] == repeat
            and r["full_decode"] == "PASS"
        ),
        None
    )

    if previous is not None:
        print(f"SKIP: {name}, repeat={repeat}")
        return previous

    enc = next(
        r for r in heldout_results
        if r["method"] == name
    )

    path = (
        STAGE / "artifacts"
        / f"heldout_{name}.fzac"
    )

    blob = path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == enc["artifact_sha256"]

    print(f"\n=== FULL DECODE: {name} ===", flush=True)
    print("Repeat:", repeat)
    print("Session:", SESSION_ID)
    print("Compressed bytes:", len(blob))
    print(
        "Predicted seconds:",
        round(enc["predicted_decode_s"], 4)
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded = fz.decode(blob, lm)

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, heldout_tokens)
    )

    byte_exact = decoded_raw == heldout_raw

    decoded_sha = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    result = {
        **enc,
        "repeat": repeat,
        "decode_session_id": SESSION_ID,
        "decode_seconds": elapsed,
        "decode_peak_mib": peak_mib,
        "decode_bytes_per_second": (
            len(heldout_raw) / elapsed
        ),
        "prediction_error_pct": (
            100 * abs(
                enc["predicted_decode_s"]
                - elapsed
            ) / elapsed
        ),
        "total_seconds": (
            enc["total_encode_seconds"]
            + elapsed
        ),
        "token_exact": token_exact,
        "byte_exact": byte_exact,
        "decoded_sha256": decoded_sha,
        "full_decode": (
            "PASS"
            if token_exact and byte_exact
            else "FAIL"
        )
    }

    results = [
        r for r in results
        if not (
            r["method"] == name
            and r["repeat"] == repeat
        )
    ]

    results.append(result)

    DECODE_PATH.write_text(
        json.dumps(results, indent=2)
    )

    pd.DataFrame(results).to_csv(
        STAGE / "results/heldout_decode.csv",
        index=False
    )

    (
        STAGE / "artifacts"
        / f"heldout_{name}_decoded.txt"
    ).write_bytes(decoded_raw)

    print("Actual decode seconds:", round(elapsed, 4))
    print("Peak GPU:", round(peak_mib, 4), "MiB")
    print("Token exact:", token_exact)
    print("Byte exact:", byte_exact)
    print("SHA-256:", decoded_sha)
    print("STATUS:", result["full_decode"], flush=True)

    assert token_exact and byte_exact
    assert decoded_sha == heldout_sha

    return result


# ==================== PAIRED EXPERIMENT ====================

fixed64_test = decode_heldout(
    "Fixed-64",
    repeat=1
)

bc64_test = decode_heldout(
    "BC-vs-Fixed-64",
    repeat=1
)

# ==================== COMPARISON ====================

pair64_df = pd.DataFrame([
    fixed64_test,
    bc64_test
])

print("\n=== PAIRED FULL DECODE COMPARISON ===")

display(pair64_df[[
    "method",
    "compressed_bytes",
    "bpb",
    "total_encode_seconds",
    "predicted_decode_s",
    "decode_seconds",
    "decode_peak_mib",
    "total_seconds",
    "prediction_error_pct",
    "byte_exact"
]].round(4))

size_saving = 100 * (
    fixed64_test["compressed_bytes"]
    - bc64_test["compressed_bytes"]
) / fixed64_test["compressed_bytes"]

decode_saving = 100 * (
    fixed64_test["decode_seconds"]
    - bc64_test["decode_seconds"]
) / fixed64_test["decode_seconds"]

print("\nSize saving:", round(size_saving, 4), "%")
print("Actual decode saving:", round(decode_saving, 4), "%")

print(
    "Both objectives improved:",
    bool(size_saving > 0 and decode_saving > 0)
)

print("CELL 12 DONE")

# Executed input 14
#Stage 7 — Cell 13: Đo lặp Fixed-64 và BC-64
# ==================== REPEAT 2 ====================

bc64_repeat2 = decode_heldout(
    "BC-vs-Fixed-64",
    repeat=2
)

fixed64_repeat2 = decode_heldout(
    "Fixed-64",
    repeat=2
)

# ==================== REPEAT 3 ====================

fixed64_repeat3 = decode_heldout(
    "Fixed-64",
    repeat=3
)

bc64_repeat3 = decode_heldout(
    "BC-vs-Fixed-64",
    repeat=3
)

# ==================== STATISTICAL SUMMARY ====================

repeat_df = pd.DataFrame(
    json.loads(DECODE_PATH.read_text())
)

pair_df = repeat_df[
    repeat_df["method"].isin([
        "Fixed-64",
        "BC-vs-Fixed-64"
    ])
].copy()

summary64 = (
    pair_df
    .groupby("method")
    .agg(
        repeats=("repeat", "count"),
        compressed_bytes=("compressed_bytes", "first"),
        mean_decode_s=("decode_seconds", "mean"),
        median_decode_s=("decode_seconds", "median"),
        std_decode_s=("decode_seconds", "std"),
        min_decode_s=("decode_seconds", "min"),
        max_decode_s=("decode_seconds", "max"),
        peak_gpu_mib=("decode_peak_mib", "max"),
        lossless=("byte_exact", "all")
    )
    .reset_index()
)

summary64["cv_pct"] = (
    100 * summary64["std_decode_s"]
    / summary64["mean_decode_s"]
)

print("\n=== REPEATED DECODE SUMMARY ===")

display(summary64.round(4))

# ==================== PAIRED SAVINGS ====================

paired = pair_df.pivot(
    index="repeat",
    columns="method",
    values="decode_seconds"
)

paired["decode_saving_pct"] = 100 * (
    paired["Fixed-64"]
    - paired["BC-vs-Fixed-64"]
) / paired["Fixed-64"]

print("\n=== PAIRED DECODE SAVINGS ===")

display(paired.round(4))

summary64.to_csv(
    STAGE / "results/heldout_repeat64_summary.csv",
    index=False
)

paired.to_csv(
    STAGE / "results/heldout_repeat64_paired.csv"
)

print(
    "\nMean paired decode saving:",
    round(paired["decode_saving_pct"].mean(), 4),
    "%"
)

print(
    "Positive repetitions:",
    int((paired["decode_saving_pct"] > 0).sum()),
    "/ 3"
)

assert len(pair_df) == 6
assert pair_df["byte_exact"].all()

print("Lossless: 6/6 PASS")
print("CELL 13 DONE")

# Executed input 15
#Stage 7 — Cell 14: Full Decode Fixed-128 và BC-128
fixed128_test = decode_heldout(
    "Fixed-128",
    repeat=1
)

bc128_test = decode_heldout(
    "BC-vs-Fixed-128",
    repeat=1
)

pair128_df = pd.DataFrame([
    fixed128_test,
    bc128_test
])

print("\n=== PAIRED FULL DECODE COMPARISON ===")

display(pair128_df[[
    "method",
    "compressed_bytes",
    "bpb",
    "total_encode_seconds",
    "predicted_decode_s",
    "decode_seconds",
    "decode_peak_mib",
    "total_seconds",
    "prediction_error_pct",
    "byte_exact"
]].round(4))

size_saving128 = 100 * (
    fixed128_test["compressed_bytes"]
    - bc128_test["compressed_bytes"]
) / fixed128_test["compressed_bytes"]

decode_saving128 = 100 * (
    fixed128_test["decode_seconds"]
    - bc128_test["decode_seconds"]
) / fixed128_test["decode_seconds"]

print("\nSize saving:", round(size_saving128, 4), "%")
print("Actual decode saving:", round(decode_saving128, 4), "%")

print(
    "Both objectives improved:",
    bool(
        size_saving128 > 0
        and decode_saving128 > 0
    )
)

print("CELL 14 DONE")

# Executed input 16
#Stage 7 — Cell 15: Đo lặp Fixed-128 và BC-128
# ==================== REPEAT 2 ====================

bc128_repeat2 = decode_heldout(
    "BC-vs-Fixed-128",
    repeat=2
)

fixed128_repeat2 = decode_heldout(
    "Fixed-128",
    repeat=2
)

# ==================== REPEAT 3 ====================

fixed128_repeat3 = decode_heldout(
    "Fixed-128",
    repeat=3
)

bc128_repeat3 = decode_heldout(
    "BC-vs-Fixed-128",
    repeat=3
)

# ==================== SUMMARY ====================

repeat_df = pd.DataFrame(
    json.loads(DECODE_PATH.read_text())
)

pair128 = repeat_df[
    repeat_df["method"].isin([
        "Fixed-128",
        "BC-vs-Fixed-128"
    ])
].copy()

summary128 = (
    pair128
    .groupby("method")
    .agg(
        repeats=("repeat", "count"),
        compressed_bytes=("compressed_bytes", "first"),
        mean_decode_s=("decode_seconds", "mean"),
        median_decode_s=("decode_seconds", "median"),
        std_decode_s=("decode_seconds", "std"),
        min_decode_s=("decode_seconds", "min"),
        max_decode_s=("decode_seconds", "max"),
        peak_gpu_mib=("decode_peak_mib", "max"),
        lossless=("byte_exact", "all")
    )
    .reset_index()
)

summary128["cv_pct"] = (
    100 * summary128["std_decode_s"]
    / summary128["mean_decode_s"]
)

paired128 = pair128.pivot(
    index="repeat",
    columns="method",
    values="decode_seconds"
)

paired128["decode_saving_pct"] = 100 * (
    paired128["Fixed-128"]
    - paired128["BC-vs-Fixed-128"]
) / paired128["Fixed-128"]

summary128.to_csv(
    STAGE / "results/heldout_repeat128_summary.csv",
    index=False
)

paired128.to_csv(
    STAGE / "results/heldout_repeat128_paired.csv"
)

print("\n=== REPEATED DECODE SUMMARY ===")

display(summary128.round(4))

print("\n=== PAIRED DECODE SAVINGS ===")

display(paired128.round(4))

print(
    "\nMean paired decode saving:",
    round(
        paired128["decode_saving_pct"].mean(),
        4
    ),
    "%"
)

print(
    "Positive repetitions:",
    int(
        (paired128["decode_saving_pct"] > 0).sum()
    ),
    "/ 3"
)

assert len(pair128) == 6
assert pair128["byte_exact"].all()

print("Lossless: 6/6 PASS")
print("CELL 15 DONE")

# Executed input 17
#Stage 7 — Cell 16: Full Decode Fixed-256 và BC-256
fixed256_test = decode_heldout(
    "Fixed-256",
    repeat=1
)

bc256_test = decode_heldout(
    "BC-vs-Fixed-256",
    repeat=1
)

pair256_df = pd.DataFrame([
    fixed256_test,
    bc256_test
])

print("\n=== PAIRED FULL DECODE COMPARISON ===")

display(pair256_df[[
    "method",
    "compressed_bytes",
    "bpb",
    "total_encode_seconds",
    "predicted_decode_s",
    "decode_seconds",
    "decode_peak_mib",
    "total_seconds",
    "prediction_error_pct",
    "byte_exact"
]].round(4))

size_saving256 = 100 * (
    fixed256_test["compressed_bytes"]
    - bc256_test["compressed_bytes"]
) / fixed256_test["compressed_bytes"]

decode_saving256 = 100 * (
    fixed256_test["decode_seconds"]
    - bc256_test["decode_seconds"]
) / fixed256_test["decode_seconds"]

print("\nSize saving:", round(size_saving256, 4), "%")

print(
    "Actual decode saving:",
    round(decode_saving256, 4),
    "%"
)

print(
    "Both objectives improved:",
    bool(
        size_saving256 > 0
        and decode_saving256 > 0
    )
)

print("CELL 16 DONE")

# Executed input 18
#Stage 7 — Cell 17: Full Decode Fixed-512 và BC-512
fixed512_test = decode_heldout(
    "Fixed-512",
    repeat=1
)

bc512_test = decode_heldout(
    "BC-vs-Fixed-512",
    repeat=1
)

pair512_df = pd.DataFrame([
    fixed512_test,
    bc512_test
])

print("\n=== PAIRED FULL DECODE COMPARISON ===")

display(pair512_df[[
    "method",
    "compressed_bytes",
    "bpb",
    "total_encode_seconds",
    "predicted_decode_s",
    "decode_seconds",
    "decode_peak_mib",
    "total_seconds",
    "prediction_error_pct",
    "byte_exact"
]].round(4))

size_saving512 = 100 * (
    fixed512_test["compressed_bytes"]
    - bc512_test["compressed_bytes"]
) / fixed512_test["compressed_bytes"]

decode_saving512 = 100 * (
    fixed512_test["decode_seconds"]
    - bc512_test["decode_seconds"]
) / fixed512_test["decode_seconds"]

print("\nSize saving:", round(size_saving512, 4), "%")
print("Actual decode saving:", round(decode_saving512, 4), "%")

print(
    "Both objectives improved:",
    bool(size_saving512 > 0 and decode_saving512 > 0)
)

print("CELL 17 DONE")

# Executed input 19
#Stage 7 — Cell 18: Tổng hợp kết quả và vẽ biểu đồ paper
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

RESULTS = STAGE / "results"
PLOTS = STAGE / "plots"

# ==================== VERIFY ====================

df = pd.DataFrame(
    json.loads(DECODE_PATH.read_text())
)

assert len(df) == 16
assert df["method"].nunique() == 8
assert df["full_decode"].eq("PASS").all()
assert df["byte_exact"].all()
assert df["token_exact"].all()
assert df["decoded_sha256"].eq(heldout_sha).all()

print("Full decode measurements: 16/16 PASS")
print("Unique configurations: 8/8 PASS")

# ==================== AGGREGATE ====================

summary = (
    df.groupby(["method", "family", "baseline"])
    .agg(
        repeats=("repeat", "count"),
        compressed_bytes=("compressed_bytes", "first"),
        ratio=("ratio", "first"),
        bpb=("bpb", "first"),
        effective_L=("effective_L", "first"),
        total_encode_s=("total_encode_seconds", "first"),
        encode_peak_mib=("encode_peak_mib", "max"),
        predicted_decode_s=("predicted_decode_s", "first"),
        mean_decode_s=("decode_seconds", "mean"),
        median_decode_s=("decode_seconds", "median"),
        std_decode_s=("decode_seconds", "std"),
        decode_peak_mib=("decode_peak_mib", "max"),
        mean_prediction_error_pct=(
            "prediction_error_pct", "mean"
        ),
        byte_exact=("byte_exact", "all")
    )
    .reset_index()
)

summary["mean_total_s"] = (
    summary["total_encode_s"]
    + summary["mean_decode_s"]
)

summary["cv_pct"] = (
    100 * summary["std_decode_s"]
    / summary["mean_decode_s"]
)

summary["context"] = (
    summary["baseline"]
    .str.split("-")
    .str[-1]
    .astype(int)
)

summary = summary.sort_values(
    ["context", "family"]
).reset_index(drop=True)

# ==================== PAIRED COMPARISON ====================

comparisons = []

for L in [64, 128, 256, 512]:

    fixed = summary[
        summary["method"] == f"Fixed-{L}"
    ].iloc[0]

    adaptive = summary[
        summary["method"] == f"BC-vs-Fixed-{L}"
    ].iloc[0]

    pair = df[
        df["method"].isin([
            f"Fixed-{L}",
            f"BC-vs-Fixed-{L}"
        ])
    ].pivot(
        index="repeat",
        columns="method",
        values="decode_seconds"
    )

    paired_saving = 100 * (
        pair[f"Fixed-{L}"]
        - pair[f"BC-vs-Fixed-{L}"]
    ) / pair[f"Fixed-{L}"]

    extra_encode = (
        adaptive["total_encode_s"]
        - fixed["total_encode_s"]
    )

    saved_decode = (
        fixed["mean_decode_s"]
        - adaptive["mean_decode_s"]
    )

    comparisons.append({
        "context": L,
        "fixed_bytes": int(fixed["compressed_bytes"]),
        "adaptive_bytes": int(adaptive["compressed_bytes"]),
        "size_saving_pct": 100 * (
            fixed["compressed_bytes"]
            - adaptive["compressed_bytes"]
        ) / fixed["compressed_bytes"],
        "fixed_decode_mean_s": fixed["mean_decode_s"],
        "adaptive_decode_mean_s": adaptive["mean_decode_s"],
        "mean_paired_decode_saving_pct": paired_saving.mean(),
        "positive_repetitions": int(
            (paired_saving > 0).sum()
        ),
        "repetitions": len(pair),
        "fixed_encode_s": fixed["total_encode_s"],
        "adaptive_encode_s": adaptive["total_encode_s"],
        "encode_slowdown": (
            adaptive["total_encode_s"]
            / fixed["total_encode_s"]
        ),
        "fixed_total_s": fixed["mean_total_s"],
        "adaptive_total_s": adaptive["mean_total_s"],
        "total_time_saving_pct": 100 * (
            fixed["mean_total_s"]
            - adaptive["mean_total_s"]
        ) / fixed["mean_total_s"],
        "decode_memory_change_pct": 100 * (
            adaptive["decode_peak_mib"]
            - fixed["decode_peak_mib"]
        ) / fixed["decode_peak_mib"],
        "break_even_decodes": (
            max(1, int(np.ceil(extra_encode / saved_decode)))
            if saved_decode > 0 else None
        ),
        "byte_exact": True
    })

comparison = pd.DataFrame(comparisons)

summary.to_csv(
    RESULTS / "stage7_final_summary.csv",
    index=False
)

summary.to_json(
    RESULTS / "stage7_final_summary.json",
    orient="records",
    indent=2
)

comparison.to_csv(
    RESULTS / "stage7_pair_comparison.csv",
    index=False
)

comparison.to_json(
    RESULTS / "stage7_pair_comparison.json",
    orient="records",
    indent=2
)

# ==================== PLOT HELPER ====================

def save_stage7_plot(name):

    plt.tight_layout()

    for ext in ["png", "pdf"]:

        plt.savefig(
            PLOTS / f"{name}.{ext}",
            dpi=300,
            bbox_inches="tight"
        )

    plt.show()
    plt.close()


# FIGURE 4: Actual Pareto

plt.figure(figsize=(9, 6))

for family, color, marker in [
    ("Fixed", "#2563eb", "o"),
    ("Adaptive", "#dc2626", "s")
]:

    g = summary[
        summary["family"] == family
    ].sort_values("mean_decode_s")

    plt.plot(
        g["mean_decode_s"],
        g["bpb"],
        marker=marker,
        color=color,
        label=family
    )

    for _, r in g.iterrows():
        plt.annotate(
            str(r["context"]),
            (r["mean_decode_s"], r["bpb"]),
            xytext=(5, 6),
            textcoords="offset points",
            fontsize=8,
            color=color
        )

plt.xlabel("Measured decoding time (s)")
plt.ylabel("Bits per byte (BPB)")
plt.title("Held-out test: compression-decoding trade-off")
plt.legend()
plt.grid(alpha=0.25)

save_stage7_plot("04_heldout_actual_pareto")


# FIGURE 5: Percentage improvements

x = np.arange(len(comparison))
width = 0.36

plt.figure(figsize=(10, 6))

plt.bar(
    x - width/2,
    comparison["size_saving_pct"],
    width,
    label="Compressed size saving"
)

plt.bar(
    x + width/2,
    comparison["mean_paired_decode_saving_pct"],
    width,
    label="Decoding time saving"
)

plt.xticks(
    x,
    comparison["context"].astype(str)
)

plt.xlabel("Fixed context reference")
plt.ylabel("Improvement (%)")
plt.title("Budget-Constrained DP improvements")
plt.axhline(0, color="black", linewidth=0.7)
plt.legend()
plt.grid(axis="y", alpha=0.25)

save_stage7_plot("05_heldout_improvements")


# FIGURE 6: Measured vs predicted

plt.figure(figsize=(8, 6))

for family, marker in [
    ("Fixed", "o"),
    ("Adaptive", "s")
]:

    g = summary[summary["family"] == family]

    plt.scatter(
        g["mean_decode_s"],
        g["predicted_decode_s"],
        marker=marker,
        s=70,
        label=family
    )

limit = max(
    summary["mean_decode_s"].max(),
    summary["predicted_decode_s"].max()
)

plt.plot(
    [0, limit],
    [0, limit],
    "k--",
    label="Ideal prediction"
)

plt.xlabel("Measured decoding time (s)")
plt.ylabel("Predicted decoding time (s)")
plt.title("Held-out latency prediction accuracy")
plt.legend()
plt.grid(alpha=0.25)

save_stage7_plot("06_heldout_latency_prediction")


# FIGURE 7: Repeated measurements

plt.figure(figsize=(9, 6))

for L, color in [(64, "#2563eb"), (128, "#dc2626")]:

    pair = df[df["baseline"] == f"Fixed-{L}"].pivot(
        index="repeat",
        columns="method",
        values="decode_seconds"
    )

    saving = 100 * (
        pair[f"Fixed-{L}"]
        - pair[f"BC-vs-Fixed-{L}"]
    ) / pair[f"Fixed-{L}"]

    plt.plot(
        saving.index,
        saving.values,
        "o-",
        color=color,
        label=f"BC-{L}"
    )

plt.xticks([1, 2, 3])
plt.xlabel("Repeat")
plt.ylabel("Paired decoding time saving (%)")
plt.title("Repeated measurement stability")
plt.legend()
plt.grid(alpha=0.25)

save_stage7_plot("07_repeat_stability")


# FIGURE 8: Encoding overhead

plt.figure(figsize=(9, 6))

plt.bar(
    x - width/2,
    comparison["fixed_encode_s"],
    width,
    label="Fixed"
)

plt.bar(
    x + width/2,
    comparison["adaptive_encode_s"],
    width,
    label="Budget-Constrained DP"
)

plt.xticks(
    x,
    comparison["context"].astype(str)
)

plt.xlabel("Fixed context reference")
plt.ylabel("Total encoding time (s)")
plt.title("Encoding overhead including analysis and search")
plt.legend()
plt.grid(axis="y", alpha=0.25)

save_stage7_plot("08_encoding_overhead")


# FIGURE 9: Total time

plt.figure(figsize=(9, 6))

plt.bar(
    comparison["context"].astype(str),
    comparison["total_time_saving_pct"],
    color=[
        "#16a34a" if v > 0 else "#dc2626"
        for v in comparison["total_time_saving_pct"]
    ]
)

plt.axhline(0, color="black", linewidth=0.8)
plt.xlabel("Fixed context reference")
plt.ylabel("Total time saving (%)")
plt.title("End-to-end encoding and decoding trade-off")
plt.grid(axis="y", alpha=0.25)

save_stage7_plot("09_total_time_tradeoff")


# ==================== FINAL REPORT ====================

print("\n=== STAGE 7 FINAL SUMMARY ===")

display(summary.round(4))

print("\n=== FINAL PAIRED COMPARISON ===")

display(comparison.round(4))

print(
    "\nMean held-out latency prediction error:",
    round(df["prediction_error_pct"].mean(), 4),
    "%"
)

print("\n=== GENERATED FIGURES ===")

for p in sorted(PLOTS.glob("*")):
    print(p.name)

print("\nPNG files:", len(list(PLOTS.glob("*.png"))))
print("PDF files:", len(list(PLOTS.glob("*.pdf"))))

print("\nLossless measurements: 16/16")
print("CELL 18 DONE")