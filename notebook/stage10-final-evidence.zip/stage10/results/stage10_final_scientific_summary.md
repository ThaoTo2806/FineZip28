# FineZip28 — Stage 10 Scientific Summary

## Status

READY FOR FINAL PACKAGING.

This is the Stage 10 scientific scope review.
Final evidence and artifact ZIPs have not yet been created.

## Experiment coverage

- Six datasets of 100,000 bytes each.
- Eighty-four 100 KB compression configurations.
- Fourteen 1 MB compression configurations.
- Seventy-two traditional 100 KB benchmark runs.
- Twelve traditional 1 MB benchmark runs.
- One fresh Fast BC-DP full decode on 1 MB.
- Four publication figures, each in PNG and PDF.

## Compression results

At 100 KB, BZip2 produced the smallest file on five
of the six evaluated datasets. On enwik8_new,
BC-DP-Full achieved 27,608 bytes.

On enwik8 1 MB, Fixed-512 achieved 213,691 bytes,
saving 24.0407% relative to BZip2.

Fast BC-DP-64 achieved 273,990 bytes,
saving 2.6066% relative to BZip2.

Its measured encode time was
117.3890 seconds.

Its measured full decode time was
1386.1740 seconds.

All 286,273 tokens and all 1,000,000 original bytes
were reconstructed exactly, including matching SHA-256.

## Trade-offs

Fast BC-DP-64 produced an artifact
0.8414% larger than Fixed-64.

The observed decode time was
16.6318% lower than Fixed-64,
but these measurements were made in different sessions
and must not be treated as controlled speedup evidence.

Traditional codecs remain much faster at decoding.

## Scaling interpretation

The two input sizes differ by 10x, but the samples
are not prefix-identical. The measured encode
scaling is descriptive only.

No claim of asymptotic linear complexity is made.

## Evidence quality

- 98/98 compressed artifact sizes matched the tables.
- 61/61 available independent artifact SHA checks passed.
- All 98 actual artifact SHA values were recorded.
- 4/4 figures and all 8 PNG/PDF files were audited.
- The Stage 10 Fast BC-DP 1 MB decode is lossless verified.

## Limitations

- Historical FineZip timing measurements cross sessions.
- FineZip timings generally lack repeated measurements.
- External LLM compressor baselines were not executed.
- Dataset coverage is limited.
- Decode cost is a major practical limitation.

## Source provenance

Git commit:
62f09e3105296d62c39e8d95cf8b8775e63f2677

## Release decision

READY_FOR_FINAL_PACKAGING

Final ZIP packaging and Kaggle Input upload
remain separate required steps before Stage 11.
