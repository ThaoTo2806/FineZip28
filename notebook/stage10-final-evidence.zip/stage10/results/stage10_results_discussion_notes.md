# Stage 10 — Results and Discussion Notes

## Experimental scope

- Six 100 KB datasets, with 84 compression configurations
  aggregated from Stage 9 FineZip and Stage 10 traditional baselines.
- One 1 MB enwik8 dataset, with 14 verified compression configurations.
- Traditional algorithms: gzip, bzip2, xz and zstd.
- FineZip source commit:
  `62f09e3105296d62c39e8d95cf8b8775e63f2677`.
- Full compressed artifact sizes, including format overhead,
  are reported.

## 100 KB compression results

| Dataset | Smallest method(s) | Smallest bytes | BZip2 bytes | Saving vs BZip2 |
|---|---|---:|---:|---:|
| csv_data | bz2 | 14,854 | 14,854 | 0.00% |
| english | bz2 | 29,848 | 29,848 | 0.00% |
| enwik8_new | BC-DP-Full | 27,608 | 31,303 | 11.80% |
| mixed | bz2 | 28,659 | 28,659 | 0.00% |
| python_code | bz2 | 17,726 | 17,726 | 0.00% |
| vietnamese | bz2 | 26,832 | 26,832 | 0.00% |

These results describe compressed artifact sizes. FineZip
measurements originate from previous Stage 9 experiments,
while traditional baselines were measured in Stage 10.

## 1 MB compression results

- Fixed-512: 213,691 bytes,
  with a measured Stage 6A decode time of
  12950.8678 seconds.
- Fast BC-DP-64: 273,990 bytes,
  with a freshly measured Stage 10 encode time of
  117.3890 seconds.
- Fast BC-DP-64 full decode:
  1386.1740 seconds.
- BZip2: 281,323 bytes.
- Fast BC-DP-64 saved 2.6066% in compressed size
  compared with BZip2.
- Compared with Fixed-64, Fast BC-DP-64 produced a
  0.8414% larger artifact and showed
  a 16.6318% lower observed decode time.
  The decode comparison crosses experimental sessions.

## Lossless verification

- The Stage 10 Fast BC-DP 100 KB pilot reproduced its Stage 9
  layout and compressed artifact byte-for-byte.
- The newly encoded 1 MB Fast BC-DP file was decoded in full.
- All 286,273 tokens were reconstructed exactly.
- The decoded 1,000,000 bytes matched the original byte-for-byte.
- Original and decoded SHA-256:
  `369b688978f649681136198fb96db14c1616756260c55fb4b65e9bc049552cad`.

## Descriptive scaling

- Original input sizes: 100 KB and 1 MB.
- 100 KB and 1 MB enwik8 samples are not prefix-identical.
- Fast BC-DP total encode time:
  11.9332 seconds
  (100 KB) versus
  117.3890 seconds
  (1 MB).
- These measurements do not establish asymptotic complexity.

## Methodological limitations

1. FineZip Stage 6A encode/decode timings are historical
   single observations; they must not be presented as
   controlled same-session comparisons against Stage 10.
2. Traditional compression and GPT-2-based compression
   involve substantially different computational workloads.
3. New Fast BC-DP encode measurements have one run per
   input size, with no within-size variance estimate.
4. The 100 KB and 1 MB samples differ, so the descriptive
   scaling factors include dataset-composition effects.
5. Fast BC-DP 1 MB decode is orders of magnitude slower
   than traditional decoders, despite its modest size
   advantage over BZip2.
6. Results are specific to the tested datasets, model,
   software setup and compression settings.
7. No independently runnable LLM-based external compressor
   baseline is claimed by these results.

## Figure references

1. `stage10_fig01_1mb_compressed_size`
2. `stage10_fig02_1mb_size_decode_tradeoff`
3. `stage10_fig03_fast_bc_dp_encode_breakdown`
4. `stage10_fig04_fast_bc_dp_encode_scaling`

These notes are an evidence-grounded draft for the manuscript,
not a final submission-ready Results section.
