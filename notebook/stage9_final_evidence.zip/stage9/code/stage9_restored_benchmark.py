def save_json_stage9(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temp.replace(path)

def controlled_decode_stage9(dataset_name, method, context=64, repeat=1):
    key = (dataset_name, method, context, repeat)
    enc = encode_completed9[dataset_name, method, context]
    path = STAGE / 'artifacts' / f'{dataset_name}_{method}_{context}.fzac'
    blob = path.read_bytes()
    assert hashlib.sha256(blob).hexdigest() == enc['artifact_sha256']
    if key in control_lookup9:
        previous = control_lookup9[key]
        assert previous['byte_exact']
        assert previous['artifact_sha256'] == enc['artifact_sha256']
        print(f'SKIP | {key}')
        return previous
    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]
    print(f'\n=== CONTROLLED DECODE: {dataset_name} | {method} ===', flush=True)
    print('Context:', context)
    print('Repeat:', repeat)
    print('Session:', SESSION_ID)
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    decoded = fz.decode(blob, lm)
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - t0
    peak_mib = torch.cuda.max_memory_allocated(0) / 1024 ** 2
    decoded_raw = tokenizer.decode(decoded.tolist(), skip_special_tokens=False, clean_up_tokenization_spaces=False).encode('utf-8')
    token_exact = bool(np.array_equal(decoded, tokens))
    byte_exact = decoded_raw == raw
    decoded_sha = hashlib.sha256(decoded_raw).hexdigest()
    sha_exact = decoded_sha == enc['original_sha256']
    assert token_exact
    assert byte_exact
    assert sha_exact
    record = {'dataset': dataset_name, 'method': method, 'context': context, 'repeat': repeat, 'compressed_bytes': enc['compressed_bytes'], 'bpb': enc['bpb'], 'total_encode_seconds': enc['total_encode_seconds'], 'predicted_decode_s': enc['predicted_decode_s'], 'decode_seconds': elapsed, 'decode_peak_mib': peak_mib, 'total_seconds': enc['total_encode_seconds'] + elapsed, 'artifact_sha256': enc['artifact_sha256'], 'layout_sha256': enc['layout_sha256'], 'decoded_sha256': decoded_sha, 'token_exact': token_exact, 'byte_exact': byte_exact, 'sha_exact': sha_exact, 'decode_session_id': SESSION_ID, 'gpu_name': torch.cuda.get_device_name(0), 'full_decode': 'PASS'}
    control_records9.append(record)
    control_lookup9[key] = record
    save_json_stage9(CONTROL_JSON9, control_records9)
    pd.DataFrame(control_records9).to_csv(CONTROL_CSV9, index=False)
    print('Decode:', round(elapsed, 4), 's')
    print('GPU peak:', round(peak_mib, 4), 'MiB')
    print('Byte-exact:', byte_exact)
    print('STATUS: PASS')
    print(f'Controlled checkpoint: {len(control_records9)}/24')
    return record

def benchmark_controlled_dataset9(dataset_name):
    orders = [CONTROL_METHODS, CONTROL_METHODS[::-1], CONTROL_METHODS[2:] + CONTROL_METHODS[:2]]
    for repeat, order in enumerate(orders, start=1):
        print(f'\n=== REPEAT {repeat}/3 ===')
        for method in order:
            controlled_decode_stage9(dataset_name=dataset_name, method=method, context=CONTROL_CONTEXT, repeat=repeat)
    df = pd.DataFrame([r for r in control_records9 if r['dataset'] == dataset_name])
    assert len(df) == 12
    summary = df.groupby('method').agg(repeats=('decode_seconds', 'count'), compressed_bytes=('compressed_bytes', 'first'), mean_decode_s=('decode_seconds', 'mean'), median_decode_s=('decode_seconds', 'median'), std_decode_s=('decode_seconds', 'std'), peak_gpu_mib=('decode_peak_mib', 'max'), byte_exact=('byte_exact', 'all')).reset_index()
    summary['cv_pct'] = 100 * summary['std_decode_s'] / summary['mean_decode_s']
    summary.to_csv(STAGE / 'results' / f'{dataset_name}_controlled_summary.csv', index=False)
    print('\n=== CONTROLLED DECODE SUMMARY ===')
    display(summary.round(4))
    return summary