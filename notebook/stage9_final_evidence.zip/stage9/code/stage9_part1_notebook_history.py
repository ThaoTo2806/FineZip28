# ==================== CELL 1 ====================
# Stage 9 — Cell 1: Clone Source & Setup Environment

%cd /kaggle/working

!git clone https://github.com/ThaoTo2806/FineZip28.git

!git -C /kaggle/working/FineZip28 checkout 62f09e3105296d62c39e8d95cf8b8775e63f2677

!pip install -q transformers==5.0.0 accelerate sentencepiece

!nvidia-smi

!git -C /kaggle/working/FineZip28 rev-parse HEAD

from pathlib import Path

ROOT = Path("/kaggle/working/FineZip28")
STAGE = Path("/kaggle/working/stage9")
INPUT = Path("/kaggle/input/datasets/thothanh28")

for folder in [
    "code",
    "results",
    "plots",
    "artifacts",
    "datasets",
    "reference"
]:
    (STAGE / folder).mkdir(
        parents=True,
        exist_ok=True
    )

print("\n=== REQUIRED KAGGLE INPUT ===")

required_inputs = [
    "stage7-final-evidence",
    "stage7-final-artifacts",
    "stage8-final-evidence",
    "stage8-final-artifacts"
]

for name in required_inputs:

    path = INPUT / name

    print(
        "PASS" if path.is_dir() else "MISSING",
        "|", name
    )

assert all(
    (INPUT / name).is_dir()
    for name in required_inputs
)

print("\n=== STAGE 8 INPUT FILES ===")

for filename in [
    "stage8_final_summary.csv",
    "stage8_pair_comparison.csv",
    "stage8_metadata.json",
    "stage8_selected_layouts.json",
    "stage8_notebook_history.py",
    "python_code_analysis.npz",
    "enwik8_new_analysis.npz"
]:

    matches = sorted(INPUT.glob(
        f"stage8-final-*/**/{filename}"
    ))

    assert matches, f"Missing: {filename}"

    for path in matches:
        print("PASS |", path)

print("\nOutput folder:", STAGE)

print("STAGE 9 - CELL 1 DONE")

# ==================== CELL 2 ====================
# Stage 9 — Cell 2: Restore References & Analyze Bottleneck

import sys
import json
import shutil
import hashlib
import inspect
import numpy as np
import pandas as pd
import torch
import transformers

SESSION_ID = "Stage9-Session01"

E7 = INPUT / "stage7-final-evidence/stage7"
A7 = INPUT / "stage7-final-artifacts/stage7/artifacts"

E8 = INPUT / "stage8-final-evidence/stage8"
A8 = INPUT / "stage8-final-artifacts/stage8"

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

print("=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)
print("GPU count:", torch.cuda.device_count())

assert torch.cuda.is_available()

# ==================== RESTORE REFERENCES ====================

references = {
    "decode_cost_config.json":
        E7 / "results/decode_cost_config.json",

    "frozen_rank_table.npy":
        A7 / "frozen_rank_table.npy",

    "stage8_final_summary.csv":
        E8 / "results/stage8_final_summary.csv",

    "stage8_pair_comparison.csv":
        E8 / "results/stage8_pair_comparison.csv",

    "stage8_metadata.json":
        E8 / "results/stage8_metadata.json",

    "stage8_selected_layouts.json":
        A8 / "stage8_selected_layouts.json",

    "dataset_manifest.json":
        E8 / "results/dataset_manifest.json",

    "stage8_notebook_history.py":
        E8 / "code/stage8_notebook_history.py"
}

print("\n=== RESTORE REFERENCES ===")

for filename, source in references.items():

    assert source.is_file(), source

    destination = STAGE / "reference" / filename

    shutil.copy2(source, destination)

    assert hashlib.sha256(
        source.read_bytes()
    ).hexdigest() == hashlib.sha256(
        destination.read_bytes()
    ).hexdigest()

    print(
        f"PASS | {filename} | "
        f"{destination.stat().st_size:,} B"
    )

# ==================== FROZEN PARAMETERS ====================

cost_config = json.loads(
    (STAGE / "reference/decode_cost_config.json")
    .read_text()
)

rank_table = np.load(
    STAGE / "reference/frozen_rank_table.npy"
)

NEW_C = float(
    cost_config["fitted_quadratic_c"]
)

OLD_C = 0.000102

LEVELS = tuple(fz.CTX_SIZES)
TARGETS = [64, 128]

RMAX = 4096

DENSE_LAMBDAS = np.concatenate([
    [0.0],
    np.geomspace(0.01, 10000, 121)
])

batch_plan = {
    32: 8,
    64: 8,
    128: 8,
    256: 4,
    512: 2
}

assert rank_table.shape == (4097,)
assert len(DENSE_LAMBDAS) == 122

print("\n=== FROZEN PARAMETERS ===")
print("Context levels:", LEVELS)
print("Target contexts:", TARGETS)
print("Rank table:", rank_table.shape)
print("Fitted quadratic c:", NEW_C)
print("Dense lambda candidates:", len(DENSE_LAMBDAS))
print("Full search configurations:", 4 * len(DENSE_LAMBDAS))

# ==================== DATASET RESTORE ====================

manifest = json.loads(
    (STAGE / "reference/dataset_manifest.json")
    .read_text()
)

datasets = {}
dataset_tokens = {}

print("\n=== RESTORE DATASETS ===")

for record in manifest:

    name = record["dataset"]

    raw = (
        A8.parent / "datasets" / f"{name}.txt"
    ).read_bytes()

    assert hashlib.sha256(
        raw
    ).hexdigest() == record["sha256"]

    tokens = np.load(
        A8 / f"{name}_tokens.npy"
    )

    datasets[name] = raw
    dataset_tokens[name] = tokens

    (STAGE / "datasets" / f"{name}.txt").write_bytes(raw)

    print(
        f"PASS | {name:15s} | "
        f"{len(raw):,} bytes | "
        f"{len(tokens):,} tokens"
    )

assert len(datasets) == 6

# ==================== BOTTLENECK ANALYSIS ====================

stage8_enc = json.loads(
    (E8 / "results/encode_benchmark.json").read_text()
)

bottleneck_rows = []

for r in stage8_enc:

    if r["family"] != "Adaptive":
        continue

    selection = r["selection"]

    analysis_s = float(selection["analysis_seconds"])
    search_s = float(selection["search_seconds"])
    codec_s = float(r["encode_seconds"])
    total_s = float(r["total_encode_seconds"])

    assert np.isclose(
        analysis_s + search_s + codec_s,
        total_s
    )

    bottleneck_rows.append({
        "dataset": r["dataset"],
        "context": r["context"],
        "analysis_seconds": analysis_s,
        "search_seconds": search_s,
        "codec_seconds": codec_s,
        "total_seconds": total_s,

        "analysis_pct":
            100 * analysis_s / total_s,

        "search_pct":
            100 * search_s / total_s,

        "codec_pct":
            100 * codec_s / total_s,

        "max_speedup_if_search_free":
            total_s / (analysis_s + codec_s)
    })

bottleneck_df = pd.DataFrame(
    bottleneck_rows
)

assert len(bottleneck_df) == 12

bottleneck_df.to_csv(
    STAGE / "results/stage8_bottleneck_analysis.csv",
    index=False
)

print("\n=== STAGE 8 BOTTLENECK BREAKDOWN ===")

display(bottleneck_df.round(4))

print("\n=== MEAN ENCODING COST DISTRIBUTION ===")

for column in [
    "analysis_pct",
    "search_pct",
    "codec_pct"
]:

    print(
        f"{column:15s}: "
        f"{bottleneck_df[column].mean():.4f}%"
    )

print(
    "Mean theoretical speedup "
    "if search cost is eliminated:",
    round(
        bottleneck_df[
            "max_speedup_if_search_free"
        ].mean(),
        4
    ),
    "x"
)

# ==================== SOURCE INSPECTION ====================

print("\n=== ANALYSIS IMPLEMENTATION ===")
print(inspect.getsource(s5.analyze))

print("\n=== DP IMPLEMENTATION ===")
print(inspect.getsource(s5.TreeDP))

print("\n=== FINAL STATUS ===")
print("References: PASS")
print("Datasets: 6/6 PASS")
print("Bottleneck comparisons: 12/12")
print("Original source modified: False")
print("CELL 2 DONE")

# ==================== CELL 3 ====================
# Stage 9 — Cell 2 Fix: Correct Artifact Paths

A7 = INPUT / "stage7-final-artifacts/stage7/artifacts"
A8 = INPUT / "stage8-final-artifacts/stage8/artifacts"

references["stage8_selected_layouts.json"] = (
    A8 / "stage8_selected_layouts.json"
)

references["frozen_rank_table.npy"] = (
    A7 / "frozen_rank_table.npy"
)

print("=== VERIFY CORRECTED PATHS ===")

for filename, source in references.items():

    assert source.is_file(), f"Missing: {source}"

    print(f"PASS | {filename}")

print("\nArtifact directory:", A8)
print("PATH FIX: PASS")
print("CELL 2 FIX DONE")

# ==================== CELL 4 ====================
# Stage 9 — Cell 2: Restore References & Analyze Bottleneck

import sys
import json
import shutil
import hashlib
import inspect
import numpy as np
import pandas as pd
import torch
import transformers

SESSION_ID = "Stage9-Session01"

E7 = INPUT / "stage7-final-evidence/stage7"
A7 = INPUT / "stage7-final-artifacts/stage7/artifacts"

E8 = INPUT / "stage8-final-evidence/stage8"
A8 = INPUT / "stage8-final-artifacts/stage8/artifacts"

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

print("=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)
print("GPU count:", torch.cuda.device_count())

assert torch.cuda.is_available()

# ==================== RESTORE REFERENCES ====================

references = {
    "decode_cost_config.json":
        E7 / "results/decode_cost_config.json",

    "frozen_rank_table.npy":
        A7 / "frozen_rank_table.npy",

    "stage8_final_summary.csv":
        E8 / "results/stage8_final_summary.csv",

    "stage8_pair_comparison.csv":
        E8 / "results/stage8_pair_comparison.csv",

    "stage8_metadata.json":
        E8 / "results/stage8_metadata.json",

    "stage8_selected_layouts.json":
        A8 / "stage8_selected_layouts.json",

    "dataset_manifest.json":
        E8 / "results/dataset_manifest.json",

    "stage8_notebook_history.py":
        E8 / "code/stage8_notebook_history.py"
}

print("\n=== RESTORE REFERENCES ===")

for filename, source in references.items():

    assert source.is_file(), source

    destination = STAGE / "reference" / filename

    shutil.copy2(source, destination)

    assert hashlib.sha256(
        source.read_bytes()
    ).hexdigest() == hashlib.sha256(
        destination.read_bytes()
    ).hexdigest()

    print(
        f"PASS | {filename} | "
        f"{destination.stat().st_size:,} B"
    )

# ==================== FROZEN PARAMETERS ====================

cost_config = json.loads(
    (STAGE / "reference/decode_cost_config.json")
    .read_text()
)

rank_table = np.load(
    STAGE / "reference/frozen_rank_table.npy"
)

NEW_C = float(
    cost_config["fitted_quadratic_c"]
)

OLD_C = 0.000102

LEVELS = tuple(fz.CTX_SIZES)
TARGETS = [64, 128]

RMAX = 4096

DENSE_LAMBDAS = np.concatenate([
    [0.0],
    np.geomspace(0.01, 10000, 121)
])

batch_plan = {
    32: 8,
    64: 8,
    128: 8,
    256: 4,
    512: 2
}

assert rank_table.shape == (4097,)
assert len(DENSE_LAMBDAS) == 122

print("\n=== FROZEN PARAMETERS ===")
print("Context levels:", LEVELS)
print("Target contexts:", TARGETS)
print("Rank table:", rank_table.shape)
print("Fitted quadratic c:", NEW_C)
print("Dense lambda candidates:", len(DENSE_LAMBDAS))
print("Full search configurations:", 4 * len(DENSE_LAMBDAS))

# ==================== DATASET RESTORE ====================

manifest = json.loads(
    (STAGE / "reference/dataset_manifest.json")
    .read_text()
)

datasets = {}
dataset_tokens = {}

print("\n=== RESTORE DATASETS ===")

for record in manifest:

    name = record["dataset"]

    raw = (
        A8.parent / "datasets" / f"{name}.txt"
    ).read_bytes()

    assert hashlib.sha256(
        raw
    ).hexdigest() == record["sha256"]

    tokens = np.load(
        A8 / f"{name}_tokens.npy"
    )

    datasets[name] = raw
    dataset_tokens[name] = tokens

    (STAGE / "datasets" / f"{name}.txt").write_bytes(raw)

    print(
        f"PASS | {name:15s} | "
        f"{len(raw):,} bytes | "
        f"{len(tokens):,} tokens"
    )

assert len(datasets) == 6

# ==================== BOTTLENECK ANALYSIS ====================

stage8_enc = json.loads(
    (E8 / "results/encode_benchmark.json").read_text()
)

bottleneck_rows = []

for r in stage8_enc:

    if r["family"] != "Adaptive":
        continue

    selection = r["selection"]

    analysis_s = float(selection["analysis_seconds"])
    search_s = float(selection["search_seconds"])
    codec_s = float(r["encode_seconds"])
    total_s = float(r["total_encode_seconds"])

    assert np.isclose(
        analysis_s + search_s + codec_s,
        total_s
    )

    bottleneck_rows.append({
        "dataset": r["dataset"],
        "context": r["context"],
        "analysis_seconds": analysis_s,
        "search_seconds": search_s,
        "codec_seconds": codec_s,
        "total_seconds": total_s,

        "analysis_pct":
            100 * analysis_s / total_s,

        "search_pct":
            100 * search_s / total_s,

        "codec_pct":
            100 * codec_s / total_s,

        "max_speedup_if_search_free":
            total_s / (analysis_s + codec_s)
    })

bottleneck_df = pd.DataFrame(
    bottleneck_rows
)

assert len(bottleneck_df) == 12

bottleneck_df.to_csv(
    STAGE / "results/stage8_bottleneck_analysis.csv",
    index=False
)

print("\n=== STAGE 8 BOTTLENECK BREAKDOWN ===")

display(bottleneck_df.round(4))

print("\n=== MEAN ENCODING COST DISTRIBUTION ===")

for column in [
    "analysis_pct",
    "search_pct",
    "codec_pct"
]:

    print(
        f"{column:15s}: "
        f"{bottleneck_df[column].mean():.4f}%"
    )

print(
    "Mean theoretical speedup "
    "if search cost is eliminated:",
    round(
        bottleneck_df[
            "max_speedup_if_search_free"
        ].mean(),
        4
    ),
    "x"
)

# ==================== SOURCE INSPECTION ====================

print("\n=== ANALYSIS IMPLEMENTATION ===")
print(inspect.getsource(s5.analyze))

print("\n=== DP IMPLEMENTATION ===")
print(inspect.getsource(s5.TreeDP))

print("\n=== FINAL STATUS ===")
print("References: PASS")
print("Datasets: 6/6 PASS")
print("Bottleneck comparisons: 12/12")
print("Original source modified: False")
print("CELL 2 DONE")

# ==================== CELL 5 ====================
# Stage 9 — Cell 3: Restore Model & Validate Analysis Cache

import gc
import time
import hashlib
import json
import numpy as np
import torch
import pandas as pd

from transformers import AutoTokenizer

DEVICE = "cuda:0"

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

print("=== LOAD TOKENIZER ===")

tokenizer = AutoTokenizer.from_pretrained("gpt2")

for name, tokens in dataset_tokens.items():

    restored = tokenizer.decode(
        tokens.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    assert restored == datasets[name]

    print(f"PASS | {name:15s} | Tokenizer exact")

# ==================== LOAD CODEC MODEL ====================

print("\n=== LOAD GPT-2 ===")

gc.collect()
torch.cuda.empty_cache()

t0 = time.perf_counter()

lm = fz.HFLM(
    name="gpt2",
    device=DEVICE,
    max_batch_tokens=1024,
    eps=None
)

torch.cuda.synchronize()

load_seconds = time.perf_counter() - t0

assert lm.V == 50257
assert lm.bos == 50256

assert next(
    lm.model.parameters()
).dtype == torch.float32

assert lm.model.config._attn_implementation == "sdpa"

model_config = {
    "name": "gpt2",
    "dtype": str(next(lm.model.parameters()).dtype),
    "attention": lm.model.config._attn_implementation,
    "vocab_size": lm.V,
    "bos": lm.bos,
    "gpu": torch.cuda.get_device_name(0),
    "torch": torch.__version__,
    "tf32": torch.backends.cuda.matmul.allow_tf32,
    "matmul_precision": torch.get_float32_matmul_precision(),
    "max_batch_tokens": lm.max_batch_tokens,
    "adapter_sha256": None
}

print(json.dumps(model_config, indent=2))
print("Load time:", round(load_seconds, 3), "s")

# ==================== RESTORE ANALYSIS CACHE ====================

print("\n=== VALIDATE STAGE 8 ANALYSIS CACHE ===")

analysis_cache = {}
padded_tokens = {}
cache_records = []

for name, tokens in dataset_tokens.items():

    toks_pad = fz.pad_tokens(tokens, lm.bos)

    padded_tokens[name] = toks_pad

    cache_path = A8 / f"{name}_analysis.npz"

    assert cache_path.is_file(), cache_path

    A = {}

    with np.load(
        cache_path,
        allow_pickle=False
    ) as cache:

        for L in LEVELS:

            bits = cache[f"L{L}_bits"].copy()
            ranks = cache[f"L{L}_ranks"].copy()

            expected_chunks = len(toks_pad) // L

            assert ranks.shape == (
                expected_chunks, L
            )

            assert bits.shape[0] == expected_chunks

            assert np.isfinite(bits).all()
            assert (bits >= 0).all()

            assert np.issubdtype(
                ranks.dtype,
                np.integer
            )

            assert (ranks >= 0).all()
            assert (ranks < lm.V).all()

            A[L] = {
                "bits": bits,
                "ranks": ranks
            }

            cache_records.append({
                "dataset": name,
                "context": int(L),
                "chunks": expected_chunks,
                "scored_tokens": int(ranks.size),
                "mean_nll_bits_per_token": float(
                    bits.sum() / ranks.size
                ),
                "mean_rank": float(ranks.mean()),
                "cache_sha256": hashlib.sha256(
                    cache_path.read_bytes()
                ).hexdigest()
            })

    analysis_cache[name] = A

    print(
        f"PASS | {name:15s} | "
        f"{len(toks_pad):,} padded tokens | "
        f"{len(A)} context levels"
    )

assert len(analysis_cache) == 6
assert len(cache_records) == 30

cache_df = pd.DataFrame(cache_records)

cache_df.to_csv(
    STAGE / "results/analysis_cache_validation.csv",
    index=False
)

# ==================== ABLATION CONFIGURATION ====================

REDUCED_LAMBDAS = np.unique(
    np.concatenate([
        DENSE_LAMBDAS[::4],
        [DENSE_LAMBDAS[-1]]
    ])
)

ABLATION_CONFIGS = {
    "BC-DP-Full": {
        "levels": [32, 64, 128, 256, 512],
        "lambda_grid": "dense"
    },

    "BC-DP-ReducedSearch": {
        "levels": [32, 64, 128, 256, 512],
        "lambda_grid": "reduced"
    },

    "BC-DP-ReducedLevels": {
        "levels": [32, 64, 128],
        "lambda_grid": "dense"
    },

    "Fast-BC-DP": {
        "levels": [32, 64, 128],
        "lambda_grid": "reduced"
    }
}

ablation_rows = []

print("\n=== ABLATION CONFIGURATIONS ===")

for name, config in ABLATION_CONFIGS.items():

    grid = (
        DENSE_LAMBDAS
        if config["lambda_grid"] == "dense"
        else REDUCED_LAMBDAS
    )

    ablation_rows.append({
        "method": name,
        "levels": str(config["levels"]),
        "context_levels": len(config["levels"]),
        "lambda_candidates": len(grid),
        "search_configurations": 4 * len(grid),
        "level_reduction_pct": 100 * (
            1 - len(config["levels"]) / len(LEVELS)
        ),
        "search_reduction_pct": 100 * (
            1 - len(grid) / len(DENSE_LAMBDAS)
        )
    })

ablation_df = pd.DataFrame(ablation_rows)

display(ablation_df.round(4))

ablation_df.to_csv(
    STAGE / "results/ablation_configurations.csv",
    index=False
)

config_record = {
    "model": model_config,
    "ablation_configs": ABLATION_CONFIGS,
    "dense_lambdas": DENSE_LAMBDAS.tolist(),
    "reduced_lambdas": REDUCED_LAMBDAS.tolist(),
    "target_contexts": TARGETS,
    "session_id": SESSION_ID
}

(STAGE / "results/stage9_configuration.json").write_text(
    json.dumps(config_record, indent=2),
    encoding="utf-8"
)

print("\n=== FINAL STATUS ===")
print("Tokenizer validation: 6/6 PASS")
print("Model configuration: PASS")
print("Analysis cache: 30/30 PASS")
print("Ablation configurations: 4/4")
print("Configuration saved: PASS")
print("CELL 3 DONE")

# ==================== CELL 6 ====================
# Stage 9 — Cell 4: Cached Ablation Search

import bz2
import time
import json
import hashlib
import numpy as np
import pandas as pd

# ==================== LATENCY MODELS ====================

stage7_latency = pd.read_csv(
    E7 / "results/latency_calibration_summary.csv"
) if (
    E7 / "results/latency_calibration_summary.csv"
).is_file() else None

# Frozen Stage 7 measured latency (seconds/chunk)
measured_cost = {
    32: 0.0977889428750131,
    64: 0.3924272889999827,
    128: 1.505137029874987,
    256: 6.030026267999972,
    512: 24.272794831499937
}

time_models = {
    "Fitted": lambda L: NEW_C * L**2,
    "Measured": lambda L: measured_cost[L]
}

# ==================== LAYOUT EVALUATION ====================

def evaluate_stage9_layout(leaves, analysis, n_pad):

    cursor = 0
    rank_parts = []

    counts = {
        int(L): 0 for L in LEVELS
    }

    for start, L in leaves:

        assert start == cursor
        assert start + L <= n_pad
        assert L in analysis

        rank_parts.append(
            analysis[L]["ranks"][start // L]
        )

        counts[L] += 1
        cursor += L

    assert cursor == n_pad

    ranks = np.concatenate(
        rank_parts
    ).astype("<u2")

    payload_bytes = len(
        bz2.compress(
            ranks.tobytes(),
            compresslevel=9
        )
    )

    flags = fz.layout_to_flags(
        leaves, n_pad
    )

    layout_bytes = (len(flags) + 7) // 8

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    layout_hash = hashlib.sha256(
        np.asarray(
            leaves,
            dtype=np.int64
        ).tobytes()
    ).hexdigest()

    return {
        "layout_sha256": layout_hash,
        "payload_bytes": payload_bytes,
        "layout_bytes": layout_bytes,
        "variable_bytes":
            payload_bytes + layout_bytes,
        "predicted_decode_s":
            predicted_decode_s,
        "effective_L": sum(
            counts[L] * L**2
            for L in LEVELS
        ) / n_pad,
        "chunk_counts": counts
    }


# ==================== FROZEN OBJECTIVES ====================

def build_stage9_objectives(analysis):

    cost_nll = s5.cost_ac(analysis)

    cost_rank = {}

    for L, values in analysis.items():

        ranks = values["ranks"]

        tail = np.where(
            ranks >= RMAX,
            np.log2(np.maximum(ranks, 1)),
            0.0
        )

        cost_rank[L] = (
            rank_table[
                np.minimum(ranks, RMAX)
            ].sum(axis=1)
            + tail.sum(axis=1)
        )

    return {
        "NLL": cost_nll,
        "Rank": cost_rank
    }


# ==================== ABLATION SEARCH ====================

def search_stage9(
    toks_pad,
    analysis,
    lambda_grid
):

    t0 = time.perf_counter()

    objectives = build_stage9_objectives(
        analysis
    )

    search_rows = []
    evaluated = {}
    layouts = {}

    for objective_name, cost in objectives.items():

        for time_name, time_fn in time_models.items():

            for lam in lambda_grid:

                policy = s5.TreeDP(
                    cost=cost,
                    lam=float(lam),
                    t_chunk=time_fn
                )

                leaves = policy(toks_pad)

                key = hashlib.sha256(
                    np.asarray(
                        leaves,
                        dtype=np.int64
                    ).tobytes()
                ).hexdigest()

                if key not in evaluated:

                    evaluated[key] = (
                        evaluate_stage9_layout(
                            leaves,
                            analysis,
                            len(toks_pad)
                        )
                    )

                    layouts[key] = leaves

                search_rows.append({
                    "objective": objective_name,
                    "time_model": time_name,
                    "lambda": float(lam),
                    **evaluated[key]
                })

    search_df = pd.DataFrame(search_rows)

    elapsed = time.perf_counter() - t0

    return search_df, layouts, elapsed


# ==================== LOAD STAGE 8 REFERENCE ====================

stage8_layouts = json.loads(
    (
        STAGE / "reference" /
        "stage8_selected_layouts.json"
    ).read_text()
)

ablation_results = []
ablation_layouts = {}

stage_start = time.perf_counter()

# ==================== RUN ALL DATASETS ====================

for dataset_name in datasets:

    print("\n" + "=" * 60)
    print("DATASET:", dataset_name)
    print("=" * 60)

    toks_pad = padded_tokens[dataset_name]

    full_analysis = analysis_cache[
        dataset_name
    ]

    fixed_reference = {}

    for target in TARGETS:

        leaves = fz.FixedPolicy(target)(
            toks_pad, lm, 8
        )

        fixed_reference[target] = (
            evaluate_stage9_layout(
                leaves,
                full_analysis,
                len(toks_pad)
            )
        )

    ablation_layouts[dataset_name] = {}

    for method, config in ABLATION_CONFIGS.items():

        # Only expose permitted context levels to DP
        analysis = {
            L: full_analysis[L]
            for L in config["levels"]
        }

        lambda_grid = (
            DENSE_LAMBDAS
            if config["lambda_grid"] == "dense"
            else REDUCED_LAMBDAS
        )

        search_df, layouts, search_seconds = (
            search_stage9(
                toks_pad,
                analysis,
                lambda_grid
            )
        )

        assert len(search_df) == (
            4 * len(lambda_grid)
        )

        search_df.to_csv(
            STAGE / "results" /
            f"{dataset_name}_{method}_search.csv",
            index=False
        )

        ablation_layouts[dataset_name][method] = {}

        for target in TARGETS:

            ref = fixed_reference[target]

            feasible = search_df[
                search_df["predicted_decode_s"]
                <= ref["predicted_decode_s"]
            ]

            assert not feasible.empty

            best = feasible.sort_values([
                "variable_bytes",
                "predicted_decode_s"
            ]).iloc[0]

            chosen_leaves = layouts[
                best["layout_sha256"]
            ]

            assert all(
                L in config["levels"]
                for _, L in chosen_leaves
            )

            original = stage8_layouts[
                dataset_name
            ][str(target)]["selection"]

            full_proxy_bytes = int(
                original["adaptive_variable_bytes"]
            )

            proxy_bytes = int(
                best["variable_bytes"]
            )

            matches_stage8 = (
                best["layout_sha256"]
                == original["layout_sha256"]
            )

            # The full ablation should recover the
            # same selected payload and latency.
            if method == "BC-DP-Full":

                assert proxy_bytes == full_proxy_bytes

                assert np.isclose(
                    best["predicted_decode_s"],
                    original["adaptive_pred_decode_s"]
                )

            result = {
                "dataset": dataset_name,
                "method": method,
                "target_context": int(target),

                "levels": config["levels"],

                "lambda_candidates":
                    len(lambda_grid),

                "search_configurations":
                    len(search_df),

                "unique_layouts":
                    len(layouts),

                "objective":
                    str(best["objective"]),

                "time_model":
                    str(best["time_model"]),

                "lambda":
                    float(best["lambda"]),

                "fixed_variable_bytes":
                    int(ref["variable_bytes"]),

                "adaptive_variable_bytes":
                    proxy_bytes,

                "full_bc_variable_bytes":
                    full_proxy_bytes,

                "size_saving_vs_fixed_pct": 100 * (
                    1 - proxy_bytes
                    / ref["variable_bytes"]
                ),

                "size_penalty_vs_full_bc_pct": 100 * (
                    proxy_bytes / full_proxy_bytes - 1
                ),

                "fixed_pred_decode_s":
                    float(ref["predicted_decode_s"]),

                "adaptive_pred_decode_s":
                    float(best["predicted_decode_s"]),

                "pred_decode_saving_pct": 100 * (
                    1 - best["predicted_decode_s"]
                    / ref["predicted_decode_s"]
                ),

                "effective_L":
                    float(best["effective_L"]),

                "cached_search_seconds":
                    search_seconds,

                "layout_sha256":
                    str(best["layout_sha256"]),

                "matches_stage8_layout":
                    bool(matches_stage8)
            }

            ablation_results.append(result)

            ablation_layouts[
                dataset_name
            ][method][str(target)] = {
                "selection": result,
                "leaves": [
                    [int(s), int(L)]
                    for s, L in chosen_leaves
                ]
            }

            print(
                f"{method:22s} | "
                f"Target={target:3d} | "
                f"Penalty vs Full: "
                f"{result['size_penalty_vs_full_bc_pct']:+.4f}% | "
                f"Pred decode saving: "
                f"{result['pred_decode_saving_pct']:+.4f}%"
            )

        print(
            f"Search time: {search_seconds:.3f}s | "
            f"Unique layouts: {len(layouts)}"
        )

    # Save checkpoint after each dataset
    pd.DataFrame(ablation_results).to_csv(
        STAGE / "results/cached_ablation_results.csv",
        index=False
    )

    (
        STAGE / "artifacts" /
        "stage9_ablation_layouts.json"
    ).write_text(
        json.dumps(
            ablation_layouts,
            indent=2
        )
    )

    print(f"CHECKPOINT: {dataset_name} PASS")


# ==================== FINAL SUMMARY ====================

cached_ablation_df = pd.DataFrame(
    ablation_results
)

assert len(cached_ablation_df) == 48

print("\n=== CACHED ABLATION SUMMARY ===")

display(
    cached_ablation_df[[
        "dataset",
        "method",
        "target_context",
        "adaptive_variable_bytes",
        "size_penalty_vs_full_bc_pct",
        "pred_decode_saving_pct",
        "cached_search_seconds"
    ]].round(4)
)

# ==================== AGGREGATE RESULTS ====================

aggregate = (
    cached_ablation_df
    .groupby("method")
    .agg(
        mean_size_penalty_pct=(
            "size_penalty_vs_full_bc_pct",
            "mean"
        ),
        max_size_penalty_pct=(
            "size_penalty_vs_full_bc_pct",
            "max"
        ),
        mean_pred_decode_saving_pct=(
            "pred_decode_saving_pct",
            "mean"
        ),
        mean_cached_search_s=(
            "cached_search_seconds",
            "mean"
        ),
        identical_stage8_layouts=(
            "matches_stage8_layout",
            "sum"
        )
    )
    .reset_index()
)

full_search_time = aggregate.loc[
    aggregate["method"] == "BC-DP-Full",
    "mean_cached_search_s"
].iloc[0]

aggregate["search_speedup"] = (
    full_search_time
    / aggregate["mean_cached_search_s"]
)

aggregate.to_csv(
    STAGE / "results/cached_ablation_aggregate.csv",
    index=False
)

print("\n=== AGGREGATE ABLATION RESULTS ===")

display(aggregate.round(4))

print("\n=== FINAL STATUS ===")
print("Datasets: 6/6")
print("Ablation methods: 4/4")
print("Selected configurations: 48/48")
print("Stage 8 full reference: PASS")
print("Checkpoints: SAVED")
print(
    "Elapsed:",
    round(time.perf_counter() - stage_start, 2),
    "seconds"
)
print("CELL 4 DONE")

# ==================== CELL 7 ====================
# Stage 9 — Cell 5: Fresh GPT-2 Analysis Benchmark

import gc
import time
import json
import hashlib
import torch
import numpy as np
import pandas as pd

ANALYSIS_VARIANTS = {
    "Full": tuple(LEVELS),
    "Reduced": (32, 64, 128)
}

ANALYSIS_REPEATS = 3

ANALYSIS_JSON = (
    STAGE / "results/fresh_analysis_benchmark.json"
)

analysis_benchmark_records = []

if ANALYSIS_JSON.is_file():
    analysis_benchmark_records = json.loads(
        ANALYSIS_JSON.read_text()
    )

analysis_completed = {
    (r["dataset"], r["variant"], r["repeat"]): r
    for r in analysis_benchmark_records
}

# ==================== WARM-UP ====================

print("=== GPU WARM-UP ===")

warmup_tokens = padded_tokens["enwik8_new"][:1024]

for L in LEVELS:

    warmup_result = s5.analyze(
        warmup_tokens,
        lm,
        batch=8,
        levels=(L,)
    )

    torch.cuda.synchronize()

    del warmup_result

    print(f"PASS | Context {L}")

# ==================== BENCHMARK FUNCTION ====================

def benchmark_fresh_analysis(
    dataset_name,
    variant,
    repeat
):

    levels = ANALYSIS_VARIANTS[variant]

    toks_pad = padded_tokens[dataset_name]

    cache_path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{variant}_fresh_analysis.npz"
    )

    key = (dataset_name, variant, repeat)

    if key in analysis_completed and cache_path.is_file():

        print(
            f"SKIP | {dataset_name} | "
            f"{variant} | repeat={repeat}"
        )

        return analysis_completed[key]

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    # Fresh inference — no reuse of Stage 8 cache
    analysis = s5.analyze(
        toks_pad,
        lm,
        batch=8,
        levels=levels
    )

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # Verification is outside timed region
    cache = {}

    rank_match = True
    nll_match = True
    max_nll_difference = 0.0
    scored_tokens = 0

    for L in levels:

        ranks = analysis[L]["ranks"]
        bits = analysis[L]["bits"]

        reference = analysis_cache[
            dataset_name
        ][L]

        assert ranks.shape == (
            len(toks_pad) // L, L
        )

        assert np.isfinite(bits).all()

        rank_match = rank_match and bool(
            np.array_equal(
                ranks,
                reference["ranks"]
            )
        )

        nll_match = nll_match and bool(
            np.allclose(
                bits,
                reference["bits"],
                rtol=1e-5,
                atol=1e-5
            )
        )

        if bits.size:

            max_nll_difference = max(
                max_nll_difference,
                float(np.max(np.abs(
                    bits - reference["bits"]
                )))
            )

        scored_tokens += int(ranks.size)

        cache[f"L{L}_ranks"] = ranks
        cache[f"L{L}_bits"] = bits

    # Cache fresh inference for subsequent encode
    np.savez_compressed(
        cache_path,
        **cache
    )

    record = {
        "dataset": dataset_name,
        "variant": variant,
        "repeat": repeat,
        "levels": list(levels),
        "context_count": len(levels),
        "original_tokens": len(
            dataset_tokens[dataset_name]
        ),
        "scored_tokens": scored_tokens,
        "analysis_seconds": elapsed,
        "analysis_peak_mib": peak_mib,
        "rank_match_stage8": rank_match,
        "nll_match_stage8": nll_match,
        "max_nll_difference": max_nll_difference,
        "cache_sha256": hashlib.sha256(
            cache_path.read_bytes()
        ).hexdigest(),
        "session_id": SESSION_ID,
        "gpu_name": torch.cuda.get_device_name(0)
    }

    # Save checkpoint
    analysis_benchmark_records[:] = [
        r for r in analysis_benchmark_records
        if (
            r["dataset"],
            r["variant"],
            r["repeat"]
        ) != key
    ]

    analysis_benchmark_records.append(record)

    analysis_completed[key] = record

    temp = ANALYSIS_JSON.with_suffix(".tmp")

    temp.write_text(
        json.dumps(
            analysis_benchmark_records,
            indent=2
        )
    )

    temp.replace(ANALYSIS_JSON)

    pd.DataFrame(
        analysis_benchmark_records
    ).to_csv(
        STAGE / "results/fresh_analysis_benchmark.csv",
        index=False
    )

    print(
        f"{variant:8s} | "
        f"Repeat {repeat} | "
        f"{elapsed:.4f}s | "
        f"GPU {peak_mib:.2f} MiB | "
        f"Rank match={rank_match} | "
        f"NLL match={nll_match}",
        flush=True
    )

    del analysis, cache
    gc.collect()

    return record


# ==================== RUN BENCHMARK ====================

stage_start = time.perf_counter()

for dataset_name in datasets:

    print("\n" + "=" * 60)
    print("DATASET:", dataset_name)
    print("=" * 60)

    for repeat in range(
        1,
        ANALYSIS_REPEATS + 1
    ):

        order = (
            ["Full", "Reduced"]
            if repeat % 2 == 1
            else ["Reduced", "Full"]
        )

        for variant in order:

            benchmark_fresh_analysis(
                dataset_name,
                variant,
                repeat
            )

    print(
        f"CHECKPOINT: {dataset_name} PASS"
    )


# ==================== SUMMARY ====================

fresh_analysis_df = pd.DataFrame(
    analysis_benchmark_records
)

assert len(fresh_analysis_df) == 36

analysis_summary_df = (
    fresh_analysis_df
    .groupby(["dataset", "variant"])
    .agg(
        repeats=("analysis_seconds", "count"),
        mean_analysis_s=("analysis_seconds", "mean"),
        median_analysis_s=("analysis_seconds", "median"),
        std_analysis_s=("analysis_seconds", "std"),
        peak_gpu_mib=("analysis_peak_mib", "max"),
        rank_match=("rank_match_stage8", "all"),
        nll_match=("nll_match_stage8", "all")
    )
    .reset_index()
)

analysis_summary_df["cv_pct"] = (
    100
    * analysis_summary_df["std_analysis_s"]
    / analysis_summary_df["mean_analysis_s"]
)

analysis_summary_df.to_csv(
    STAGE / "results/fresh_analysis_summary.csv",
    index=False
)

print("\n=== FRESH ANALYSIS SUMMARY ===")

display(analysis_summary_df.round(4))


# ==================== PAIRED ANALYSIS SAVINGS ====================

analysis_pairs = []

for dataset_name in datasets:

    subset = analysis_summary_df[
        analysis_summary_df["dataset"] == dataset_name
    ]

    full = subset[
        subset["variant"] == "Full"
    ].iloc[0]

    reduced = subset[
        subset["variant"] == "Reduced"
    ].iloc[0]

    full_time = float(
        full["median_analysis_s"]
    )

    reduced_time = float(
        reduced["median_analysis_s"]
    )

    analysis_pairs.append({
        "dataset": dataset_name,
        "full_analysis_s": full_time,
        "reduced_analysis_s": reduced_time,
        "analysis_saving_pct": 100 * (
            1 - reduced_time / full_time
        ),
        "analysis_speedup":
            full_time / reduced_time,
        "full_gpu_mib": float(full["peak_gpu_mib"]),
        "reduced_gpu_mib": float(reduced["peak_gpu_mib"]),
        "rank_match": bool(
            full["rank_match"]
            and reduced["rank_match"]
        ),
        "nll_match": bool(
            full["nll_match"]
            and reduced["nll_match"]
        )
    })

analysis_pair_df = pd.DataFrame(
    analysis_pairs
)

analysis_pair_df.to_csv(
    STAGE / "results/fresh_analysis_comparison.csv",
    index=False
)

print("\n=== PAIRED ANALYSIS COMPARISON ===")

display(analysis_pair_df.round(4))

print("\n=== AGGREGATE ===")

print(
    "Mean analysis saving:",
    round(
        analysis_pair_df[
            "analysis_saving_pct"
        ].mean(),
        4
    ),
    "%"
)

print(
    "Mean analysis speedup:",
    round(
        analysis_pair_df[
            "analysis_speedup"
        ].mean(),
        4
    ),
    "x"
)

print(
    "Rank consistency:",
    int(
        fresh_analysis_df[
            "rank_match_stage8"
        ].sum()
    ),
    "/ 36"
)

print(
    "NLL consistency:",
    int(
        fresh_analysis_df[
            "nll_match_stage8"
        ].sum()
    ),
    "/ 36"
)

print(
    "Elapsed:",
    round(
        (time.perf_counter() - stage_start) / 60,
        2
    ),
    "minutes"
)

print("\n=== FINAL STATUS ===")
print("Datasets: 6/6")
print("Fresh analysis measurements: 36/36")
print("Checkpoints: SAVED")
print("CELL 5 DONE")

# ==================== CELL 8 ====================
# Stage 9 — Cell 6: End-to-End Encoding Ablation Benchmark

import gc
import time
import json
import hashlib
import numpy as np
import pandas as pd
import torch

ENCODE_JSON9 = (
    STAGE / "results/encode_ablation.json"
)

ENCODE_CSV9 = (
    STAGE / "results/encode_ablation.csv"
)

encode_records9 = (
    json.loads(ENCODE_JSON9.read_text())
    if ENCODE_JSON9.is_file()
    else []
)

encode_completed9 = {
    (r["dataset"], r["method"], r["context"]): r
    for r in encode_records9
}

METHODS9 = [
    "Fixed",
    "BC-DP-Full",
    "BC-DP-ReducedSearch",
    "BC-DP-ReducedLevels",
    "Fast-BC-DP"
]

# ==================== BENCHMARK FUNCTION ====================

def encode_stage9(dataset_name, method, target):

    key = (dataset_name, method, target)

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]
    toks_pad = padded_tokens[dataset_name]

    artifact_path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}_{target}.fzac"
    )

    if key in encode_completed9:

        previous = encode_completed9[key]

        assert artifact_path.is_file()

        assert hashlib.sha256(
            artifact_path.read_bytes()
        ).hexdigest() == previous["artifact_sha256"]

        print(f"SKIP | {key}")

        return previous

    print(
        f"\n=== ENCODE: {dataset_name} | "
        f"{method} | Target={target} ===",
        flush=True
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    analysis_seconds = 0.0
    search_seconds = 0.0

    selection = None

    start_total = time.perf_counter()

    # ==================== FIXED POLICY ====================

    if method == "Fixed":

        policy = fz.FixedPolicy(target)

        levels = [target]
        proposals = 0
        unique_layouts = 0

    # ==================== ADAPTIVE POLICY ====================

    else:

        config = ABLATION_CONFIGS[method]

        levels = config["levels"]

        lambda_grid = (
            DENSE_LAMBDAS
            if config["lambda_grid"] == "dense"
            else REDUCED_LAMBDAS
        )

        # Fresh GPU inference
        t0 = time.perf_counter()

        analysis = s5.analyze(
            toks_pad,
            lm,
            batch=8,
            levels=tuple(levels)
        )

        torch.cuda.synchronize()

        analysis_seconds = (
            time.perf_counter() - t0
        )

        # Fresh layout search
        t0 = time.perf_counter()

        fixed_leaves = fz.FixedPolicy(target)(
            toks_pad, lm, 8
        )

        fixed_reference = evaluate_stage9_layout(
            fixed_leaves,
            analysis,
            len(toks_pad)
        )

        search_df, layouts, _ = search_stage9(
            toks_pad,
            analysis,
            lambda_grid
        )

        feasible = search_df[
            search_df["predicted_decode_s"]
            <= fixed_reference["predicted_decode_s"]
        ]

        assert not feasible.empty

        best = feasible.sort_values([
            "variable_bytes",
            "predicted_decode_s"
        ]).iloc[0]

        chosen_leaves = layouts[
            best["layout_sha256"]
        ]

        search_seconds = (
            time.perf_counter() - t0
        )

        proposals = len(search_df)
        unique_layouts = len(layouts)

        # Verify against cached screening
        expected = ablation_layouts[
            dataset_name
        ][method][str(target)]["selection"]

        selection = {
            "objective": str(best["objective"]),
            "time_model": str(best["time_model"]),
            "lambda": float(best["lambda"]),

            "layout_sha256": str(
                best["layout_sha256"]
            ),

            "variable_bytes": int(
                best["variable_bytes"]
            ),

            "predicted_budget_s": float(
                fixed_reference["predicted_decode_s"]
            ),

            "matches_cached_layout": bool(
                best["layout_sha256"]
                == expected["layout_sha256"]
            )
        }

        def policy(
            toks, model, batch,
            leaves=chosen_leaves
        ):
            return leaves

    # ==================== REAL CODEC ENCODE ====================

    torch.cuda.synchronize()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    codec_seconds = (
        time.perf_counter() - t0
    )

    total_encode_seconds = (
        time.perf_counter() - start_total
    )

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LAYOUT VERIFICATION ====================

    counts = {
        int(L): int(sum(
            length == L
            for _, length in leaves
        ))
        for L in LEVELS
    }

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    layout_sha256 = hashlib.sha256(
        np.asarray(
            leaves, dtype=np.int64
        ).tobytes()
    ).hexdigest()

    if method != "Fixed":

        assert layout_sha256 == (
            selection["layout_sha256"]
        )

        assert predicted_decode_s <= (
            selection["predicted_budget_s"]
            + 1e-8
        )

        assert all(
            L in levels
            for _, L in leaves
        )

    # ==================== SAVE ARTIFACT ====================

    artifact_path.write_bytes(blob)

    artifact_sha256 = hashlib.sha256(
        blob
    ).hexdigest()

    assert hashlib.sha256(
        artifact_path.read_bytes()
    ).hexdigest() == artifact_sha256

    record = {
        "dataset": dataset_name,
        "method": method,
        "context": int(target),
        "levels": list(levels),
        "search_configurations": proposals,
        "unique_layouts": unique_layouts,

        "original_bytes": len(raw),
        "original_sha256": hashlib.sha256(
            raw
        ).hexdigest(),

        "tokens": len(tokens),
        "padded_tokens": len(toks_pad),

        "compressed_bytes": len(blob),
        "ratio": len(raw) / len(blob),
        "bpb": 8 * len(blob) / len(raw),

        "analysis_seconds": analysis_seconds,
        "search_seconds": search_seconds,
        "codec_seconds": codec_seconds,
        "total_encode_seconds": total_encode_seconds,
        "encode_peak_mib": peak_mib,

        "predicted_decode_s": predicted_decode_s,

        "effective_L": sum(
            int(L)**2 for _, L in leaves
        ) / len(toks_pad),

        "chunk_counts": counts,
        "layout_sha256": layout_sha256,

        "selection": selection,

        "artifact_path": str(artifact_path),
        "artifact_sha256": artifact_sha256,

        "encode_session_id": SESSION_ID,
        "gpu_name": torch.cuda.get_device_name(0),

        "full_decode": "PENDING"
    }

    encode_records9.append(record)
    encode_completed9[key] = record

    # Atomic checkpoint
    temp = ENCODE_JSON9.with_suffix(".tmp")

    temp.write_text(
        json.dumps(encode_records9, indent=2)
    )

    temp.replace(ENCODE_JSON9)

    pd.DataFrame(encode_records9).to_csv(
        ENCODE_CSV9,
        index=False
    )

    print("Compressed:", len(blob), "B")
    print("Analysis:", round(analysis_seconds, 4), "s")
    print("Search:", round(search_seconds, 4), "s")
    print("Codec:", round(codec_seconds, 4), "s")
    print("Total encode:", round(total_encode_seconds, 4), "s")

    print(
        "Peak GPU:",
        round(peak_mib, 2),
        "MiB"
    )

    print(
        f"CHECKPOINT: {len(encode_records9)}/60"
    )

    return record


# ==================== RUN BENCHMARK ====================

stage_start = time.perf_counter()

for dataset_name in datasets:

    print("\n" + "=" * 60)
    print("DATASET:", dataset_name)
    print("=" * 60)

    for target in TARGETS:

        for method in METHODS9:

            encode_stage9(
                dataset_name,
                method,
                target
            )

    print(
        f"DATASET {dataset_name}: 10/10 PASS"
    )


# ==================== ENCODE SUMMARY ====================

encode_df9 = pd.DataFrame(encode_records9)

assert len(encode_df9) == 60

assert not encode_df9.duplicated([
    "dataset", "method", "context"
]).any()

print("\n=== ENCODE ABLATION SUMMARY ===")

display(encode_df9[[
    "dataset",
    "method",
    "context",
    "compressed_bytes",
    "bpb",
    "analysis_seconds",
    "search_seconds",
    "codec_seconds",
    "total_encode_seconds",
    "encode_peak_mib"
]].round(4))


# ==================== COMPARE WITH FULL BC-DP ====================

comparison_records9 = []

for dataset_name in datasets:

    for target in TARGETS:

        full = encode_completed9[
            (dataset_name, "BC-DP-Full", target)
        ]

        fixed = encode_completed9[
            (dataset_name, "Fixed", target)
        ]

        for method in METHODS9[1:]:

            current = encode_completed9[
                (dataset_name, method, target)
            ]

            comparison_records9.append({
                "dataset": dataset_name,
                "method": method,
                "context": target,

                "compressed_bytes":
                    current["compressed_bytes"],

                "size_penalty_vs_full_pct": 100 * (
                    current["compressed_bytes"]
                    / full["compressed_bytes"] - 1
                ),

                "size_saving_vs_fixed_pct": 100 * (
                    1 - current["compressed_bytes"]
                    / fixed["compressed_bytes"]
                ),

                "encode_saving_vs_full_pct": 100 * (
                    1 - current["total_encode_seconds"]
                    / full["total_encode_seconds"]
                ),

                "encode_speedup_vs_full":
                    full["total_encode_seconds"]
                    / current["total_encode_seconds"],

                "encode_slowdown_vs_fixed":
                    current["total_encode_seconds"]
                    / fixed["total_encode_seconds"],

                "pred_decode_saving_vs_fixed_pct": 100 * (
                    1 - current["predicted_decode_s"]
                    / fixed["predicted_decode_s"]
                ),

                "matches_cached_layout":
                    current["selection"][
                        "matches_cached_layout"
                    ]
            })

comparison_df9 = pd.DataFrame(
    comparison_records9
)

comparison_df9.to_csv(
    STAGE / "results/encode_ablation_comparison.csv",
    index=False
)

aggregate_df9 = (
    comparison_df9
    .groupby("method")
    .agg(
        mean_size_penalty_pct=(
            "size_penalty_vs_full_pct", "mean"
        ),

        max_size_penalty_pct=(
            "size_penalty_vs_full_pct", "max"
        ),

        mean_encode_saving_pct=(
            "encode_saving_vs_full_pct", "mean"
        ),

        mean_encode_speedup=(
            "encode_speedup_vs_full", "mean"
        ),

        mean_slowdown_vs_fixed=(
            "encode_slowdown_vs_fixed", "mean"
        ),

        mean_pred_decode_saving_pct=(
            "pred_decode_saving_vs_fixed_pct", "mean"
        ),

        cached_layout_matches=(
            "matches_cached_layout", "sum"
        )
    )
    .reset_index()
)

aggregate_df9.to_csv(
    STAGE / "results/encode_ablation_aggregate.csv",
    index=False
)

print("\n=== AGGREGATE ENCODE ABLATION ===")

display(aggregate_df9.round(4))

print("\n=== FINAL STATUS ===")
print("Encode: 60/60")
print("Comparisons: 48/48")
print("Datasets: 6/6")
print("Methods: 5/5")

print(
    "Estimated decode time for all artifacts:",
    round(
        encode_df9["predicted_decode_s"].sum()
        / 3600,
        2
    ),
    "hours"
)

print(
    "Elapsed:",
    round(
        (time.perf_counter() - stage_start) / 60,
        2
    ),
    "minutes"
)

print("Artifacts and checkpoints: SAVED")
print("CELL 6 DONE")

# ==================== CELL 9 ====================
# Stage 9 — Cell 7: Artifact Deduplication & Lossless Audit

import json
import hashlib
import pandas as pd

from pathlib import Path

# ==================== LOAD RESULTS ====================

encode_records9 = json.loads(
    ENCODE_JSON9.read_text()
)

stage8_decode_records = json.loads(
    (E8 / "results/decode_benchmark.json").read_text()
)

assert len(encode_records9) == 60
assert len(stage8_decode_records) == 24

# ==================== VERIFY STAGE 8 EVIDENCE ====================

verified_stage8 = {}

print("=== VERIFY STAGE 8 LOSSLESS EVIDENCE ===")

for r in stage8_decode_records:

    assert r["full_decode"] == "PASS"
    assert r["token_exact"]
    assert r["byte_exact"]
    assert r["sha_exact"]

    name = r["dataset"]
    method = r["method"]

    artifact_path = (
        A8 / f"{name}_{method}.fzac"
    )

    decoded_path = (
        A8 / f"{name}_{method}_decoded.txt"
    )

    assert artifact_path.is_file()
    assert decoded_path.is_file()

    assert hashlib.sha256(
        artifact_path.read_bytes()
    ).hexdigest() == r["artifact_sha256"]

    assert hashlib.sha256(
        decoded_path.read_bytes()
    ).hexdigest() == r["original_sha256"]

    key = (
        r["original_sha256"],
        r["artifact_sha256"]
    )

    verified_stage8[key] = r

print("Stage 8 evidence: 24/24 PASS")
print(
    "Unique verified Stage 8 artifacts:",
    len(verified_stage8)
)

# ==================== AUDIT STAGE 9 ARTIFACTS ====================

audit_records = []
pending_groups = {}

print("\n=== STAGE 9 ARTIFACT AUDIT ===")

for r in encode_records9:

    name = r["dataset"]
    method = r["method"]
    target = r["context"]

    artifact_path = (
        STAGE / "artifacts" /
        f"{name}_{method}_{target}.fzac"
    )

    assert artifact_path.is_file()

    blob = artifact_path.read_bytes()

    artifact_sha = hashlib.sha256(
        blob
    ).hexdigest()

    original_sha = hashlib.sha256(
        datasets[name]
    ).hexdigest()

    assert artifact_sha == r["artifact_sha256"]
    assert original_sha == r["original_sha256"]
    assert len(blob) == r["compressed_bytes"]

    key = (original_sha, artifact_sha)

    audit = {
        "dataset": name,
        "method": method,
        "context": int(target),
        "compressed_bytes": len(blob),
        "original_sha256": original_sha,
        "artifact_sha256": artifact_sha,
        "predicted_decode_s": float(
            r["predicted_decode_s"]
        ),
        "artifact_path": str(artifact_path)
    }

    if key in verified_stage8:

        ref = verified_stage8[key]

        audit.update({
            "verification_status":
                "PASS_STAGE8_IDENTICAL",

            "evidence_source":
                "Stage8-Session01",

            "reference_dataset":
                ref["dataset"],

            "reference_method":
                ref["method"],

            "lossless_verified": True,

            "fresh_stage9_decode": False,

            "requires_unique_decode": False
        })

    else:

        audit.update({
            "verification_status":
                "PENDING_STAGE9",

            "evidence_source": None,
            "reference_dataset": None,
            "reference_method": None,

            "lossless_verified": False,
            "fresh_stage9_decode": False,

            "requires_unique_decode":
                key not in pending_groups
        })

        pending_groups.setdefault(
            key, []
        ).append(audit)

    audit_records.append(audit)

    print(
        f"{name:15s} | "
        f"{method:22s} | "
        f"{target:3d} | "
        f"{audit['verification_status']}"
    )


# ==================== UNIQUE DECODE QUEUE ====================

decode_queue = []

for key, members in pending_groups.items():

    representative = members[0]

    decode_queue.append({
        "dataset":
            representative["dataset"],

        "method":
            representative["method"],

        "context":
            representative["context"],

        "original_sha256":
            representative["original_sha256"],

        "artifact_sha256":
            representative["artifact_sha256"],

        "artifact_path":
            representative["artifact_path"],

        "predicted_decode_s":
            representative["predicted_decode_s"],

        "covered_configurations":
            len(members),

        "aliases": [
            {
                "dataset": m["dataset"],
                "method": m["method"],
                "context": m["context"]
            }
            for m in members
        ]
    })

# ==================== SAVE CHECKPOINTS ====================

audit_df = pd.DataFrame(audit_records)

queue_df = pd.DataFrame(decode_queue)

assert len(audit_df) == 60

audit_df.to_csv(
    STAGE / "results/artifact_audit.csv",
    index=False
)

(STAGE / "results/artifact_audit.json").write_text(
    json.dumps(audit_records, indent=2)
)

(STAGE / "artifacts/stage9_decode_queue.json").write_text(
    json.dumps(decode_queue, indent=2)
)

queue_df.to_csv(
    STAGE / "results/stage9_decode_queue.csv",
    index=False
)

# ==================== SUMMARY ====================

verified_count = int(
    audit_df["lossless_verified"].sum()
)

pending_count = 60 - verified_count

estimated_all_seconds = sum(
    r["predicted_decode_s"]
    for r in encode_records9
)

estimated_unique_seconds = sum(
    r["predicted_decode_s"]
    for r in decode_queue
)

assert sum(
    r["covered_configurations"]
    for r in decode_queue
) == pending_count

print("\n=== AUDIT SUMMARY BY METHOD ===")

display(
    audit_df.groupby("method").agg(
        configurations=("method", "count"),
        verified_stage8=("lossless_verified", "sum"),
        unique_new_artifacts=(
            "requires_unique_decode", "sum"
        )
    ).reset_index()
)

print("\n=== UNIQUE DECODE QUEUE ===")

if not queue_df.empty:

    display(queue_df[[
        "dataset",
        "method",
        "context",
        "covered_configurations",
        "predicted_decode_s"
    ]].round(4))

print("\n=== FINAL AUDIT STATUS ===")

print("Stage 9 artifacts: 60/60 PASS")
print("Verified by Stage 8 SHA-256:", verified_count)
print("Pending configuration verification:", pending_count)
print("Unique new artifacts to decode:", len(decode_queue))

print(
    "Estimated decode without deduplication:",
    round(estimated_all_seconds / 3600, 3),
    "hours"
)

print(
    "Estimated unique lossless verification:",
    round(estimated_unique_seconds / 3600, 3),
    "hours"
)

print(
    "Estimated decode workload reduction:",
    round(
        100 * (
            1 - estimated_unique_seconds
            / estimated_all_seconds
        ),
        2
    ),
    "%"
)

print("Decode queue saved: PASS")
print("CELL 7 DONE")

# ==================== CELL 10 ====================
# Stage 9 — Cell 8: Initialize Unique Full Decode

import gc
import time
import json
import hashlib
import torch
import numpy as np
import pandas as pd

DECODE_JSON9 = STAGE / "results/unique_decode_results.json"
DECODE_CSV9 = STAGE / "results/unique_decode_results.csv"

AUDIT_JSON9 = STAGE / "results/artifact_audit.json"
AUDIT_CSV9 = STAGE / "results/artifact_audit.csv"

decode_queue = json.loads(
    (STAGE / "artifacts/stage9_decode_queue.json").read_text()
)

audit_records = json.loads(
    AUDIT_JSON9.read_text()
)

decode_records9 = (
    json.loads(DECODE_JSON9.read_text())
    if DECODE_JSON9.is_file()
    else []
)

assert len(decode_queue) == 15
assert len(audit_records) == 60

DECODED_DIR9 = STAGE / "artifacts/decoded_unique"

DECODED_DIR9.mkdir(
    parents=True,
    exist_ok=True
)

# ==================== ATOMIC JSON SAVE ====================

def save_json_stage9(path, data):

    temp = path.with_suffix(".tmp")

    temp.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8"
    )

    temp.replace(path)


# ==================== UPDATE AUDIT ====================

def update_lossless_audit9(result):

    assert result["full_decode"] == "PASS"

    key = (
        result["original_sha256"],
        result["artifact_sha256"]
    )

    updated = 0

    for audit in audit_records:

        audit_key = (
            audit["original_sha256"],
            audit["artifact_sha256"]
        )

        if audit_key != key:
            continue

        direct = (
            audit["dataset"] == result["dataset"]
            and audit["method"] == result["method"]
            and audit["context"] == result["context"]
        )

        audit.update({

            "verification_status": (
                "PASS_STAGE9_DIRECT"
                if direct
                else "PASS_STAGE9_IDENTICAL"
            ),

            "lossless_verified": True,

            "fresh_stage9_decode": direct,

            "evidence_source": result[
                "decode_session_id"
            ],

            "reference_dataset": result["dataset"],

            "reference_method": result["method"],

            "reference_context": result["context"],

            "decoded_sha256": result["decoded_sha256"]
        })

        updated += 1

    assert updated == result[
        "covered_configurations"
    ]

    save_json_stage9(
        AUDIT_JSON9,
        audit_records
    )

    pd.DataFrame(audit_records).to_csv(
        AUDIT_CSV9,
        index=False
    )

    return updated


# ==================== UNIQUE DECODE FUNCTION ====================

def decode_unique_stage9(item):

    dataset_name = item["dataset"]
    method = item["method"]
    context = item["context"]

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    blob_path = Path(item["artifact_path"])
    blob = blob_path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == item["artifact_sha256"]

    assert hashlib.sha256(
        raw
    ).hexdigest() == item["original_sha256"]

    decoded_path = (
        DECODED_DIR9 /
        f"{dataset_name}_{method}_{context}_decoded.txt"
    )

    previous = next(
        (
            r for r in decode_records9
            if r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
            and r["full_decode"] == "PASS"
        ),
        None
    )

    if previous is not None and decoded_path.is_file():

        assert hashlib.sha256(
            decoded_path.read_bytes()
        ).hexdigest() == item["original_sha256"]

        update_lossless_audit9(previous)

        print(
            f"SKIP | {dataset_name} | "
            f"{method} | {context}"
        )

        return previous

    print(
        f"\n=== UNIQUE DECODE: {dataset_name} | "
        f"{method} | Context={context} ===",
        flush=True
    )

    print(
        "Covered configurations:",
        item["covered_configurations"]
    )

    print(
        "Predicted decode:",
        round(item["predicted_decode_s"], 4),
        "s"
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded = fz.decode(
        blob,
        lm
    )

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LOSSLESS VERIFICATION ====================

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, tokens)
    )

    byte_exact = decoded_raw == raw

    decoded_sha = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    sha_exact = (
        decoded_sha == item["original_sha256"]
    )

    passed = (
        token_exact
        and byte_exact
        and sha_exact
    )

    result = {
        **item,

        "compressed_bytes": len(blob),

        "decode_seconds": elapsed,

        "decode_minutes": elapsed / 60,

        "decode_peak_mib": peak_mib,

        "decode_bytes_per_second":
            len(raw) / elapsed,

        "prediction_error_pct": 100 * abs(
            item["predicted_decode_s"] - elapsed
        ) / elapsed,

        "decoded_tokens": len(decoded),

        "decoded_bytes": len(decoded_raw),

        "token_exact": token_exact,

        "byte_exact": byte_exact,

        "sha_exact": sha_exact,

        "decoded_sha256": decoded_sha,

        "decode_session_id": SESSION_ID,

        "decode_gpu_name":
            torch.cuda.get_device_name(0),

        "decode_gpu_id": 0,

        "full_decode": (
            "PASS" if passed else "FAIL"
        ),

        "decoded_path": str(decoded_path)
    }

    # ==================== CHECKPOINT ====================

    decoded_path.write_bytes(decoded_raw)

    decode_records9[:] = [
        r for r in decode_records9
        if not (
            r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
        )
    ]

    decode_records9.append(result)

    save_json_stage9(
        DECODE_JSON9,
        decode_records9
    )

    pd.DataFrame(decode_records9).to_csv(
        DECODE_CSV9,
        index=False
    )

    assert passed, "Lossless verification failed"

    covered = update_lossless_audit9(
        result
    )

    verified_count = sum(
        r["lossless_verified"]
        for r in audit_records
    )

    direct_count = sum(
        r["full_decode"] == "PASS"
        for r in decode_records9
    )

    print("Actual decode:", round(elapsed, 4), "s")
    print("GPU peak:", round(peak_mib, 4), "MiB")
    print("Token exact:", token_exact)
    print("Byte exact:", byte_exact)
    print("SHA-256 exact:", sha_exact)
    print("SHA-256:", decoded_sha)

    print("Newly covered configurations:", covered)

    print(
        f"Unique decode checkpoint: "
        f"{direct_count}/15"
    )

    print(
        f"Lossless verified configurations: "
        f"{verified_count}/60"
    )

    print("STATUS: PASS")

    return result


# ==================== DATASET DECODE FUNCTION ====================

def benchmark_unique_dataset9(dataset_name):

    items = [
        item for item in decode_queue
        if item["dataset"] == dataset_name
    ]

    rows = []

    for item in items:

        rows.append(
            decode_unique_stage9(item)
        )

    df = pd.DataFrame(rows)

    df.to_csv(
        STAGE / "results" /
        f"{dataset_name}_unique_decode.csv",
        index=False
    )

    print("\n=== DATASET UNIQUE DECODE SUMMARY ===")

    if not df.empty:

        display(df[[
            "dataset",
            "method",
            "context",
            "covered_configurations",
            "compressed_bytes",
            "decode_seconds",
            "decode_peak_mib",
            "byte_exact",
            "full_decode"
        ]].round(4))

    print(
        f"DATASET {dataset_name}: "
        f"{len(rows)}/{len(items)} PASS"
    )

    return df


# ==================== DECODE PLAN ====================

print("=== STAGE 9 UNIQUE DECODE PLAN ===")

plan_rows = []

for name in datasets:

    items = [
        item for item in decode_queue
        if item["dataset"] == name
    ]

    plan_rows.append({
        "dataset": name,

        "unique_artifacts": len(items),

        "covered_configurations": sum(
            item["covered_configurations"]
            for item in items
        ),

        "estimated_minutes": sum(
            item["predicted_decode_s"]
            for item in items
        ) / 60
    })

plan_df = pd.DataFrame(plan_rows)

display(plan_df.round(4))

plan_df.to_csv(
    STAGE / "results/unique_decode_plan.csv",
    index=False
)

print("\n=== FINAL STATUS ===")

print("Unique decode function: READY")
print("Audit update function: READY")
print("Unique artifacts:", len(decode_queue))

print(
    "Verified configurations:",
    sum(r["lossless_verified"] for r in audit_records),
    "/ 60"
)

print("CELL 8 DONE")

# ==================== CELL 11 ====================
# Stage 9 — Cell 8: Initialize Unique Full Decode

import gc
import time
import json
import hashlib
import torch
import numpy as np
import pandas as pd

DECODE_JSON9 = STAGE / "results/unique_decode_results.json"
DECODE_CSV9 = STAGE / "results/unique_decode_results.csv"

AUDIT_JSON9 = STAGE / "results/artifact_audit.json"
AUDIT_CSV9 = STAGE / "results/artifact_audit.csv"

decode_queue = json.loads(
    (STAGE / "artifacts/stage9_decode_queue.json").read_text()
)

audit_records = json.loads(
    AUDIT_JSON9.read_text()
)

decode_records9 = (
    json.loads(DECODE_JSON9.read_text())
    if DECODE_JSON9.is_file()
    else []
)

assert len(decode_queue) == 15
assert len(audit_records) == 60

DECODED_DIR9 = STAGE / "artifacts/decoded_unique"

DECODED_DIR9.mkdir(
    parents=True,
    exist_ok=True
)

# ==================== ATOMIC JSON SAVE ====================

def save_json_stage9(path, data):

    temp = path.with_suffix(".tmp")

    temp.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8"
    )

    temp.replace(path)


# ==================== UPDATE AUDIT ====================

def update_lossless_audit9(result):

    assert result["full_decode"] == "PASS"

    key = (
        result["original_sha256"],
        result["artifact_sha256"]
    )

    updated = 0

    for audit in audit_records:

        audit_key = (
            audit["original_sha256"],
            audit["artifact_sha256"]
        )

        if audit_key != key:
            continue

        direct = (
            audit["dataset"] == result["dataset"]
            and audit["method"] == result["method"]
            and audit["context"] == result["context"]
        )

        audit.update({

            "verification_status": (
                "PASS_STAGE9_DIRECT"
                if direct
                else "PASS_STAGE9_IDENTICAL"
            ),

            "lossless_verified": True,

            "fresh_stage9_decode": direct,

            "evidence_source": result[
                "decode_session_id"
            ],

            "reference_dataset": result["dataset"],

            "reference_method": result["method"],

            "reference_context": result["context"],

            "decoded_sha256": result["decoded_sha256"]
        })

        updated += 1

    assert updated == result[
        "covered_configurations"
    ]

    save_json_stage9(
        AUDIT_JSON9,
        audit_records
    )

    pd.DataFrame(audit_records).to_csv(
        AUDIT_CSV9,
        index=False
    )

    return updated


# ==================== UNIQUE DECODE FUNCTION ====================

def decode_unique_stage9(item):

    dataset_name = item["dataset"]
    method = item["method"]
    context = item["context"]

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    blob_path = Path(item["artifact_path"])
    blob = blob_path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == item["artifact_sha256"]

    assert hashlib.sha256(
        raw
    ).hexdigest() == item["original_sha256"]

    decoded_path = (
        DECODED_DIR9 /
        f"{dataset_name}_{method}_{context}_decoded.txt"
    )

    previous = next(
        (
            r for r in decode_records9
            if r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
            and r["full_decode"] == "PASS"
        ),
        None
    )

    if previous is not None and decoded_path.is_file():

        assert hashlib.sha256(
            decoded_path.read_bytes()
        ).hexdigest() == item["original_sha256"]

        update_lossless_audit9(previous)

        print(
            f"SKIP | {dataset_name} | "
            f"{method} | {context}"
        )

        return previous

    print(
        f"\n=== UNIQUE DECODE: {dataset_name} | "
        f"{method} | Context={context} ===",
        flush=True
    )

    print(
        "Covered configurations:",
        item["covered_configurations"]
    )

    print(
        "Predicted decode:",
        round(item["predicted_decode_s"], 4),
        "s"
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded = fz.decode(
        blob,
        lm
    )

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LOSSLESS VERIFICATION ====================

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, tokens)
    )

    byte_exact = decoded_raw == raw

    decoded_sha = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    sha_exact = (
        decoded_sha == item["original_sha256"]
    )

    passed = (
        token_exact
        and byte_exact
        and sha_exact
    )

    result = {
        **item,

        "compressed_bytes": len(blob),

        "decode_seconds": elapsed,

        "decode_minutes": elapsed / 60,

        "decode_peak_mib": peak_mib,

        "decode_bytes_per_second":
            len(raw) / elapsed,

        "prediction_error_pct": 100 * abs(
            item["predicted_decode_s"] - elapsed
        ) / elapsed,

        "decoded_tokens": len(decoded),

        "decoded_bytes": len(decoded_raw),

        "token_exact": token_exact,

        "byte_exact": byte_exact,

        "sha_exact": sha_exact,

        "decoded_sha256": decoded_sha,

        "decode_session_id": SESSION_ID,

        "decode_gpu_name":
            torch.cuda.get_device_name(0),

        "decode_gpu_id": 0,

        "full_decode": (
            "PASS" if passed else "FAIL"
        ),

        "decoded_path": str(decoded_path)
    }

    # ==================== CHECKPOINT ====================

    decoded_path.write_bytes(decoded_raw)

    decode_records9[:] = [
        r for r in decode_records9
        if not (
            r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
        )
    ]

    decode_records9.append(result)

    save_json_stage9(
        DECODE_JSON9,
        decode_records9
    )

    pd.DataFrame(decode_records9).to_csv(
        DECODE_CSV9,
        index=False
    )

    assert passed, "Lossless verification failed"

    covered = update_lossless_audit9(
        result
    )

    verified_count = sum(
        r["lossless_verified"]
        for r in audit_records
    )

    direct_count = sum(
        r["full_decode"] == "PASS"
        for r in decode_records9
    )

    print("Actual decode:", round(elapsed, 4), "s")
    print("GPU peak:", round(peak_mib, 4), "MiB")
    print("Token exact:", token_exact)
    print("Byte exact:", byte_exact)
    print("SHA-256 exact:", sha_exact)
    print("SHA-256:", decoded_sha)

    print("Newly covered configurations:", covered)

    print(
        f"Unique decode checkpoint: "
        f"{direct_count}/15"
    )

    print(
        f"Lossless verified configurations: "
        f"{verified_count}/60"
    )

    print("STATUS: PASS")

    return result


# ==================== DATASET DECODE FUNCTION ====================

def benchmark_unique_dataset9(dataset_name):

    items = [
        item for item in decode_queue
        if item["dataset"] == dataset_name
    ]

    rows = []

    for item in items:

        rows.append(
            decode_unique_stage9(item)
        )

    df = pd.DataFrame(rows)

    df.to_csv(
        STAGE / "results" /
        f"{dataset_name}_unique_decode.csv",
        index=False
    )

    print("\n=== DATASET UNIQUE DECODE SUMMARY ===")

    if not df.empty:

        display(df[[
            "dataset",
            "method",
            "context",
            "covered_configurations",
            "compressed_bytes",
            "decode_seconds",
            "decode_peak_mib",
            "byte_exact",
            "full_decode"
        ]].round(4))

    print(
        f"DATASET {dataset_name}: "
        f"{len(rows)}/{len(items)} PASS"
    )

    return df


# ==================== DECODE PLAN ====================

print("=== STAGE 9 UNIQUE DECODE PLAN ===")

plan_rows = []

for name in datasets:

    items = [
        item for item in decode_queue
        if item["dataset"] == name
    ]

    plan_rows.append({
        "dataset": name,

        "unique_artifacts": len(items),

        "covered_configurations": sum(
            item["covered_configurations"]
            for item in items
        ),

        "estimated_minutes": sum(
            item["predicted_decode_s"]
            for item in items
        ) / 60
    })

plan_df = pd.DataFrame(plan_rows)

display(plan_df.round(4))

plan_df.to_csv(
    STAGE / "results/unique_decode_plan.csv",
    index=False
)

print("\n=== FINAL STATUS ===")

print("Unique decode function: READY")
print("Audit update function: READY")
print("Unique artifacts:", len(decode_queue))

print(
    "Verified configurations:",
    sum(r["lossless_verified"] for r in audit_records),
    "/ 60"
)

print("CELL 8 DONE")

# ==================== CELL 12 ====================
# Stage 9 — Cell 8: Initialize Unique Full Decode

import gc
import time
import json
import hashlib
import torch
import numpy as np
import pandas as pd

DECODE_JSON9 = STAGE / "results/unique_decode_results.json"
DECODE_CSV9 = STAGE / "results/unique_decode_results.csv"

AUDIT_JSON9 = STAGE / "results/artifact_audit.json"
AUDIT_CSV9 = STAGE / "results/artifact_audit.csv"

decode_queue = json.loads(
    (STAGE / "artifacts/stage9_decode_queue.json").read_text()
)

audit_records = json.loads(
    AUDIT_JSON9.read_text()
)

decode_records9 = (
    json.loads(DECODE_JSON9.read_text())
    if DECODE_JSON9.is_file()
    else []
)

assert len(decode_queue) == 15
assert len(audit_records) == 60

DECODED_DIR9 = STAGE / "artifacts/decoded_unique"

DECODED_DIR9.mkdir(
    parents=True,
    exist_ok=True
)

# ==================== ATOMIC JSON SAVE ====================

def save_json_stage9(path, data):

    temp = path.with_suffix(".tmp")

    temp.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8"
    )

    temp.replace(path)


# ==================== UPDATE AUDIT ====================

def update_lossless_audit9(result):

    assert result["full_decode"] == "PASS"

    key = (
        result["original_sha256"],
        result["artifact_sha256"]
    )

    updated = 0

    for audit in audit_records:

        audit_key = (
            audit["original_sha256"],
            audit["artifact_sha256"]
        )

        if audit_key != key:
            continue

        direct = (
            audit["dataset"] == result["dataset"]
            and audit["method"] == result["method"]
            and audit["context"] == result["context"]
        )

        audit.update({

            "verification_status": (
                "PASS_STAGE9_DIRECT"
                if direct
                else "PASS_STAGE9_IDENTICAL"
            ),

            "lossless_verified": True,

            "fresh_stage9_decode": direct,

            "evidence_source": result[
                "decode_session_id"
            ],

            "reference_dataset": result["dataset"],

            "reference_method": result["method"],

            "reference_context": result["context"],

            "decoded_sha256": result["decoded_sha256"]
        })

        updated += 1

    assert updated == result[
        "covered_configurations"
    ]

    save_json_stage9(
        AUDIT_JSON9,
        audit_records
    )

    pd.DataFrame(audit_records).to_csv(
        AUDIT_CSV9,
        index=False
    )

    return updated


# ==================== UNIQUE DECODE FUNCTION ====================

def decode_unique_stage9(item):

    dataset_name = item["dataset"]
    method = item["method"]
    context = item["context"]

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    blob_path = Path(item["artifact_path"])
    blob = blob_path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == item["artifact_sha256"]

    assert hashlib.sha256(
        raw
    ).hexdigest() == item["original_sha256"]

    decoded_path = (
        DECODED_DIR9 /
        f"{dataset_name}_{method}_{context}_decoded.txt"
    )

    previous = next(
        (
            r for r in decode_records9
            if r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
            and r["full_decode"] == "PASS"
        ),
        None
    )

    if previous is not None and decoded_path.is_file():

        assert hashlib.sha256(
            decoded_path.read_bytes()
        ).hexdigest() == item["original_sha256"]

        update_lossless_audit9(previous)

        print(
            f"SKIP | {dataset_name} | "
            f"{method} | {context}"
        )

        return previous

    print(
        f"\n=== UNIQUE DECODE: {dataset_name} | "
        f"{method} | Context={context} ===",
        flush=True
    )

    print(
        "Covered configurations:",
        item["covered_configurations"]
    )

    print(
        "Predicted decode:",
        round(item["predicted_decode_s"], 4),
        "s"
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded = fz.decode(
        blob,
        lm
    )

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LOSSLESS VERIFICATION ====================

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, tokens)
    )

    byte_exact = decoded_raw == raw

    decoded_sha = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    sha_exact = (
        decoded_sha == item["original_sha256"]
    )

    passed = (
        token_exact
        and byte_exact
        and sha_exact
    )

    result = {
        **item,

        "compressed_bytes": len(blob),

        "decode_seconds": elapsed,

        "decode_minutes": elapsed / 60,

        "decode_peak_mib": peak_mib,

        "decode_bytes_per_second":
            len(raw) / elapsed,

        "prediction_error_pct": 100 * abs(
            item["predicted_decode_s"] - elapsed
        ) / elapsed,

        "decoded_tokens": len(decoded),

        "decoded_bytes": len(decoded_raw),

        "token_exact": token_exact,

        "byte_exact": byte_exact,

        "sha_exact": sha_exact,

        "decoded_sha256": decoded_sha,

        "decode_session_id": SESSION_ID,

        "decode_gpu_name":
            torch.cuda.get_device_name(0),

        "decode_gpu_id": 0,

        "full_decode": (
            "PASS" if passed else "FAIL"
        ),

        "decoded_path": str(decoded_path)
    }

    # ==================== CHECKPOINT ====================

    decoded_path.write_bytes(decoded_raw)

    decode_records9[:] = [
        r for r in decode_records9
        if not (
            r["artifact_sha256"] == item["artifact_sha256"]
            and r["original_sha256"] == item["original_sha256"]
        )
    ]

    decode_records9.append(result)

    save_json_stage9(
        DECODE_JSON9,
        decode_records9
    )

    pd.DataFrame(decode_records9).to_csv(
        DECODE_CSV9,
        index=False
    )

    assert passed, "Lossless verification failed"

    covered = update_lossless_audit9(
        result
    )

    verified_count = sum(
        r["lossless_verified"]
        for r in audit_records
    )

    direct_count = sum(
        r["full_decode"] == "PASS"
        for r in decode_records9
    )

    print("Actual decode:", round(elapsed, 4), "s")
    print("GPU peak:", round(peak_mib, 4), "MiB")
    print("Token exact:", token_exact)
    print("Byte exact:", byte_exact)
    print("SHA-256 exact:", sha_exact)
    print("SHA-256:", decoded_sha)

    print("Newly covered configurations:", covered)

    print(
        f"Unique decode checkpoint: "
        f"{direct_count}/15"
    )

    print(
        f"Lossless verified configurations: "
        f"{verified_count}/60"
    )

    print("STATUS: PASS")

    return result


# ==================== DATASET DECODE FUNCTION ====================

def benchmark_unique_dataset9(dataset_name):

    items = [
        item for item in decode_queue
        if item["dataset"] == dataset_name
    ]

    rows = []

    for item in items:

        rows.append(
            decode_unique_stage9(item)
        )

    df = pd.DataFrame(rows)

    df.to_csv(
        STAGE / "results" /
        f"{dataset_name}_unique_decode.csv",
        index=False
    )

    print("\n=== DATASET UNIQUE DECODE SUMMARY ===")

    if not df.empty:

        display(df[[
            "dataset",
            "method",
            "context",
            "covered_configurations",
            "compressed_bytes",
            "decode_seconds",
            "decode_peak_mib",
            "byte_exact",
            "full_decode"
        ]].round(4))

    print(
        f"DATASET {dataset_name}: "
        f"{len(rows)}/{len(items)} PASS"
    )

    return df


# ==================== DECODE PLAN ====================

print("=== STAGE 9 UNIQUE DECODE PLAN ===")

plan_rows = []

for name in datasets:

    items = [
        item for item in decode_queue
        if item["dataset"] == name
    ]

    plan_rows.append({
        "dataset": name,

        "unique_artifacts": len(items),

        "covered_configurations": sum(
            item["covered_configurations"]
            for item in items
        ),

        "estimated_minutes": sum(
            item["predicted_decode_s"]
            for item in items
        ) / 60
    })

plan_df = pd.DataFrame(plan_rows)

display(plan_df.round(4))

plan_df.to_csv(
    STAGE / "results/unique_decode_plan.csv",
    index=False
)

print("\n=== FINAL STATUS ===")

print("Unique decode function: READY")
print("Audit update function: READY")
print("Unique artifacts:", len(decode_queue))

print(
    "Verified configurations:",
    sum(r["lossless_verified"] for r in audit_records),
    "/ 60"
)

print("CELL 8 DONE")

# ==================== CELL 13 ====================
# Stage 9 — Cell 9: Unique Full Decode Wikipedia

stage9_enwik8 = benchmark_unique_dataset9(
    dataset_name="enwik8_new"
)

print("\nCELL 9 DONE")

# ==================== CELL 14 ====================
# Stage 9 — Cell 10: Unique Full Decode English

stage9_english = benchmark_unique_dataset9(
    dataset_name="english"
)

print("\nCELL 10 DONE")

# ==================== CELL 15 ====================
# Stage 9 — Cell 11: Unique Full Decode Python Code

stage9_python = benchmark_unique_dataset9(
    dataset_name="python_code"
)

print("\nCELL 11 DONE")

# ==================== CELL 16 ====================
# Stage 9 — Cell 12: Unique Full Decode CSV Data

stage9_csv = benchmark_unique_dataset9(
    dataset_name="csv_data"
)

print("\nCELL 12 DONE")

# ==================== CELL 17 ====================
# Stage 9 — Cell 13: Unique Full Decode Vietnamese

stage9_vietnamese = benchmark_unique_dataset9(
    dataset_name="vietnamese"
)

print("\nCELL 13 DONE")

# ==================== CELL 18 ====================
# Stage 9 — Cell 14: Unique Full Decode Mixed Dataset

stage9_mixed = benchmark_unique_dataset9(
    dataset_name="mixed"
)

print("\nCELL 14 DONE")

# ==================== CELL 19 ====================
# Stage 9 — Cell 15: Controlled Decode Benchmark Setup

import gc
import time
import json
import hashlib
import numpy as np
import pandas as pd
import torch

CONTROL_JSON9 = (
    STAGE / "results/controlled_decode.json"
)

CONTROL_CSV9 = (
    STAGE / "results/controlled_decode.csv"
)

CONTROL_DATASETS = [
    "enwik8_new",
    "python_code"
]

CONTROL_METHODS = [
    "Fixed",
    "BC-DP-Full",
    "BC-DP-ReducedLevels",
    "Fast-BC-DP"
]

CONTROL_CONTEXT = 64
CONTROL_REPEATS = 3

# ==================== VERIFY LOSSLESS EVIDENCE ====================

audit_records = json.loads(
    AUDIT_JSON9.read_text()
)

decode_records9 = json.loads(
    DECODE_JSON9.read_text()
)

assert len(audit_records) == 60
assert len(decode_records9) == 15

assert all(
    r["lossless_verified"]
    for r in audit_records
)

assert all(
    r["full_decode"] == "PASS"
    and r["byte_exact"]
    and r["token_exact"]
    and r["sha_exact"]
    for r in decode_records9
)

print("=== FINAL LOSSLESS AUDIT ===")

display(
    pd.DataFrame(audit_records)
    .groupby("verification_status")
    .size()
    .reset_index(name="configurations")
)

print("Lossless verified: 60/60")
print("Unique full decode: 15/15")

# ==================== LOAD CHECKPOINT ====================

control_records9 = (
    json.loads(CONTROL_JSON9.read_text())
    if CONTROL_JSON9.is_file()
    else []
)

control_lookup9 = {
    (
        r["dataset"],
        r["method"],
        r["context"],
        r["repeat"]
    ): r
    for r in control_records9
}

# ==================== CONTROLLED DECODE ====================

def controlled_decode_stage9(
    dataset_name,
    method,
    context=64,
    repeat=1
):

    key = (
        dataset_name,
        method,
        context,
        repeat
    )

    enc = encode_completed9[
        (dataset_name, method, context)
    ]

    path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}_{context}.fzac"
    )

    blob = path.read_bytes()

    assert hashlib.sha256(
        blob
    ).hexdigest() == enc["artifact_sha256"]

    if key in control_lookup9:

        previous = control_lookup9[key]

        assert previous["byte_exact"]
        assert previous["artifact_sha256"] == \
            enc["artifact_sha256"]

        print(f"SKIP | {key}")

        return previous

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]

    print(
        f"\n=== CONTROLLED DECODE: "
        f"{dataset_name} | {method} ===",
        flush=True
    )

    print("Context:", context)
    print("Repeat:", repeat)
    print("Session:", SESSION_ID)

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    t0 = time.perf_counter()

    decoded = fz.decode(
        blob,
        lm
    )

    torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    decoded_raw = tokenizer.decode(
        decoded.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    token_exact = bool(
        np.array_equal(decoded, tokens)
    )

    byte_exact = decoded_raw == raw

    decoded_sha = hashlib.sha256(
        decoded_raw
    ).hexdigest()

    sha_exact = (
        decoded_sha == enc["original_sha256"]
    )

    assert token_exact
    assert byte_exact
    assert sha_exact

    record = {
        "dataset": dataset_name,
        "method": method,
        "context": context,
        "repeat": repeat,

        "compressed_bytes":
            enc["compressed_bytes"],

        "bpb": enc["bpb"],

        "total_encode_seconds":
            enc["total_encode_seconds"],

        "predicted_decode_s":
            enc["predicted_decode_s"],

        "decode_seconds":
            elapsed,

        "decode_peak_mib":
            peak_mib,

        "total_seconds":
            enc["total_encode_seconds"] + elapsed,

        "artifact_sha256":
            enc["artifact_sha256"],

        "layout_sha256":
            enc["layout_sha256"],

        "decoded_sha256":
            decoded_sha,

        "token_exact":
            token_exact,

        "byte_exact":
            byte_exact,

        "sha_exact":
            sha_exact,

        "decode_session_id":
            SESSION_ID,

        "gpu_name":
            torch.cuda.get_device_name(0),

        "full_decode":
            "PASS"
    }

    control_records9.append(record)

    control_lookup9[key] = record

    save_json_stage9(
        CONTROL_JSON9,
        control_records9
    )

    pd.DataFrame(
        control_records9
    ).to_csv(
        CONTROL_CSV9,
        index=False
    )

    print("Decode:", round(elapsed, 4), "s")
    print("GPU peak:", round(peak_mib, 4), "MiB")
    print("Byte-exact:", byte_exact)
    print("STATUS: PASS")

    print(
        f"Controlled checkpoint: "
        f"{len(control_records9)}/24"
    )

    return record


# ==================== DATASET BENCHMARK ====================

def benchmark_controlled_dataset9(dataset_name):

    # Rotate execution order to reduce order bias
    orders = [
        CONTROL_METHODS,
        CONTROL_METHODS[::-1],
        CONTROL_METHODS[2:] + CONTROL_METHODS[:2]
    ]

    for repeat, order in enumerate(
        orders, start=1
    ):

        print(
            f"\n=== REPEAT {repeat}/3 ==="
        )

        for method in order:

            controlled_decode_stage9(
                dataset_name=dataset_name,
                method=method,
                context=CONTROL_CONTEXT,
                repeat=repeat
            )

    df = pd.DataFrame([
        r for r in control_records9
        if r["dataset"] == dataset_name
    ])

    assert len(df) == 12

    summary = (
        df.groupby("method")
        .agg(
            repeats=("decode_seconds", "count"),
            compressed_bytes=("compressed_bytes", "first"),
            mean_decode_s=("decode_seconds", "mean"),
            median_decode_s=("decode_seconds", "median"),
            std_decode_s=("decode_seconds", "std"),
            peak_gpu_mib=("decode_peak_mib", "max"),
            byte_exact=("byte_exact", "all")
        )
        .reset_index()
    )

    summary["cv_pct"] = (
        100 * summary["std_decode_s"]
        / summary["mean_decode_s"]
    )

    summary.to_csv(
        STAGE / "results" /
        f"{dataset_name}_controlled_summary.csv",
        index=False
    )

    print("\n=== CONTROLLED DECODE SUMMARY ===")

    display(summary.round(4))

    return summary


# ==================== ESTIMATED TIME ====================

print("\n=== CONTROLLED BENCHMARK PLAN ===")

control_plan = []

for dataset_name in CONTROL_DATASETS:

    predicted_seconds = sum(
        encode_completed9[
            (
                dataset_name,
                method,
                CONTROL_CONTEXT
            )
        ]["predicted_decode_s"]
        for method in CONTROL_METHODS
    ) * CONTROL_REPEATS

    control_plan.append({
        "dataset": dataset_name,
        "methods": len(CONTROL_METHODS),
        "repeats": CONTROL_REPEATS,
        "measurements": 12,
        "estimated_minutes":
            predicted_seconds / 60
    })

control_plan_df = pd.DataFrame(
    control_plan
)

display(control_plan_df.round(4))

control_plan_df.to_csv(
    STAGE / "results/controlled_decode_plan.csv",
    index=False
)

print("\n=== FINAL STATUS ===")
print("Lossless verification: 60/60 PASS")
print("Controlled decode function: READY")
print("Planned measurements: 24")

print(
    "Estimated total minutes:",
    round(
        control_plan_df[
            "estimated_minutes"
        ].sum(),
        2
    )
)

print("CELL 15 DONE")

# ==================== CELL 20 ====================
# Stage 9 — Cell 16: Controlled Decode Wikipedia

controlled_enwik8 = benchmark_controlled_dataset9(
    dataset_name="enwik8_new"
)

print("\nCELL 16 DONE")

# ==================== CELL 21 ====================
# Stage 9 — Cell 16B: ZIP Part 1 Checkpoint

import json
import hashlib
import zipfile
import shutil

from pathlib import Path
from IPython.display import FileLink, display

WORKING = Path("/kaggle/working")

EVIDENCE_ZIP = WORKING / "stage9_part1_evidence.zip"
ARTIFACTS_ZIP = WORKING / "stage9_part1_artifacts.zip"

# ==================== VERIFY CHECKPOINTS ====================

encode_check = json.loads(
    (STAGE / "results/encode_ablation.json").read_text()
)

audit_check = json.loads(
    (STAGE / "results/artifact_audit.json").read_text()
)

unique_check = json.loads(
    (STAGE / "results/unique_decode_results.json").read_text()
)

control_check = json.loads(
    (STAGE / "results/controlled_decode.json").read_text()
)

analysis_check = json.loads(
    (STAGE / "results/fresh_analysis_benchmark.json").read_text()
)

assert len(encode_check) == 60
assert len(audit_check) == 60
assert len(unique_check) == 15
assert len(control_check) == 12
assert len(analysis_check) == 36

assert all(
    r["lossless_verified"]
    for r in audit_check
)

assert all(
    r["full_decode"] == "PASS"
    and r["byte_exact"]
    and r["token_exact"]
    and r["sha_exact"]
    for r in unique_check + control_check
)

assert all(
    r["dataset"] == "enwik8_new"
    for r in control_check
)

assert len({
    (r["dataset"], r["method"], r["context"], r["repeat"])
    for r in control_check
}) == 12

print("Encode: 60/60 PASS")
print("Fresh analysis: 36/36 PASS")
print("Lossless audit: 60/60 PASS")
print("Unique decode: 15/15 PASS")
print("Controlled decode: 12/24 PASS")

# ==================== VERIFY ENCODE ARTIFACTS ====================

for r in encode_check:

    path = (
        STAGE / "artifacts" /
        f"{r['dataset']}_{r['method']}_{r['context']}.fzac"
    )

    assert path.is_file()

    assert hashlib.sha256(
        path.read_bytes()
    ).hexdigest() == r["artifact_sha256"]

print("Compressed artifact integrity: 60/60 PASS")

# ==================== VERIFY UNIQUE DECODE FILES ====================

for r in unique_check:

    path = Path(r["decoded_path"])

    assert path.is_file()

    assert hashlib.sha256(
        path.read_bytes()
    ).hexdigest() == r["original_sha256"]

print("Unique decoded artifacts: 15/15 PASS")

# ==================== SAVE TOKEN ARRAYS ====================

for name, tokens in dataset_tokens.items():

    np.save(
        STAGE / "artifacts" / f"{name}_tokens.npy",
        tokens
    )

print("Token arrays: 6/6 SAVED")

# ==================== SAVE SESSION CHECKPOINT ====================

session_checkpoint = {

    "stage": "Stage9",
    "part": 1,
    "session_id": SESSION_ID,

    "source_commit":
        "62f09e3105296d62c39e8d95cf8b8775e63f2677",

    "fresh_analysis_completed": 36,
    "cached_ablation_completed": 48,
    "encode_completed": 60,
    "lossless_verified": 60,
    "unique_decode_completed": 15,

    "controlled_decode_completed": 12,
    "controlled_decode_total": 24,

    "completed_datasets": [
        "enwik8_new"
    ],

    "pending_datasets": [
        "python_code"
    ],

    "last_completed_cell": 16,
    "next_cell": 17,

    "resume_session_id": "Stage9-Session02",

    "model_config": model_config,

    "required_previous_inputs": [
        "stage7-final-evidence",
        "stage7-final-artifacts",
        "stage8-final-evidence",
        "stage8-final-artifacts"
    ]
}

(STAGE / "results/session_part1.json").write_text(
    json.dumps(session_checkpoint, indent=2),
    encoding="utf-8"
)

# ==================== SAVE NOTEBOOK HISTORY ====================

CODE_DIR = STAGE / "code"
CODE_DIR.mkdir(parents=True, exist_ok=True)

history = get_ipython().history_manager.input_hist_raw

(CODE_DIR / "stage9_part1_notebook_history.py").write_text(
    "\n\n".join(
        f"# ==================== CELL {i} ====================\n"
        + source
        for i, source in enumerate(history)
        if source.strip()
    ),
    encoding="utf-8"
)

# Save copies only — do not modify original repo
for filename in [
    "adaptive_context_finezip_v3.py",
    "stage5_tools.py"
]:

    shutil.copy2(
        ROOT / "update" / filename,
        CODE_DIR / filename
    )

print("Session checkpoint: SAVED")
print("Notebook history: SAVED")
print("Source snapshots: SAVED")
print("Original source modified: False")

# ==================== ZIP FUNCTION ====================

def checkpoint_zip9(zip_path, folders):

    files = []

    for folder in folders:

        directory = STAGE / folder

        assert directory.is_dir(), directory

        files.extend(
            p for p in directory.rglob("*")
            if p.is_file()
            and "__pycache__" not in p.parts
            and p.suffix != ".pyc"
        )

    files = sorted(set(files))

    assert files

    with zipfile.ZipFile(
        zip_path,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9
    ) as z:

        for path in files:

            arcname = (
                Path("stage9") /
                path.relative_to(STAGE)
            )

            z.write(
                path,
                arcname=str(arcname)
            )

    # Verify ZIP integrity and exact file contents
    with zipfile.ZipFile(zip_path, "r") as z:

        assert z.testzip() is None

        assert len(z.namelist()) == len(files)

        for path in files:

            arcname = str(
                Path("stage9") /
                path.relative_to(STAGE)
            )

            assert hashlib.sha256(
                z.read(arcname)
            ).hexdigest() == hashlib.sha256(
                path.read_bytes()
            ).hexdigest()

    print(f"\nZIP: {zip_path.name}")
    print("Files:", len(files))

    print(
        "Size:",
        round(zip_path.stat().st_size / 1024**2, 3),
        "MB"
    )

    print(
        "SHA-256:",
        hashlib.sha256(
            zip_path.read_bytes()
        ).hexdigest()
    )

    print("Integrity: PASS")

    display(FileLink(zip_path.name))

    return files

# ==================== EVIDENCE ZIP ====================

evidence_files9 = checkpoint_zip9(
    EVIDENCE_ZIP,
    folders=[
        "results",
        "code",
        "plots",
        "reference"
    ]
)

# ==================== ARTIFACT ZIP ====================

artifact_files9 = checkpoint_zip9(
    ARTIFACTS_ZIP,
    folders=[
        "artifacts",
        "datasets"
    ]
)

assert sum(
    p.suffix == ".fzac"
    for p in artifact_files9
) == 60

print("\n=== STAGE 9 PART 1 COMPLETED ===")
print("Encode: 60/60")
print("Lossless: 60/60")
print("Unique full decode: 15/15")
print("Controlled decode: 12/24")
print("ZIP integrity: 2/2 PASS")
print("Next: Cell 17 — Controlled Decode Python")
print("CELL 16B DONE")