# ==================== CELL 1 ====================
# Stage 9 — Part 2 — Cell R1

%cd /kaggle/working

!git clone https://github.com/ThaoTo2806/FineZip28.git

!git -C /kaggle/working/FineZip28 checkout 62f09e3105296d62c39e8d95cf8b8775e63f2677

!pip install -q transformers==5.0.0 accelerate sentencepiece

!nvidia-smi

!git -C /kaggle/working/FineZip28 rev-parse HEAD

from pathlib import Path

ROOT = Path("/kaggle/working/FineZip28")
STAGE = Path("/kaggle/working/stage9")
INPUT = Path("/kaggle/input/datasets/thothanh28")

SESSION_ID = "Stage9-Session02"

E9 = INPUT / "stage9-part1-evidence/stage9"
A9 = INPUT / "stage9-part1-artifacts/stage9"

print("\n=== CHECKPOINT INPUT VERIFICATION ===")

required_files = [
    E9 / "results/session_part1.json",
    E9 / "results/encode_ablation.json",
    E9 / "results/artifact_audit.json",
    E9 / "results/unique_decode_results.json",
    E9 / "results/controlled_decode.json",
    E9 / "results/fresh_analysis_benchmark.json",
    E9 / "code/stage9_part1_notebook_history.py",
    A9 / "artifacts/python_code_tokens.npy",
    A9 / "datasets/python_code.txt",
    A9 / "artifacts/python_code_Fixed_64.fzac",
    A9 / "artifacts/python_code_Fast-BC-DP_64.fzac"
]

for path in required_files:

    assert path.is_file(), f"Missing: {path}"

    print(
        f"PASS | {path.name} | "
        f"{path.stat().st_size:,} B"
    )

print("\n=== PREVIOUS STAGE INPUTS ===")

for name in [
    "stage7-final-evidence",
    "stage7-final-artifacts",
    "stage8-final-evidence",
    "stage8-final-artifacts"
]:

    assert (INPUT / name).is_dir()

    print("PASS |", name)

print("\nSession:", SESSION_ID)
print("Source commit: READY")
print("Checkpoint inputs: PASS")
print("STAGE 9 PART 2 - CELL R1 DONE")

# ==================== CELL 2 ====================
# Stage 9 — Part 2 — Cell R2: Restore Checkpoint

import shutil
import json
import hashlib
import sys
import numpy as np
import pandas as pd
import torch
import transformers

# ==================== RESTORE FILES ====================

print("=== RESTORE CHECKPOINT ===")

STAGE.mkdir(parents=True, exist_ok=True)

for source_root in [E9, A9]:

    for source in sorted(source_root.rglob("*")):

        if not source.is_file():
            continue

        destination = (
            STAGE / source.relative_to(source_root)
        )

        destination.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        shutil.copy2(source, destination)

        assert hashlib.sha256(
            source.read_bytes()
        ).hexdigest() == hashlib.sha256(
            destination.read_bytes()
        ).hexdigest()

print("Checkpoint files restored: PASS")

for folder in [
    "results", "artifacts", "datasets",
    "reference", "code", "plots"
]:

    directory = STAGE / folder
    directory.mkdir(parents=True, exist_ok=True)

    count = sum(
        p.is_file()
        for p in directory.rglob("*")
    )

    print(f"{folder:12s} | {count} files")

# ==================== RESTORE VARIABLES ====================

sys.path.insert(0, str(ROOT / "update"))

import adaptive_context_finezip_v3 as fz
import stage5_tools as s5

E7 = INPUT / "stage7-final-evidence/stage7"
A7 = INPUT / "stage7-final-artifacts/stage7/artifacts"

E8 = INPUT / "stage8-final-evidence/stage8"
A8 = INPUT / "stage8-final-artifacts/stage8/artifacts"

ENCODE_JSON9 = STAGE / "results/encode_ablation.json"
ENCODE_CSV9 = STAGE / "results/encode_ablation.csv"

AUDIT_JSON9 = STAGE / "results/artifact_audit.json"
AUDIT_CSV9 = STAGE / "results/artifact_audit.csv"

DECODE_JSON9 = STAGE / "results/unique_decode_results.json"
DECODE_CSV9 = STAGE / "results/unique_decode_results.csv"

CONTROL_JSON9 = STAGE / "results/controlled_decode.json"
CONTROL_CSV9 = STAGE / "results/controlled_decode.csv"

ANALYSIS_JSON = (
    STAGE / "results/fresh_analysis_benchmark.json"
)

session_part1 = json.loads(
    (STAGE / "results/session_part1.json").read_text()
)

assert session_part1["source_commit"] == (
    "62f09e3105296d62c39e8d95cf8b8775e63f2677"
)

assert session_part1["last_completed_cell"] == 16
assert session_part1["next_cell"] == 17

encode_records9 = json.loads(
    ENCODE_JSON9.read_text()
)

encode_completed9 = {
    (r["dataset"], r["method"], r["context"]): r
    for r in encode_records9
}

audit_records = json.loads(
    AUDIT_JSON9.read_text()
)

decode_records9 = json.loads(
    DECODE_JSON9.read_text()
)

control_records9 = json.loads(
    CONTROL_JSON9.read_text()
)

analysis_benchmark_records = json.loads(
    ANALYSIS_JSON.read_text()
)

assert len(encode_completed9) == 60
assert len(audit_records) == 60
assert len(decode_records9) == 15
assert len(control_records9) == 12
assert len(analysis_benchmark_records) == 36

# ==================== RESTORE CONFIGURATION ====================

config9 = json.loads(
    (STAGE / "results/stage9_configuration.json")
    .read_text()
)

model_config = config9["model"]

ABLATION_CONFIGS = config9["ablation_configs"]

DENSE_LAMBDAS = np.asarray(
    config9["dense_lambdas"]
)

REDUCED_LAMBDAS = np.asarray(
    config9["reduced_lambdas"]
)

TARGETS = config9["target_contexts"]
LEVELS = tuple(fz.CTX_SIZES)

METHODS9 = [
    "Fixed",
    "BC-DP-Full",
    "BC-DP-ReducedSearch",
    "BC-DP-ReducedLevels",
    "Fast-BC-DP"
]

# ==================== RESTORE DATASETS ====================

print("\n=== VERIFY DATASETS ===")

manifest = json.loads(
    (STAGE / "reference/dataset_manifest.json")
    .read_text()
)

datasets = {}
dataset_tokens = {}

for r in manifest:

    name = r["dataset"]

    raw = (
        STAGE / "datasets" / f"{name}.txt"
    ).read_bytes()

    tokens = np.load(
        STAGE / "artifacts" / f"{name}_tokens.npy",
        allow_pickle=False
    )

    assert hashlib.sha256(
        raw
    ).hexdigest() == r["sha256"]

    datasets[name] = raw
    dataset_tokens[name] = tokens

    print(
        f"PASS | {name:15s} | "
        f"{len(raw):,} bytes | "
        f"{len(tokens):,} tokens"
    )

assert len(datasets) == 6

# ==================== VERIFY ENCODE ARTIFACTS ====================

print("\n=== VERIFY 60 COMPRESSED ARTIFACTS ===")

for r in encode_records9:

    path = (
        STAGE / "artifacts" /
        f"{r['dataset']}_{r['method']}_{r['context']}.fzac"
    )

    assert path.is_file()

    blob = path.read_bytes()

    assert len(blob) == r["compressed_bytes"]

    assert hashlib.sha256(
        blob
    ).hexdigest() == r["artifact_sha256"]

    assert hashlib.sha256(
        datasets[r["dataset"]]
    ).hexdigest() == r["original_sha256"]

    assert len(
        dataset_tokens[r["dataset"]]
    ) == r["tokens"]

print("Compressed artifacts: 60/60 PASS")

# ==================== VERIFY LOSSLESS CHECKPOINT ====================

assert all(
    r["lossless_verified"]
    for r in audit_records
)

for r in decode_records9:

    path = (
        STAGE / "artifacts/decoded_unique" /
        f"{r['dataset']}_{r['method']}_{r['context']}_decoded.txt"
    )

    assert path.is_file()

    assert hashlib.sha256(
        path.read_bytes()
    ).hexdigest() == r["original_sha256"]

    assert r["full_decode"] == "PASS"
    assert r["byte_exact"]
    assert r["token_exact"]
    assert r["sha_exact"]

print("Unique decoded artifacts: 15/15 PASS")
print("Lossless audit: 60/60 PASS")

# ==================== VERIFY CONTROLLED DECODE ====================

print("\n=== RESTORED CONTROLLED DECODE ===")

for r in control_records9:

    assert r["dataset"] == "enwik8_new"
    assert r["decode_session_id"] == "Stage9-Session01"

    assert r["full_decode"] == "PASS"
    assert r["byte_exact"]
    assert r["token_exact"]
    assert r["sha_exact"]

    enc = encode_completed9[
        (r["dataset"], r["method"], r["context"])
    ]

    assert r["artifact_sha256"] == enc["artifact_sha256"]
    assert r["decoded_sha256"] == enc["original_sha256"]

control_lookup9 = {
    (
        r["dataset"], r["method"],
        r["context"], r["repeat"]
    ): r
    for r in control_records9
}

assert len(control_lookup9) == 12

control_df9 = pd.DataFrame(control_records9)

display(
    control_df9.groupby("method")
    .agg(
        repeats=("decode_seconds", "count"),
        compressed_bytes=("compressed_bytes", "first"),
        mean_decode_s=("decode_seconds", "mean"),
        std_decode_s=("decode_seconds", "std"),
        lossless=("byte_exact", "all")
    )
    .reset_index()
    .round(4)
)

# ==================== VERIFY SOURCE SNAPSHOTS ====================

print("\n=== VERIFY SOURCE INTEGRITY ===")

for filename in [
    "adaptive_context_finezip_v3.py",
    "stage5_tools.py"
]:

    original = ROOT / "update" / filename
    snapshot = STAGE / "code" / filename

    assert hashlib.sha256(
        original.read_bytes()
    ).hexdigest() == hashlib.sha256(
        snapshot.read_bytes()
    ).hexdigest()

    print(f"PASS | {filename}")

# ==================== ENVIRONMENT ====================

print("\n=== ENVIRONMENT ===")
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("NumPy:", np.__version__)
print("CUDA:", torch.version.cuda)
print("GPU count:", torch.cuda.device_count())

print("\n=== FINAL RESTORE STATUS ===")
print("Previous session: Stage9-Session01")
print("Current session:", SESSION_ID)
print("Datasets: 6/6")
print("Fresh analysis: 36/36")
print("Cached ablation: 48/48")
print("Encode: 60/60")
print("Lossless verification: 60/60")
print("Unique decode: 15/15")
print("Controlled decode: 12/24")
print("Pending: Python Code — 12 measurements")
print("CHECKPOINT RESTORE: PASS")
print("CELL R2 DONE")

# ==================== CELL 3 ====================
# Stage 9 — Part 2 — Cell R3: Restore GPT-2

import gc
import time
import json
import torch
import numpy as np
import hashlib

from transformers import AutoTokenizer

DEVICE = "cuda:0"

torch.cuda.set_device(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.set_float32_matmul_precision("highest")

# ==================== LOAD TOKENIZER ====================

print("=== LOAD TOKENIZER ===")

tokenizer = AutoTokenizer.from_pretrained("gpt2")

for name, tokens in dataset_tokens.items():

    restored = tokenizer.decode(
        tokens.tolist(),
        skip_special_tokens=False,
        clean_up_tokenization_spaces=False
    ).encode("utf-8")

    assert restored == datasets[name]

    print(f"PASS | {name:15s} | Byte-exact")

# ==================== LOAD MODEL ====================

print("\n=== LOAD GPT-2 ===")

gc.collect()
torch.cuda.empty_cache()

t0 = time.perf_counter()

lm = fz.HFLM(
    name="gpt2",
    device=DEVICE,
    max_batch_tokens=1024,
    eps=None
)

torch.cuda.synchronize()

print(
    "Model load time:",
    round(time.perf_counter() - t0, 3),
    "s"
)

current_model_config = {
    "name": "gpt2",
    "dtype": str(next(lm.model.parameters()).dtype),
    "attention": lm.model.config._attn_implementation,
    "vocab_size": lm.V,
    "bos": lm.bos,
    "gpu": torch.cuda.get_device_name(0),
    "torch": torch.__version__,
    "tf32": torch.backends.cuda.matmul.allow_tf32,
    "matmul_precision": torch.get_float32_matmul_precision(),
    "max_batch_tokens": lm.max_batch_tokens,
    "adapter_sha256": None
}

print("\n=== MODEL CONFIGURATION ===")

print(json.dumps(current_model_config, indent=2))

# ==================== COMPARE PREVIOUS SESSION ====================

print("\n=== SESSION COMPATIBILITY ===")

for key, previous_value in model_config.items():

    current_value = current_model_config.get(key)

    assert current_value == previous_value, (
        f"Configuration mismatch: {key} | "
        f"{previous_value} vs {current_value}"
    )

    print(f"PASS | {key}: {current_value}")

assert current_model_config == model_config

# ==================== ARTIFACT QUICK CHECK ====================

print("\n=== PYTHON ARTIFACT COMPATIBILITY ===")

CONTROL_METHODS = [
    "Fixed",
    "BC-DP-Full",
    "BC-DP-ReducedLevels",
    "Fast-BC-DP"
]

for method in CONTROL_METHODS:

    path = (
        STAGE / "artifacts" /
        f"python_code_{method}_64.fzac"
    )

    blob = path.read_bytes()

    enc = encode_completed9[
        ("python_code", method, 64)
    ]

    assert hashlib.sha256(
        blob
    ).hexdigest() == enc["artifact_sha256"]

    fz.quick_check(
        blob,
        lm,
        dataset_tokens["python_code"],
        groups_per_L=1
    )

    print(f"PASS | {method}")

# ==================== SAVE SESSION ENVIRONMENT ====================

session_part2 = {
    "session_id": SESSION_ID,
    "previous_session": "Stage9-Session01",
    "source_commit":
        "62f09e3105296d62c39e8d95cf8b8775e63f2677",
    "model_config": current_model_config,
    "configuration_identical": True,
    "tokenizer_byte_exact": True,
    "restored_controlled_measurements": 12,
    "pending_controlled_measurements": 12,
    "pending_dataset": "python_code"
}

(STAGE / "results/session_part2.json").write_text(
    json.dumps(session_part2, indent=2),
    encoding="utf-8"
)

print("\n=== FINAL STATUS ===")
print("Tokenizer: 6/6 PASS")
print("Model configuration identical: True")
print("Python artifact quick check: 4/4 completed")
print("GPU warm-up: DONE")
print("Session metadata: SAVED")
print("MODEL COMPATIBILITY: PASS")
print("CELL R3 DONE")

# ==================== CELL 4 ====================
# Stage 9 — Part 2 — Cell R4: Restore Benchmark Functions

import ast
import gc
import time
import json
import hashlib
import numpy as np
import pandas as pd
import torch

# ==================== RESTORE ORIGINAL FUNCTIONS ====================

history_path = (
    STAGE / "code/stage9_part1_notebook_history.py"
)

assert history_path.is_file()

history_text = history_path.read_text(
    encoding="utf-8"
)

required_functions = [
    "save_json_stage9",
    "controlled_decode_stage9",
    "benchmark_controlled_dataset9"
]

# Notebook history contains IPython commands.
# Extract only the required Python function definitions.

history_lines = history_text.splitlines()

restored_sources = {}

for name in required_functions:

    start = next(
        i for i, line in enumerate(history_lines)
        if line.startswith(f"def {name}(")
    )

    end = start + 1

    while end < len(history_lines):

        line = history_lines[end]

        if (
            line.strip()
            and not line.startswith((" ", "\t", "#"))
            and not line.startswith(")")
        ):
            break

        end += 1

    source = "\n".join(
        history_lines[start:end]
    )

    parsed = ast.parse(source)

    function_node = next(
        node for node in parsed.body
        if isinstance(node, ast.FunctionDef)
        and node.name == name
    )

    module = ast.Module(
        body=[function_node],
        type_ignores=[]
    )

    exec(
        compile(
            module,
            filename=str(history_path),
            mode="exec"
        ),
        globals()
    )

    restored_sources[name] = ast.unparse(
        function_node
    )

    print(f"PASS | {name}")

# ==================== RESTORE CONFIGURATION ====================

CONTROL_DATASETS = [
    "enwik8_new",
    "python_code"
]

CONTROL_METHODS = [
    "Fixed",
    "BC-DP-Full",
    "BC-DP-ReducedLevels",
    "Fast-BC-DP"
]

CONTROL_CONTEXT = 64
CONTROL_REPEATS = 3

CONTROL_JSON9 = (
    STAGE / "results/controlled_decode.json"
)

CONTROL_CSV9 = (
    STAGE / "results/controlled_decode.csv"
)

control_records9 = json.loads(
    CONTROL_JSON9.read_text()
)

control_lookup9 = {
    (
        r["dataset"],
        r["method"],
        r["context"],
        r["repeat"]
    ): r
    for r in control_records9
}

assert len(control_records9) == 12
assert len(control_lookup9) == 12

assert all(
    r["dataset"] == "enwik8_new"
    and r["byte_exact"]
    and r["full_decode"] == "PASS"
    for r in control_records9
)

assert SESSION_ID == "Stage9-Session02"

# ==================== SAVE RESTORED FUNCTIONS ====================

(
    STAGE / "code/stage9_restored_benchmark.py"
).write_text(
    "\n\n".join(
        restored_sources.values()
    ),
    encoding="utf-8"
)

# ==================== VERIFY PENDING BENCHMARK ====================

print("\n=== PENDING PYTHON BENCHMARK ===")

predicted_total = 0.0

for method in CONTROL_METHODS:

    record = encode_completed9[
        ("python_code", method, 64)
    ]

    predicted = record["predicted_decode_s"]

    predicted_total += (
        predicted * CONTROL_REPEATS
    )

    print(
        f"{method:24s} | "
        f"{predicted:.3f} s/run | "
        f"Repeats: {CONTROL_REPEATS}"
    )

print("\n=== FINAL STATUS ===")

print("Restored functions: 3/3 PASS")
print("Previous measurements: 12/12 PASS")
print("Controlled decode: 12/24")
print("Pending measurements: 12")
print("Current session:", SESSION_ID)

print(
    "Estimated remaining benchmark:",
    round(predicted_total / 60, 2),
    "minutes"
)

print("BENCHMARK RESTORE: PASS")
print("CELL R4 DONE")

# ==================== CELL 5 ====================
# Stage 9 — Cell 17: Controlled Decode Python Code

controlled_python = benchmark_controlled_dataset9(
    dataset_name="python_code"
)

print("\nCELL 17 DONE")

# ==================== CELL 6 ====================
# Stage 9 — Cell 18: Final Summary & Publication Figures

import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pathlib import Path

RESULTS9 = STAGE / "results"
PLOTS9 = STAGE / "plots"

PLOTS9.mkdir(parents=True, exist_ok=True)

# ==================== LOAD ALL RESULTS ====================

enc9 = pd.DataFrame(
    json.loads(ENCODE_JSON9.read_text())
)

audit9 = pd.DataFrame(
    json.loads(AUDIT_JSON9.read_text())
)

unique9 = pd.DataFrame(
    json.loads(DECODE_JSON9.read_text())
)

control9 = pd.DataFrame(
    json.loads(CONTROL_JSON9.read_text())
)

analysis9 = pd.read_csv(
    RESULTS9 / "fresh_analysis_comparison.csv"
)

fresh9 = pd.read_csv(
    RESULTS9 / "fresh_analysis_benchmark.csv"
)

cached9 = pd.read_csv(
    RESULTS9 / "cached_ablation_results.csv"
)

cached_agg9 = pd.read_csv(
    RESULTS9 / "cached_ablation_aggregate.csv"
)

encode_compare9 = pd.read_csv(
    RESULTS9 / "encode_ablation_comparison.csv"
)

encode_agg9 = pd.read_csv(
    RESULTS9 / "encode_ablation_aggregate.csv"
)

bottleneck9 = pd.read_csv(
    RESULTS9 / "stage8_bottleneck_analysis.csv"
)

# ==================== VERIFY ALL EXPERIMENTS ====================

assert len(enc9) == 60
assert len(audit9) == 60
assert len(unique9) == 15
assert len(control9) == 24
assert len(fresh9) == 36
assert len(cached9) == 48

assert audit9["lossless_verified"].all()

for df in [unique9, control9]:

    assert df["byte_exact"].all()
    assert df["token_exact"].all()
    assert df["sha_exact"].all()
    assert (df["full_decode"] == "PASS").all()

assert not control9.duplicated([
    "dataset", "method", "context", "repeat"
]).any()

for _, r in enc9.iterrows():

    path = (
        STAGE / "artifacts" /
        f"{r['dataset']}_{r['method']}_{r['context']}.fzac"
    )

    assert path.is_file()

    assert hashlib.sha256(
        path.read_bytes()
    ).hexdigest() == r["artifact_sha256"]

print("Encode integrity: 60/60 PASS")
print("Lossless audit: 60/60 PASS")
print("Unique decode: 15/15 PASS")
print("Controlled decode: 24/24 PASS")
print("Fresh analysis: 36/36 PASS")

# ==================== FINAL ENCODE TABLE ====================

final_encode9 = enc9.merge(
    audit9[[
        "dataset",
        "method",
        "context",
        "verification_status",
        "lossless_verified",
        "fresh_stage9_decode"
    ]],
    on=["dataset", "method", "context"],
    how="left",
    validate="one_to_one"
)

assert final_encode9["lossless_verified"].all()

final_encode9.to_csv(
    RESULTS9 / "stage9_final_encode_summary.csv",
    index=False
)

final_encode9.to_json(
    RESULTS9 / "stage9_final_encode_summary.json",
    orient="records",
    indent=2
)

# ==================== CONTROLLED DECODE SUMMARY ====================

controlled_summary9 = (
    control9
    .groupby([
        "dataset",
        "method",
        "context",
        "decode_session_id"
    ])
    .agg(
        repeats=("decode_seconds", "count"),

        compressed_bytes=(
            "compressed_bytes", "first"
        ),

        bpb=("bpb", "first"),

        mean_decode_s=(
            "decode_seconds", "mean"
        ),

        median_decode_s=(
            "decode_seconds", "median"
        ),

        std_decode_s=(
            "decode_seconds", "std"
        ),

        min_decode_s=(
            "decode_seconds", "min"
        ),

        max_decode_s=(
            "decode_seconds", "max"
        ),

        decode_peak_mib=(
            "decode_peak_mib", "max"
        ),

        total_encode_s=(
            "total_encode_seconds", "first"
        ),

        artifact_sha256=(
            "artifact_sha256", "first"
        ),

        byte_exact=(
            "byte_exact", "all"
        )
    )
    .reset_index()
)

assert len(controlled_summary9) == 8
assert (controlled_summary9["repeats"] == 3).all()

controlled_summary9["cv_pct"] = (
    100 * controlled_summary9["std_decode_s"]
    / controlled_summary9["mean_decode_s"]
)

controlled_summary9["estimated_total_s"] = (
    controlled_summary9["total_encode_s"]
    + controlled_summary9["mean_decode_s"]
)

controlled_summary9.to_csv(
    RESULTS9 / "stage9_controlled_summary.csv",
    index=False
)

# ==================== PAIRED REPEAT COMPARISON ====================

paired_runs9 = []

for dataset_name in CONTROL_DATASETS:

    subset = control9[
        control9["dataset"] == dataset_name
    ]

    for repeat in range(1, 4):

        run = subset[
            subset["repeat"] == repeat
        ].set_index("method")

        fixed = run.loc["Fixed"]
        full = run.loc["BC-DP-Full"]

        for method in CONTROL_METHODS[1:]:

            current = run.loc[method]

            assert (
                current["decode_session_id"]
                == fixed["decode_session_id"]
                == full["decode_session_id"]
            )

            paired_runs9.append({
                "dataset": dataset_name,
                "method": method,
                "context": 64,
                "repeat": repeat,

                "fixed_decode_s":
                    float(fixed["decode_seconds"]),

                "full_decode_s":
                    float(full["decode_seconds"]),

                "adaptive_decode_s":
                    float(current["decode_seconds"]),

                "decode_saving_vs_fixed_pct":
                    100 * (
                        1 - current["decode_seconds"]
                        / fixed["decode_seconds"]
                    ),

                "decode_saving_vs_full_pct":
                    100 * (
                        1 - current["decode_seconds"]
                        / full["decode_seconds"]
                    ),

                "session_id":
                    current["decode_session_id"]
            })

paired_runs9 = pd.DataFrame(paired_runs9)

assert len(paired_runs9) == 18

paired_runs9.to_csv(
    RESULTS9 / "stage9_controlled_paired_runs.csv",
    index=False
)

# ==================== CONTROLLED PAIRED SUMMARY ====================

control_pairs9 = []

for dataset_name in CONTROL_DATASETS:

    subset = controlled_summary9[
        controlled_summary9["dataset"] == dataset_name
    ].set_index("method")

    fixed = subset.loc["Fixed"]
    full = subset.loc["BC-DP-Full"]

    for method in CONTROL_METHODS[1:]:

        current = subset.loc[method]

        paired = paired_runs9[
            (paired_runs9["dataset"] == dataset_name)
            & (paired_runs9["method"] == method)
        ]

        decode_gain = (
            fixed["mean_decode_s"]
            - current["mean_decode_s"]
        )

        encode_extra = (
            current["total_encode_s"]
            - fixed["total_encode_s"]
        )

        break_even = (
            max(
                1,
                int(np.ceil(
                    encode_extra / decode_gain
                ))
            )
            if decode_gain > 0
            else None
        )

        control_pairs9.append({
            "dataset": dataset_name,
            "method": method,
            "context": 64,

            "repeats": len(paired),

            "fixed_bytes":
                int(fixed["compressed_bytes"]),

            "full_bc_bytes":
                int(full["compressed_bytes"]),

            "adaptive_bytes":
                int(current["compressed_bytes"]),

            "size_saving_vs_fixed_pct":
                100 * (
                    1 - current["compressed_bytes"]
                    / fixed["compressed_bytes"]
                ),

            "size_penalty_vs_full_pct":
                100 * (
                    current["compressed_bytes"]
                    / full["compressed_bytes"] - 1
                ),

            "mean_decode_s":
                float(current["mean_decode_s"]),

            "std_decode_s":
                float(current["std_decode_s"]),

            "cv_pct":
                float(current["cv_pct"]),

            "mean_paired_saving_vs_fixed_pct":
                paired[
                    "decode_saving_vs_fixed_pct"
                ].mean(),

            "mean_paired_saving_vs_full_pct":
                paired[
                    "decode_saving_vs_full_pct"
                ].mean(),

            "positive_repeats_vs_fixed":
                int((
                    paired[
                        "decode_saving_vs_fixed_pct"
                    ] > 0
                ).sum()),

            "positive_repeats_vs_full":
                int((
                    paired[
                        "decode_saving_vs_full_pct"
                    ] > 0
                ).sum()),

            "estimated_total_s":
                float(current["estimated_total_s"]),

            "estimated_total_saving_vs_fixed_pct":
                100 * (
                    1 - current["estimated_total_s"]
                    / fixed["estimated_total_s"]
                ),

            "decode_memory_change_vs_fixed_pct":
                100 * (
                    current["decode_peak_mib"]
                    / fixed["decode_peak_mib"] - 1
                ),

            "break_even_decodes_estimated":
                break_even,

            "artifact_identical_to_full":
                bool(
                    current["artifact_sha256"]
                    == full["artifact_sha256"]
                ),

            "session_id":
                current["decode_session_id"],

            "byte_exact":
                bool(current["byte_exact"])
        })

control_pairs9 = pd.DataFrame(control_pairs9)

assert len(control_pairs9) == 6

control_pairs9.to_csv(
    RESULTS9 / "stage9_controlled_pair_comparison.csv",
    index=False
)

# ==================== INDEPENDENT CORPUS AGGREGATE ====================

scope_records9 = []

for scope, frame in [
    ("All datasets", encode_compare9),

    (
        "Independent corpora",
        encode_compare9[
            encode_compare9["dataset"] != "mixed"
        ]
    )
]:

    for method, sub in frame.groupby("method"):

        scope_records9.append({
            "scope": scope,
            "method": method,
            "configurations": len(sub),

            "mean_size_penalty_pct":
                sub["size_penalty_vs_full_pct"].mean(),

            "max_size_penalty_pct":
                sub["size_penalty_vs_full_pct"].max(),

            "mean_encode_saving_pct":
                sub["encode_saving_vs_full_pct"].mean(),

            "mean_encode_speedup":
                sub["encode_speedup_vs_full"].mean(),

            "mean_encode_slowdown_vs_fixed":
                sub["encode_slowdown_vs_fixed"].mean(),

            "mean_pred_decode_saving_pct":
                sub[
                    "pred_decode_saving_vs_fixed_pct"
                ].mean()
        })

scope_df9 = pd.DataFrame(scope_records9)

scope_df9.to_csv(
    RESULTS9 / "stage9_scope_aggregate.csv",
    index=False
)

# ==================== PLOT SETTINGS ====================

plt.rcParams.update({
    "figure.dpi": 130,
    "savefig.dpi": 300,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42
})

method_labels = {
    "Fixed": "Fixed",
    "BC-DP-Full": "Full",
    "BC-DP-ReducedSearch": "Reduced Search",
    "BC-DP-ReducedLevels": "Reduced Levels",
    "Fast-BC-DP": "Fast"
}

dataset_labels = {
    "enwik8_new": "Wikipedia",
    "english": "English",
    "python_code": "Python",
    "csv_data": "CSV",
    "vietnamese": "Vietnamese",
    "mixed": "Mixed"
}

method_colors = {
    "Fixed": "#64748B",
    "BC-DP-Full": "#2563EB",
    "BC-DP-ReducedSearch": "#9333EA",
    "BC-DP-ReducedLevels": "#16A34A",
    "Fast-BC-DP": "#EA580C"
}

def save_plot9(fig, name):

    fig.tight_layout()

    for ext in ["png", "pdf"]:

        fig.savefig(
            PLOTS9 / f"{name}.{ext}",
            bbox_inches="tight"
        )

    plt.close(fig)


# ==================== FIGURE 1: BOTTLENECK ====================

fig, ax = plt.subplots(figsize=(7, 4))

components = [
    bottleneck9["analysis_pct"].mean(),
    bottleneck9["search_pct"].mean(),
    bottleneck9["codec_pct"].mean()
]

ax.barh(
    ["GPT-2 Analysis", "DP Search", "Codec Encode"],
    components,
    color=["#2563EB", "#9333EA", "#16A34A"]
)

for i, v in enumerate(components):
    ax.text(v + 1, i, f"{v:.2f}%", va="center")

ax.set_xlim(0, 90)
ax.set_xlabel("Share of encoding time (%)")
ax.set_title("Full BC-DP encoding bottleneck")
ax.invert_yaxis()

save_plot9(fig, "01_encoding_bottleneck")


# ==================== FIGURE 2: ANALYSIS TIMES ====================

fig, ax = plt.subplots(figsize=(9, 4.8))

x = np.arange(len(analysis9))
width = 0.36

ax.bar(
    x - width/2,
    analysis9["full_analysis_s"],
    width,
    label="Full levels",
    color="#2563EB"
)

ax.bar(
    x + width/2,
    analysis9["reduced_analysis_s"],
    width,
    label="Reduced levels",
    color="#16A34A"
)

ax.set_xticks(
    x,
    [dataset_labels[d] for d in analysis9["dataset"]]
)

ax.set_ylabel("Median analysis time (s)")
ax.set_title("Fresh GPT-2 inference benchmark")
ax.legend()
ax.grid(axis="y", alpha=0.2)

save_plot9(fig, "02_fresh_analysis_time")


# ==================== FIGURE 3: ANALYSIS SAVINGS ====================

fig, ax = plt.subplots(figsize=(9, 4.5))

ax.bar(
    [dataset_labels[d] for d in analysis9["dataset"]],
    analysis9["analysis_saving_pct"],
    color="#16A34A"
)

ax.axhline(
    analysis9["analysis_saving_pct"].mean(),
    linestyle="--",
    color="black",
    label="Mean"
)

ax.set_ylabel("Analysis time reduction (%)")
ax.set_title("Inference savings by dataset")
ax.legend()
ax.grid(axis="y", alpha=0.2)

save_plot9(fig, "03_analysis_savings")


# ==================== AGGREGATE PLOT HELPER ====================

def aggregate_plot9(
    frame,
    metric,
    ylabel,
    title,
    filename
):

    ordered = frame.set_index("method").loc[
        METHODS9[1:]
    ].reset_index()

    fig, ax = plt.subplots(figsize=(8, 4.6))

    ax.bar(
        [method_labels[m] for m in ordered["method"]],
        ordered[metric],
        color=[
            method_colors[m]
            for m in ordered["method"]
        ]
    )

    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.axhline(0, linewidth=0.8, color="black")
    ax.grid(axis="y", alpha=0.2)

    save_plot9(fig, filename)


# ==================== FIGURE 4: SEARCH SPEEDUP ====================

aggregate_plot9(
    cached_agg9,
    "search_speedup",
    "Search speedup (x)",
    "Cached search ablation",
    "04_search_speedup"
)

# ==================== FIGURE 5: ENCODE SAVINGS ====================

aggregate_plot9(
    encode_agg9,
    "mean_encode_saving_pct",
    "Encoding time reduction (%)",
    "Measured end-to-end encoding ablation",
    "05_encode_savings"
)

# ==================== FIGURE 6: SIZE PENALTY ====================

aggregate_plot9(
    encode_agg9,
    "mean_size_penalty_pct",
    "Compressed size change (%)",
    "Compression penalty relative to Full BC-DP",
    "06_compression_penalty"
)

# ==================== FIGURE 7: ENCODE BREAKDOWN ====================

fig, ax = plt.subplots(figsize=(9, 5))

breakdown = (
    enc9.groupby("method")[[
        "analysis_seconds",
        "search_seconds",
        "codec_seconds"
    ]]
    .mean()
    .loc[METHODS9]
)

bottom = np.zeros(len(breakdown))

for column, label, color in [
    ("analysis_seconds", "Analysis", "#2563EB"),
    ("search_seconds", "Search", "#9333EA"),
    ("codec_seconds", "Codec", "#16A34A")
]:

    values = breakdown[column].to_numpy()

    ax.bar(
        [method_labels[m] for m in breakdown.index],
        values,
        bottom=bottom,
        color=color,
        label=label
    )

    bottom += values

ax.set_ylabel("Mean component time (s)")
ax.set_title("Encoding component costs")
ax.legend()
ax.grid(axis="y", alpha=0.2)

save_plot9(fig, "07_encoding_breakdown")


# ==================== FIGURE 8: SPEED/SIZE TRADE-OFF ====================

fig, ax = plt.subplots(figsize=(8, 6))

for method in METHODS9[1:]:

    sub = encode_compare9[
        encode_compare9["method"] == method
    ]

    ax.scatter(
        sub["size_penalty_vs_full_pct"],
        sub["encode_saving_vs_full_pct"],
        color=method_colors[method],
        label=method_labels[method],
        alpha=0.75,
        s=48
    )

ax.axvline(0, color="gray", linewidth=0.8)
ax.axhline(0, color="gray", linewidth=0.8)

ax.set_xlabel("Compressed size increase vs Full (%)")
ax.set_ylabel("Encoding time reduction vs Full (%)")
ax.set_title("Encoding speed–compression trade-off")
ax.legend()
ax.grid(alpha=0.2)

save_plot9(fig, "08_encode_size_tradeoff")


# ==================== FIGURE 9: CONTROLLED DECODE ====================

fig, axes = plt.subplots(
    1, 2, figsize=(11, 4.8)
)

for ax, dataset_name in zip(
    axes, CONTROL_DATASETS
):

    subset = (
        controlled_summary9[
            controlled_summary9["dataset"] == dataset_name
        ]
        .set_index("method")
        .loc[CONTROL_METHODS]
    )

    ax.bar(
        [method_labels[m] for m in subset.index],
        subset["mean_decode_s"],
        yerr=subset["std_decode_s"],
        capsize=4,
        color=[
            method_colors[m]
            for m in subset.index
        ]
    )

    ax.set_title(dataset_labels[dataset_name])
    ax.set_ylabel("Mean decode time (s)")
    ax.tick_params(axis="x", rotation=20)
    ax.grid(axis="y", alpha=0.2)

save_plot9(fig, "09_controlled_decode_mean_std")


# ==================== FIGURE 10: REPEAT STABILITY ====================

fig, axes = plt.subplots(
    1, 2, figsize=(11, 4.8)
)

for ax, dataset_name in zip(
    axes, CONTROL_DATASETS
):

    for method in CONTROL_METHODS:

        sub = control9[
            (control9["dataset"] == dataset_name)
            & (control9["method"] == method)
        ].sort_values("repeat")

        ax.plot(
            sub["repeat"],
            sub["decode_seconds"],
            marker="o",
            color=method_colors[method],
            label=method_labels[method]
        )

    ax.set_title(dataset_labels[dataset_name])
    ax.set_xticks([1, 2, 3])
    ax.set_xlabel("Repeat")
    ax.set_ylabel("Decode time (s)")
    ax.grid(alpha=0.2)

axes[1].legend()

save_plot9(fig, "10_controlled_repeat_stability")


# ==================== FIGURE 11: DECODE SAVINGS ====================

fig, ax = plt.subplots(figsize=(9, 4.8))

plot_methods = CONTROL_METHODS[1:]
x = np.arange(len(plot_methods))
width = 0.36

for i, dataset_name in enumerate(CONTROL_DATASETS):

    sub = (
        control_pairs9[
            control_pairs9["dataset"] == dataset_name
        ]
        .set_index("method")
        .loc[plot_methods]
    )

    ax.bar(
        x + (i - 0.5) * width,

        sub[
            "mean_paired_saving_vs_fixed_pct"
        ],

        width,
        label=dataset_labels[dataset_name]
    )

ax.set_xticks(
    x,
    [method_labels[m] for m in plot_methods]
)

ax.set_ylabel("Mean paired decode reduction (%)")
ax.set_title("Controlled decoding savings vs Fixed")
ax.axhline(0, color="black", linewidth=0.8)
ax.legend()
ax.grid(axis="y", alpha=0.2)

save_plot9(fig, "11_controlled_decode_savings")


# ==================== FIGURE 12: PREDICTION ACCURACY ====================

fig, ax = plt.subplots(figsize=(6.5, 6))

ax.scatter(
    unique9["predicted_decode_s"],
    unique9["decode_seconds"],
    color="#2563EB",
    label="Unique artifact measurements",
    s=55
)

ax.scatter(
    control9["predicted_decode_s"],
    control9["decode_seconds"],
    color="#EA580C",
    marker="^",
    alpha=0.6,
    label="Controlled measurements"
)

upper = max(
    unique9["predicted_decode_s"].max(),
    unique9["decode_seconds"].max(),
    control9["predicted_decode_s"].max(),
    control9["decode_seconds"].max()
) * 1.05

ax.plot(
    [0, upper],
    [0, upper],
    "--",
    color="gray",
    label="Perfect prediction"
)

ax.set_xlim(0, upper)
ax.set_ylim(0, upper)

ax.set_xlabel("Predicted decode time (s)")
ax.set_ylabel("Measured decode time (s)")
ax.set_title("Latency prediction across sessions")
ax.legend()
ax.grid(alpha=0.2)

save_plot9(fig, "12_latency_prediction")


# ==================== FINAL METADATA ====================

fast_agg = encode_agg9[
    encode_agg9["method"] == "Fast-BC-DP"
].iloc[0]

reduced_agg = encode_agg9[
    encode_agg9["method"] == "BC-DP-ReducedLevels"
].iloc[0]

fast_control = control_pairs9[
    control_pairs9["method"] == "Fast-BC-DP"
]

metadata9 = {
    "stage": "Stage9",
    "experiment": "Fast Adaptive Context Ablation",

    "source_commit":
        "62f09e3105296d62c39e8d95cf8b8775e63f2677",

    "sessions": [
        "Stage9-Session01",
        "Stage9-Session02"
    ],

    "datasets": 6,
    "independent_corpora": 5,
    "target_contexts": [64, 128],

    "cached_ablation_configurations": 48,
    "fresh_analysis_measurements": 36,
    "encode_configurations": 60,
    "lossless_verified_configurations": 60,

    "stage8_identical_verifications": int((
        audit9["verification_status"]
        == "PASS_STAGE8_IDENTICAL"
    ).sum()),

    "stage9_direct_verifications": int((
        audit9["verification_status"]
        == "PASS_STAGE9_DIRECT"
    ).sum()),

    "stage9_identical_verifications": int((
        audit9["verification_status"]
        == "PASS_STAGE9_IDENTICAL"
    ).sum()),

    "unique_full_decode_measurements": 15,
    "controlled_decode_measurements": 24,

    "controlled_datasets": CONTROL_DATASETS,
    "controlled_context": 64,
    "controlled_repeats": 3,

    "mean_analysis_saving_pct":
        float(analysis9["analysis_saving_pct"].mean()),

    "fast_mean_encode_saving_pct":
        float(fast_agg["mean_encode_saving_pct"]),

    "fast_mean_encode_speedup":
        float(fast_agg["mean_encode_speedup"]),

    "fast_mean_size_penalty_pct":
        float(fast_agg["mean_size_penalty_pct"]),

    "fast_max_size_penalty_pct":
        float(fast_agg["max_size_penalty_pct"]),

    "reduced_levels_mean_encode_saving_pct":
        float(
            reduced_agg["mean_encode_saving_pct"]
        ),

    "reduced_levels_mean_size_penalty_pct":
        float(
            reduced_agg["mean_size_penalty_pct"]
        ),

    "fast_mean_controlled_decode_saving_vs_fixed_pct":
        float(
            fast_control[
                "mean_paired_saving_vs_fixed_pct"
            ].mean()
        ),

    "fast_mean_controlled_decode_saving_vs_full_pct":
        float(
            fast_control[
                "mean_paired_saving_vs_full_pct"
            ].mean()
        ),

    "unique_decode_hours":
        float(unique9["decode_seconds"].sum() / 3600),

    "controlled_decode_hours":
        float(control9["decode_seconds"].sum() / 3600),

    "limitations": [
        "Controlled repeated decode covers two datasets at context 64 only",
        "Encoding benchmark uses one end-to-end measurement per configuration",
        "Stage 8 datasets are reused for ablation, not independent confirmation",
        "Mixed dataset is derived from the other corpora",
        "Total-time estimates combine encoding and decoding measurements",
        "Compare decode times within the same dataset and session",
        "Identical layouts and artifacts do not imply identical wall-clock timing"
    ]
}

(RESULTS9 / "stage9_metadata.json").write_text(
    json.dumps(metadata9, indent=2),
    encoding="utf-8"
)

# ==================== FINAL OUTPUT ====================

print("\n=== FINAL ENCODE ABLATION ===")
display(encode_agg9.round(4))

print("\n=== CONTROLLED DECODE SUMMARY ===")
display(controlled_summary9.round(4))

print("\n=== CONTROLLED PAIRED COMPARISON ===")
display(control_pairs9.round(4))

print("\n=== INDEPENDENT CORPORA SUMMARY ===")
display(scope_df9.round(4))

print("\n=== STAGE 9 METADATA ===")
print(json.dumps(metadata9, indent=2))

print("\n=== GENERATED FIGURES ===")

for p in sorted(PLOTS9.iterdir()):

    if p.suffix in [".png", ".pdf"]:
        print(p.name)

assert len(list(PLOTS9.glob("*.png"))) == 12
assert len(list(PLOTS9.glob("*.pdf"))) == 12

print("\n=== FINAL STATUS ===")
print("Encode: 60/60")
print("Lossless verification: 60/60 PASS")
print("Unique full decode: 15/15 PASS")
print("Controlled decode: 24/24 PASS")
print("Figures: 24/24")
print("Final results: SAVED")
print("CELL 18 DONE")

# ==================== CELL 7 ====================
# Stage 9 — Cell 19: ZIP Final Evidence & Artifacts

import json
import hashlib
import zipfile
import shutil

from pathlib import Path
from IPython.display import FileLink, display

WORKING = Path("/kaggle/working")

EVIDENCE_ZIP = WORKING / "stage9_final_evidence.zip"
ARTIFACTS_ZIP = WORKING / "stage9_final_artifacts.zip"

# ==================== VERIFY FINAL RESULTS ====================

enc = json.loads(
    (STAGE / "results/encode_ablation.json").read_text()
)

audit = json.loads(
    (STAGE / "results/artifact_audit.json").read_text()
)

unique = json.loads(
    (STAGE / "results/unique_decode_results.json").read_text()
)

controlled = json.loads(
    (STAGE / "results/controlled_decode.json").read_text()
)

fresh = json.loads(
    (STAGE / "results/fresh_analysis_benchmark.json").read_text()
)

assert len(enc) == 60
assert len(audit) == 60
assert len(unique) == 15
assert len(controlled) == 24
assert len(fresh) == 36

assert all(r["lossless_verified"] for r in audit)

assert all(
    r["full_decode"] == "PASS"
    and r["token_exact"]
    and r["byte_exact"]
    and r["sha_exact"]
    for r in unique + controlled
)

assert len({
    (r["dataset"], r["method"], r["context"], r["repeat"])
    for r in controlled
}) == 24

print("Encode: 60/60 PASS")
print("Lossless audit: 60/60 PASS")
print("Unique full decode: 15/15 PASS")
print("Controlled decode: 24/24 PASS")
print("Fresh analysis: 36/36 PASS")

# ==================== VERIFY ARTIFACTS ====================

for r in enc:

    path = (
        STAGE / "artifacts" /
        f"{r['dataset']}_{r['method']}_{r['context']}.fzac"
    )

    assert path.is_file()

    blob = path.read_bytes()

    assert len(blob) == r["compressed_bytes"]

    assert hashlib.sha256(
        blob
    ).hexdigest() == r["artifact_sha256"]

print("Compressed artifacts: 60/60 PASS")

for r in unique:

    path = (
        STAGE / "artifacts/decoded_unique" /
        f"{r['dataset']}_{r['method']}_{r['context']}_decoded.txt"
    )

    assert path.is_file()

    assert hashlib.sha256(
        path.read_bytes()
    ).hexdigest() == r["original_sha256"]

print("Unique decoded artifacts: 15/15 PASS")

# ==================== VERIFY FIGURES ====================

png_files = sorted(
    (STAGE / "plots").glob("*.png")
)

pdf_files = sorted(
    (STAGE / "plots").glob("*.pdf")
)

assert len(png_files) == 12
assert len(pdf_files) == 12

print("Figures: 24/24 PASS")

# ==================== VERIFY FINAL TABLES ====================

required_results = [
    "stage9_final_encode_summary.csv",
    "stage9_final_encode_summary.json",
    "stage9_controlled_summary.csv",
    "stage9_controlled_paired_runs.csv",
    "stage9_controlled_pair_comparison.csv",
    "stage9_scope_aggregate.csv",
    "stage9_metadata.json",
    "session_part1.json",
    "session_part2.json"
]

for filename in required_results:

    assert (
        STAGE / "results" / filename
    ).is_file(), filename

print("Final result tables: PASS")

# ==================== NOTEBOOK HISTORY ====================

CODE_DIR = STAGE / "code"

CODE_DIR.mkdir(parents=True, exist_ok=True)

# Preserve Part 1 history
part1_history = (
    CODE_DIR / "stage9_part1_notebook_history.py"
)

assert part1_history.is_file()

# Save Part 2 history
history = get_ipython().history_manager.input_hist_raw

part2_history = (
    CODE_DIR / "stage9_part2_notebook_history.py"
)

part2_history.write_text(
    "\n\n".join(
        f"# ==================== CELL {i} ====================\n"
        + source
        for i, source in enumerate(history)
        if source.strip()
    ),
    encoding="utf-8"
)

assert part2_history.is_file()

# Verify source snapshots
for filename in [
    "adaptive_context_finezip_v3.py",
    "stage5_tools.py"
]:

    original = ROOT / "update" / filename

    snapshot = CODE_DIR / filename

    assert snapshot.is_file()

    assert hashlib.sha256(
        original.read_bytes()
    ).hexdigest() == hashlib.sha256(
        snapshot.read_bytes()
    ).hexdigest()

print("Notebook history Part 1: SAVED")
print("Notebook history Part 2: SAVED")
print("Source integrity: PASS")
print("Original source modified: False")

# ==================== ZIP FUNCTION ====================

def create_final_zip9(zip_path, folders):

    files = []

    for folder in folders:

        directory = STAGE / folder

        assert directory.is_dir(), directory

        files.extend(
            p for p in directory.rglob("*")
            if p.is_file()
            and "__pycache__" not in p.parts
            and p.suffix != ".pyc"
        )

    files = sorted(set(files))

    assert files

    with zipfile.ZipFile(
        zip_path,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9
    ) as z:

        for path in files:

            archive_name = (
                Path("stage9") /
                path.relative_to(STAGE)
            )

            z.write(
                path,
                arcname=str(archive_name)
            )

    # Verify ZIP integrity and exact file content
    with zipfile.ZipFile(zip_path, "r") as z:

        assert z.testzip() is None

        names = z.namelist()

        assert len(names) == len(files)

        for path in files:

            archive_name = str(
                Path("stage9") /
                path.relative_to(STAGE)
            )

            assert hashlib.sha256(
                z.read(archive_name)
            ).hexdigest() == hashlib.sha256(
                path.read_bytes()
            ).hexdigest()

    print(f"\nZIP: {zip_path.name}")
    print("Files:", len(files))

    print(
        "Size:",
        round(zip_path.stat().st_size / 1024**2, 3),
        "MB"
    )

    print(
        "SHA-256:",
        hashlib.sha256(
            zip_path.read_bytes()
        ).hexdigest()
    )

    print("Integrity: PASS")

    display(FileLink(zip_path.name))

    return names


# ==================== EVIDENCE ZIP ====================

evidence_names9 = create_final_zip9(
    EVIDENCE_ZIP,
    folders=[
        "results",
        "plots",
        "code",
        "reference"
    ]
)

assert sum(
    name.endswith(".png")
    for name in evidence_names9
) == 12

assert sum(
    name.endswith(".pdf")
    for name in evidence_names9
) == 12

print("PNG included: 12/12")
print("PDF included: 12/12")

print("Both notebook histories included: PASS")

# ==================== ARTIFACTS ZIP ====================

artifact_names9 = create_final_zip9(
    ARTIFACTS_ZIP,
    folders=[
        "artifacts",
        "datasets"
    ]
)

assert sum(
    name.endswith(".fzac")
    for name in artifact_names9
) == 60

assert sum(
    name.endswith("_decoded.txt")
    for name in artifact_names9
) == 15

print("Compressed artifacts included: 60/60")
print("Unique decoded artifacts included: 15/15")

# ==================== FINAL STATUS ====================

print("\n=== STAGE 9 COMPLETED ===")
print("Datasets: 6/6")
print("Cached ablation: 48/48")
print("Fresh analysis: 36/36")
print("Encode: 60/60")
print("Lossless verification: 60/60")
print("Unique full decode: 15/15")
print("Controlled decode: 24/24")
print("Figures: 24/24")
print("ZIP archives: 2/2 PASS")
print("CELL 19 DONE")