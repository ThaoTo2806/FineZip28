def encode_stage9(dataset_name, method, target):

    key = (dataset_name, method, target)

    raw = datasets[dataset_name]
    tokens = dataset_tokens[dataset_name]
    toks_pad = padded_tokens[dataset_name]

    artifact_path = (
        STAGE / "artifacts" /
        f"{dataset_name}_{method}_{target}.fzac"
    )

    if key in encode_completed9:

        previous = encode_completed9[key]

        assert artifact_path.is_file()

        assert hashlib.sha256(
            artifact_path.read_bytes()
        ).hexdigest() == previous["artifact_sha256"]

        print(f"SKIP | {key}")

        return previous

    print(
        f"\n=== ENCODE: {dataset_name} | "
        f"{method} | Target={target} ===",
        flush=True
    )

    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(0)
    torch.cuda.synchronize()

    analysis_seconds = 0.0
    search_seconds = 0.0

    selection = None

    start_total = time.perf_counter()

    # ==================== FIXED POLICY ====================

    if method == "Fixed":

        policy = fz.FixedPolicy(target)

        levels = [target]
        proposals = 0
        unique_layouts = 0

    # ==================== ADAPTIVE POLICY ====================

    else:

        config = ABLATION_CONFIGS[method]

        levels = config["levels"]

        lambda_grid = (
            DENSE_LAMBDAS
            if config["lambda_grid"] == "dense"
            else REDUCED_LAMBDAS
        )

        # Fresh GPU inference
        t0 = time.perf_counter()

        analysis = s5.analyze(
            toks_pad,
            lm,
            batch=8,
            levels=tuple(levels)
        )

        torch.cuda.synchronize()

        analysis_seconds = (
            time.perf_counter() - t0
        )

        # Fresh layout search
        t0 = time.perf_counter()

        fixed_leaves = fz.FixedPolicy(target)(
            toks_pad, lm, 8
        )

        fixed_reference = evaluate_stage9_layout(
            fixed_leaves,
            analysis,
            len(toks_pad)
        )

        search_df, layouts, _ = search_stage9(
            toks_pad,
            analysis,
            lambda_grid
        )

        feasible = search_df[
            search_df["predicted_decode_s"]
            <= fixed_reference["predicted_decode_s"]
        ]

        assert not feasible.empty

        best = feasible.sort_values([
            "variable_bytes",
            "predicted_decode_s"
        ]).iloc[0]

        chosen_leaves = layouts[
            best["layout_sha256"]
        ]

        search_seconds = (
            time.perf_counter() - t0
        )

        proposals = len(search_df)
        unique_layouts = len(layouts)

        # Verify against cached screening
        expected = ablation_layouts[
            dataset_name
        ][method][str(target)]["selection"]

        selection = {
            "objective": str(best["objective"]),
            "time_model": str(best["time_model"]),
            "lambda": float(best["lambda"]),

            "layout_sha256": str(
                best["layout_sha256"]
            ),

            "variable_bytes": int(
                best["variable_bytes"]
            ),

            "predicted_budget_s": float(
                fixed_reference["predicted_decode_s"]
            ),

            "matches_cached_layout": bool(
                best["layout_sha256"]
                == expected["layout_sha256"]
            )
        }

        def policy(
            toks, model, batch,
            leaves=chosen_leaves
        ):
            return leaves

    # ==================== REAL CODEC ENCODE ====================

    torch.cuda.synchronize()

    t0 = time.perf_counter()

    blob, leaves = fz.encode(
        tokens,
        lm,
        policy,
        batch=8
    )

    torch.cuda.synchronize()

    codec_seconds = (
        time.perf_counter() - t0
    )

    total_encode_seconds = (
        time.perf_counter() - start_total
    )

    peak_mib = (
        torch.cuda.max_memory_allocated(0)
        / 1024**2
    )

    # ==================== LAYOUT VERIFICATION ====================

    counts = {
        int(L): int(sum(
            length == L
            for _, length in leaves
        ))
        for L in LEVELS
    }

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    layout_sha256 = hashlib.sha256(
        np.asarray(
            leaves, dtype=np.int64
        ).tobytes()
    ).hexdigest()

    if method != "Fixed":

        assert layout_sha256 == (
            selection["layout_sha256"]
        )

        assert predicted_decode_s <= (
            selection["predicted_budget_s"]
            + 1e-8
        )

        assert all(
            L in levels
            for _, L in leaves
        )

    # ==================== SAVE ARTIFACT ====================

    artifact_path.write_bytes(blob)

    artifact_sha256 = hashlib.sha256(
        blob
    ).hexdigest()

    assert hashlib.sha256(
        artifact_path.read_bytes()
    ).hexdigest() == artifact_sha256

    record = {
        "dataset": dataset_name,
        "method": method,
        "context": int(target),
        "levels": list(levels),
        "search_configurations": proposals,
        "unique_layouts": unique_layouts,

        "original_bytes": len(raw),
        "original_sha256": hashlib.sha256(
            raw
        ).hexdigest(),

        "tokens": len(tokens),
        "padded_tokens": len(toks_pad),

        "compressed_bytes": len(blob),
        "ratio": len(raw) / len(blob),
        "bpb": 8 * len(blob) / len(raw),

        "analysis_seconds": analysis_seconds,
        "search_seconds": search_seconds,
        "codec_seconds": codec_seconds,
        "total_encode_seconds": total_encode_seconds,
        "encode_peak_mib": peak_mib,

        "predicted_decode_s": predicted_decode_s,

        "effective_L": sum(
            int(L)**2 for _, L in leaves
        ) / len(toks_pad),

        "chunk_counts": counts,
        "layout_sha256": layout_sha256,

        "selection": selection,

        "artifact_path": str(artifact_path),
        "artifact_sha256": artifact_sha256,

        "encode_session_id": SESSION_ID,
        "gpu_name": torch.cuda.get_device_name(0),

        "full_decode": "PENDING"
    }

    encode_records9.append(record)
    encode_completed9[key] = record

    # Atomic checkpoint
    temp = ENCODE_JSON9.with_suffix(".tmp")

    temp.write_text(
        json.dumps(encode_records9, indent=2)
    )

    temp.replace(ENCODE_JSON9)

    pd.DataFrame(encode_records9).to_csv(
        ENCODE_CSV9,
        index=False
    )

    print("Compressed:", len(blob), "B")
    print("Analysis:", round(analysis_seconds, 4), "s")
    print("Search:", round(search_seconds, 4), "s")
    print("Codec:", round(codec_seconds, 4), "s")
    print("Total encode:", round(total_encode_seconds, 4), "s")

    print(
        "Peak GPU:",
        round(peak_mib, 2),
        "MiB"
    )

    print(
        f"CHECKPOINT: {len(encode_records9)}/60"
    )

    return record


# ==================== RUN BENCHMARK ====================
