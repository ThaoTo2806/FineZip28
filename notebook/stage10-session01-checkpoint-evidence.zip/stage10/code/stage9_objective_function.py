def build_stage9_objectives(analysis):

    cost_nll = s5.cost_ac(analysis)

    cost_rank = {}

    for L, values in analysis.items():

        ranks = values["ranks"]

        tail = np.where(
            ranks >= RMAX,
            np.log2(np.maximum(ranks, 1)),
            0.0
        )

        cost_rank[L] = (
            rank_table[
                np.minimum(ranks, RMAX)
            ].sum(axis=1)
            + tail.sum(axis=1)
        )

    return {
        "NLL": cost_nll,
        "Rank": cost_rank
    }


# ==================== ABLATION SEARCH ====================
