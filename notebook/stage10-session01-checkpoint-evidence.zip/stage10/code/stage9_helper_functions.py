def evaluate_stage9_layout(leaves, analysis, n_pad):

    cursor = 0
    rank_parts = []

    counts = {
        int(L): 0 for L in LEVELS
    }

    for start, L in leaves:

        assert start == cursor
        assert start + L <= n_pad
        assert L in analysis

        rank_parts.append(
            analysis[L]["ranks"][start // L]
        )

        counts[L] += 1
        cursor += L

    assert cursor == n_pad

    ranks = np.concatenate(
        rank_parts
    ).astype("<u2")

    payload_bytes = len(
        bz2.compress(
            ranks.tobytes(),
            compresslevel=9
        )
    )

    flags = fz.layout_to_flags(
        leaves, n_pad
    )

    layout_bytes = (len(flags) + 7) // 8

    predicted_decode_s = sum(
        counts[L] * measured_cost[L]
        for L in LEVELS
    )

    layout_hash = hashlib.sha256(
        np.asarray(
            leaves,
            dtype=np.int64
        ).tobytes()
    ).hexdigest()

    return {
        "layout_sha256": layout_hash,
        "payload_bytes": payload_bytes,
        "layout_bytes": layout_bytes,
        "variable_bytes":
            payload_bytes + layout_bytes,
        "predicted_decode_s":
            predicted_decode_s,
        "effective_L": sum(
            counts[L] * L**2
            for L in LEVELS
        ) / n_pad,
        "chunk_counts": counts
    }


# ==================== FROZEN OBJECTIVES ====================


def search_stage9(
    toks_pad,
    analysis,
    lambda_grid
):

    t0 = time.perf_counter()

    objectives = build_stage9_objectives(
        analysis
    )

    search_rows = []
    evaluated = {}
    layouts = {}

    for objective_name, cost in objectives.items():

        for time_name, time_fn in time_models.items():

            for lam in lambda_grid:

                policy = s5.TreeDP(
                    cost=cost,
                    lam=float(lam),
                    t_chunk=time_fn
                )

                leaves = policy(toks_pad)

                key = hashlib.sha256(
                    np.asarray(
                        leaves,
                        dtype=np.int64
                    ).tobytes()
                ).hexdigest()

                if key not in evaluated:

                    evaluated[key] = (
                        evaluate_stage9_layout(
                            leaves,
                            analysis,
                            len(toks_pad)
                        )
                    )

                    layouts[key] = leaves

                search_rows.append({
                    "objective": objective_name,
                    "time_model": time_name,
                    "lambda": float(lam),
                    **evaluated[key]
                })

    search_df = pd.DataFrame(search_rows)

    elapsed = time.perf_counter() - t0

    return search_df, layouts, elapsed


# ==================== LOAD STAGE 8 REFERENCE ====================
