# FineZip28 — Experimental Setup Evidence Audit

## Verified research provenance

- Repository: https://github.com/ThaoTo2806/FineZip28.git
- Frozen source commit: `62f09e3105296d62c39e8d95cf8b8775e63f2677`
- Stage 10 FINAL evidence files: 71.
- Stage 10 FINAL artifact files: 38.
- Stage 10 full decode verification: PASS.
- Stage 10 Fast BC-DP compressed size: 273,990 bytes.
- Original GPT-2 tokens: 286,273.
- Padded tokens: 286,304.
- Source/provenance/reference files audited: 14.

## Frozen source and provenance inventory

- `stage10/code/stage9_encode_function.py` (SHA-256: `5aec1222a37434da88da2220faa77202fb23ec5863c09a381decd92af72fd7f0`)
- `stage10/code/stage9_helper_functions.py` (SHA-256: `cd98d03cd53d013dda69af8b9cb7c6fb2e111bcca680e7ae0562a5779eb795b9`)
- `stage10/code/stage9_objective_function.py` (SHA-256: `48ccf8a1d542899810a331216b8b3e4b9f54a93fa1d7b0d75a4b01a62cd39264`)
- `stage10/provenance/adaptive_context_finezip_v3.py` (SHA-256: `2e9ded91038b93dbea4e4f2edf854173037ab895106bde8b73ab342d4f069bde`)
- `stage10/provenance/decode_cost_config.json` (SHA-256: `854f4f299317365251fc964dd295f0d064b145bacbcd599c1db07795aa55d453`)
- `stage10/provenance/frozen_rank_table.npy` (SHA-256: `2e7fca7f4507967c75e1e85c198d3a05bf6f7e3450e06bda762afc867b9e8167`)
- `stage10/provenance/stage5_tools.py` (SHA-256: `0abdd95fe0361b5cf32691494ec42683e6036aecbe3c2b4c592f8bbf365993bd`)
- `stage10/provenance/stage9_configuration.json` (SHA-256: `554bc9fa76526f731d6bbecc0bb5284e58843765e143ed39054d727f4158d9f4`)
- `stage10/reference/enwik8_1mb_padded_tokens.npy` (SHA-256: `cb5febd4afa2590ef5a6ea8cdb0a2a8205e9c12884b4aaa1ab35322fcb51d5d6`)
- `stage10/reference/enwik8_1mb_tokens.npy` (SHA-256: `5e8b7bcbedaaf99c2a86140a583e8a45ee6b380790417b0253e6200ab603da50`)
- `stage10/reference/stage6A_stage6A_final_summary.csv` (SHA-256: `879579f4e9c8a45a19b413985247e88f3afdcf9e1d4bcf3befe1b8c49988c560`)
- `stage10/reference/stage7_stage7_final_summary.csv` (SHA-256: `c32075c6698956191ae84f80360f045628e8a8c2c67f21de9137556ec4565503`)
- `stage10/reference/stage8_stage8_final_summary.csv` (SHA-256: `3322ede95d308568de8f0b9a53a7ee256ffb905b173b9cd8393eada629c65124`)
- `stage10/reference/stage9_stage9_final_encode_summary.csv` (SHA-256: `4bbe6b17d3aa204703605c92edc0f0a7540bab99e0b2ba4680309f09a4ee132a`)

## Historical environment metadata

The companion CSV `stage11_table14_environment_metadata.csv`
lists explicit environment-related JSON fields found
in the frozen evidence.

A field being present does not by itself establish
which experimental run it belongs to. Session-specific
provenance must be checked before using it in the paper.

Current Stage 11 runtime values must not be substituted
for missing Stage 6A, Stage 9, or Stage 10 environment
records.

## Pending manuscript verification

- Confirm historical GPU details per experiment.
- Confirm exact Python, PyTorch, CUDA, and
  Transformers versions when explicitly documented.
- Confirm tokenizer and model configuration against
  frozen code and experiment records.
- Confirm seed and deterministic execution settings
  if available.
- Keep model-based decode predictions distinct
  from observed full-decode timings.

## Reproducibility boundary

This cell verifies archived source and metadata integrity.
It does not reproduce training, compression, or decoding.

Any environment fields not supported by preserved
historical evidence must be reported as unavailable,
rather than inferred from the current Kaggle runtime.
