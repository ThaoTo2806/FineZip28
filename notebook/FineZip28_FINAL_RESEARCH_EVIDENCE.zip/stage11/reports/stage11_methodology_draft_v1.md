# Methodology

*FineZip28 — Stage 11 source-grounded draft v1*

## 1. Overview of the compression workflow

FineZip28 is a GPT-2-based compression workflow
that uses model-derived information to select
variable-length context blocks and to construct
a stored representation of token ranks.

The evaluated implementation combines:

1. GPT-2 analysis of token sequences.
2. A variable-length block-layout search.
3. A layout-selection objective incorporating
   compression-related cost and estimated
   decoding cost.
4. Rank and escape-stream serialization.
5. Lossless reconstruction using the stored
   compressed representation.

The algorithm description below refers to
the frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

It is not an independent reimplementation.

## 2. Language model and token representation

The Stage 9 configuration specifies the
pretrained `gpt2` model with a vocabulary size
of 50,257 and beginning-
of-sequence token ID
50256.

The Stage 9 runtime configuration specifies
FP32 tensors on a Tesla T4 GPU.

The input token sequence is extended to a
multiple of the codec's minimum supported
block length. The `pad_tokens` implementation
fills the additional positions with the model's
BOS token.

The original token count is retained separately
from the padded sequence length so that decoded
padding can be discarded.

The verified 1 MB Stage 10 example contained
286,273 original tokens and
286,304 padded tokens.

## 3. Candidate block layouts

The algorithm represents the token sequence
using a collection of variable-length leaves
or blocks.

The frozen configuration defines the following
candidate context lengths:

- BC-DP-Full: 32, 64, 128, 256 and 512.
- BC-DP-ReducedSearch: the same five lengths.
- BC-DP-ReducedLevels: 32, 64 and 128.
- Fast-BC-DP: 32, 64 and 128.

These candidate block lengths are distinct
from the target-context values of 64 and 128
used in the Stage 9 comparative experiments.

The evaluated layout is serialized into a
flag representation by `layout_to_flags`.
The inverse representation is handled by
`flags_to_layout` during decoding.

## 4. Compression-related objectives

The Stage 9 source constructs two objective
families, named `NLL` and `Rank`.

The NLL-family costs are derived through the
existing `cost_ac` function.

The Rank-family calculation uses a stored
rank-cost table for ranks within its supported
range and a logarithmic tail term for
larger rank values.

The numerical interpretation and complete
mathematical definition of `cost_ac`, the
rank table and the tail threshold must remain
consistent with the frozen source.

This draft does not substitute an assumed
entropy formula for those implementations.

## 5. BC-DP layout search

The Stage 9 search function enumerates
combinations of:

- Compression-related objective family.
- A configured decoding-time cost model.
- A value from the selected lambda grid.

For each combination, the implementation
constructs an `s5.TreeDP` policy with the
corresponding cost, lambda and per-chunk
time function.

The policy proposes a sequence of leaves.
The source hashes the leaf sequence with
SHA-256 and evaluates each previously unseen
layout.

This deduplication step distinguishes the
number of searched configurations from the
number of unique candidate layouts.

The implementation's precise optimization
recurrence should be derived from `TreeDP`
before a mathematical recurrence is added
to the publication.

## 6. Search-space ablations

The full and reduced search configurations
differ along two recorded dimensions.

BC-DP-Full uses five allowed block lengths
and the dense grid of
122 lambda values.

BC-DP-ReducedSearch retains the five block
lengths but uses the reduced grid of
32 lambda values.

BC-DP-ReducedLevels uses three block lengths
and the dense lambda grid.

Fast-BC-DP combines the three-length
configuration and the reduced lambda grid.

The measured Stage 9 comparisons therefore
evaluate changes to the search configuration,
rather than a completely separate neural
language model.

## 7. Decoder-cost modeling

The archived decoder-cost configuration
contains historical measured chunk latencies
at lengths 32, 64, 128, 256 and 512.

The cost calibration is identified as
`Stage7-Session01`.

The record also identifies historical
Stage 6A measurements as validation data
and marks the validation as cross-session.

These cost estimates are used to inform
layout search. A predicted decoding time
must not be presented as a fresh measured
full-decoding time.

## 8. Compressed representation

The frozen `encode` implementation calculates
token ranks for the selected leaves and records
escape positions and associated token IDs.

For escape positions, a placeholder rank is
placed in the rank stream.

The codec then constructs:

- A header containing format and model-related
  metadata, token count and batch plan.
- A packed representation of the block layout.
- A BZip2-compressed rank stream.
- A BZip2-compressed escape stream when
  escape entries are present.

The escape-position sequence is converted
to successive differences before compression.

The stored rank width is selected according
to the language-model vocabulary size.

BZip2 is therefore part of the actual
FineZip28 storage format, not merely an
external compression baseline.

The artifact size includes the container
header and the compressed payloads.

## 9. Reconstruction and lossless verification

The decoder parses the stored header,
reconstructs the block layout and obtains
the batch plan recorded during encoding.

It processes groups of leaves with the
corresponding block length and invokes
`_decode_group` to reconstruct token blocks.

After reconstruction, the decoder returns
only the original number of tokens,
discarding the appended padding.

The Stage 10 experiment independently
verified exact token reconstruction,
exact byte reconstruction and matching
SHA-256 for the 1 MB sample.

This constitutes lossless verification for
the recorded experiment; it does not
establish correctness for arbitrary inputs
without additional testing.

## 10. Implementation and evidence boundaries

The source-derived description is limited
to functionality verified in the frozen
implementation and archived records.

The following details require a final
line-by-line review before journal submission:

- The exact dynamic-programming recurrence
  and boundary constraints within `TreeDP`.
- The formula and units of the NLL and
  rank-related cost functions.
- The exact procedure that maps stored
  ranks and escapes back to original tokens.
- The model-fingerprint validation performed
  while parsing the compressed artifact.
- The complete definition of the historical
  decoding-time cost models.

The current draft does not claim formal
optimality of the layout-selection method,
statistical significance for single-run
timing differences or superiority over
unevaluated neural compression systems.
