# FineZip28 — Manuscript Working Draft v3

**Status:** Research draft; not submission-ready.

**Frozen commit:** `62f09e3105296d62c39e8d95cf8b8775e63f2677`

Section numbers are provisional and will be
normalized during final editorial integration.

---

# 1. Introduction

Lossless text compression aims to represent a
sequence compactly while retaining the ability
to reconstruct its original content exactly.
Traditional compressors and language-model-based
approaches offer different mechanisms for
exploiting regularities in text. For neural
approaches, however, compression performance
must be considered alongside the computational
cost of model evaluation and decoding.

A language model can provide context-dependent
information about a token sequence, but using
that information within a practical lossless
codec introduces several design decisions.
These include how the input is partitioned,
how model-derived information is represented,
how encoding candidates are evaluated, and
how the resulting data can be decoded
reproducibly.

This study investigates these decisions in
FineZip28, a GPT-2-based compression workflow
that uses variable-length context blocks and
rank-based token representation. Its stored
format combines block-layout metadata with
BZip2-compressed rank and escape streams.
The decoder reconstructs tokens
autoregressively, using stored escape tokens
where necessary.

A central focus is the search procedure used
to determine the block layout. FineZip28
uses a binary-tree dynamic-programming
procedure that evaluates block-related costs
together with estimated decoding costs.
The search operates within a configured
set of block lengths, objective functions,
time-cost models, and trade-off parameters.

Because candidate evaluation itself requires
computation, increasing search flexibility
does not necessarily improve the practical
encoding workflow. This motivates the
evaluation of restricted search designs.
In particular, Fast-BC-DP combines a reduced
set of block lengths with a reduced grid of
trade-off parameters. The study compares
this design against a full-search
configuration and two intermediate ablations.

The experiments examine compression size,
encoding time, and available decoding
evidence across multiple text datasets.
Traditional lossless compressors provide
reference baselines. A separate larger-input
experiment examines an operationally
relevant configuration with exact
reconstruction verification.

The contributions of this study are:

1. An implementation-grounded examination of
   context-block layout selection under
   compression-related and estimated
   decoding-cost objectives.

2. A controlled-configuration ablation of
   the search space, separating reduced
   lambda search from reduced block-length
   choices.

3. An empirical analysis of the trade-offs
   between search effort, encoding time,
   and final compressed size on the
   available benchmark datasets.

4. A reproducibility-oriented account of
   the compressed representation, model
   compatibility checks, historical timing
   provenance, and verified reconstruction
   results.

The scope of these contributions is bounded
by the evaluated datasets, implementations,
and archived measurements. The study does
not claim universal compression superiority
or demonstrate a new language-model
architecture.

The remainder of the manuscript presents
related work, the FineZip28 methodology,
the experimental setup, the results and
their limitations, and the conclusions.

**Editorial note:** Insert verified scholarly
citations for background claims after the
Related Work and References audit.

---

# 2. Related Work

**PENDING SOURCE VERIFICATION**

This section has not yet been drafted.
Scholarly citations and bibliographic
metadata must be independently verified.

---

# Methodology

*FineZip28 — Stage 11 source-grounded draft v1*

## 1. Overview of the compression workflow

FineZip28 is a GPT-2-based compression workflow
that uses model-derived information to select
variable-length context blocks and to construct
a stored representation of token ranks.

The evaluated implementation combines:

1. GPT-2 analysis of token sequences.
2. A variable-length block-layout search.
3. A layout-selection objective incorporating
   compression-related cost and estimated
   decoding cost.
4. Rank and escape-stream serialization.
5. Lossless reconstruction using the stored
   compressed representation.

The algorithm description below refers to
the frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

It is not an independent reimplementation.

## 2. Language model and token representation

The Stage 9 configuration specifies the
pretrained `gpt2` model with a vocabulary size
of 50,257 and beginning-
of-sequence token ID
50256.

The Stage 9 runtime configuration specifies
FP32 tensors on a Tesla T4 GPU.

The input token sequence is extended to a
multiple of the codec's minimum supported
block length. The `pad_tokens` implementation
fills the additional positions with the model's
BOS token.

The original token count is retained separately
from the padded sequence length so that decoded
padding can be discarded.

The verified 1 MB Stage 10 example contained
286,273 original tokens and
286,304 padded tokens.

## 3. Candidate block layouts

The algorithm represents the token sequence
using a collection of variable-length leaves
or blocks.

The frozen configuration defines the following
candidate context lengths:

- BC-DP-Full: 32, 64, 128, 256 and 512.
- BC-DP-ReducedSearch: the same five lengths.
- BC-DP-ReducedLevels: 32, 64 and 128.
- Fast-BC-DP: 32, 64 and 128.

These candidate block lengths are distinct
from the target-context values of 64 and 128
used in the Stage 9 comparative experiments.

The evaluated layout is serialized into a
flag representation by `layout_to_flags`.
The inverse representation is handled by
`flags_to_layout` during decoding.

## 4. Compression-related objectives

The Stage 9 source constructs two objective
families, named `NLL` and `Rank`.

The NLL-family costs are derived through the
existing `cost_ac` function.

The Rank-family calculation uses a stored
rank-cost table for ranks within its supported
range and a logarithmic tail term for
larger rank values.

The numerical interpretation and complete
mathematical definition of `cost_ac`, the
rank table and the tail threshold must remain
consistent with the frozen source.

This draft does not substitute an assumed
entropy formula for those implementations.

### Source-grounded objective formulas

The Stage 9 implementation obtains its `NLL`
cost array directly from `analysis[L]["bits"]`
for each available block length \(L\):

\[
C_{\mathrm{NLL},L}[i]
=
\operatorname{analysis}[L]["bits"][i].
\]

This is the source's analysis-cost field.
It must not be equated automatically with the
final stored artifact size, because the actual
file format additionally contains metadata,
layout flags, and BZip2-compressed rank and
escape streams.

The `Rank` objective is computed using a frozen
rank-cost lookup table. For the ranks belonging
to a candidate block, the implementation sums
the table costs for ranks clipped at the
configured threshold `RMAX`, then adds
\(\log_2(\max(r,1))\) for each rank at or above
that threshold.

This is an estimated rank-related cost,
not a directly measured BZip2 output length.

A separate historical helper, `cost_rank_proxy`,
constructs a smoothed rank-frequency table
using a reference context, histogram counts,
and parameter `alpha`. That helper must not
be confused with the frozen rank table used
by the Stage 9 `Rank` objective.

The helper `cost_calibrated` multiplies the
analysis bits by a length-specific coefficient
\(\kappa_L\). Its presence in the source does
not establish that it was selected for every
Stage 9 search.

**Sources:** `stage5_tools.py`, lines 36–59;
`stage9_objective_function.py`, lines 1–27.

## 5. BC-DP layout search

The Stage 9 search function enumerates
combinations of:

- Compression-related objective family.
- A configured decoding-time cost model.
- A value from the selected lambda grid.

For each combination, the implementation
constructs an `s5.TreeDP` policy with the
corresponding cost, lambda and per-chunk
time function.

The policy proposes a sequence of leaves.
The source hashes the leaf sequence with
SHA-256 and evaluates each previously unseen
layout.

This deduplication step distinguishes the
number of searched configurations from the
number of unique candidate layouts.

The implementation's precise optimization
recurrence should be derived from `TreeDP`
before a mathematical recurrence is added
to the publication.

### Binary-tree layout recurrence

The frozen `TreeDP` implementation operates on
binary subdivisions of a configured root block
length, denoted by `BLOCK`.

For a candidate block beginning at position \(s\)
with length \(L\), the implementation defines
the leaf cost as

\[
J_{\mathrm{leaf}}(s,L)
=
C_L[s/L] + \lambda\,t(L),
\]

where \(C_L\) is the precomputed cost array for
block length \(L\), \(\lambda\) is the selected
search parameter, and \(t(L)\) is the configured
estimated time cost of a block of length \(L\).

Array indexing uses the integer position \(s/L\)
for aligned candidate blocks.

When \(L\) is greater than the minimum supported
block length, the alternative split cost is

\[
J_{\mathrm{split}}(s,L)
=
J(s,L/2)+J(s+L/2,L/2).
\]

The implementation chooses the lower-cost
available alternative. When the leaf and split
costs are equal, the leaf is preferred.

A leaf is considered only when its length and
index are valid in the precomputed cost array.
When a leaf cannot be used, the implementation
falls back to the split alternative.

For positions at or beyond the padded sequence
length, the recursive solver returns zero cost
and an empty leaf list.

The source invokes the solver independently
at root offsets separated by `BLOCK`.

Accordingly, the search selects a minimum-cost
layout within this implementation's configured
binary subdivision tree and supplied cost model.
This is not a claim of global optimality across
arbitrary segmentations or arbitrary cost models.

**Source:** `stage5_tools.py`, lines 67–92.

## 6. Search-space ablations

The full and reduced search configurations
differ along two recorded dimensions.

BC-DP-Full uses five allowed block lengths
and the dense grid of
122 lambda values.

BC-DP-ReducedSearch retains the five block
lengths but uses the reduced grid of
32 lambda values.

BC-DP-ReducedLevels uses three block lengths
and the dense lambda grid.

Fast-BC-DP combines the three-length
configuration and the reduced lambda grid.

The measured Stage 9 comparisons therefore
evaluate changes to the search configuration,
rather than a completely separate neural
language model.

## 7. Decoder-cost modeling

The archived decoder-cost configuration
contains historical measured chunk latencies
at lengths 32, 64, 128, 256 and 512.

The cost calibration is identified as
`Stage7-Session01`.

The record also identifies historical
Stage 6A measurements as validation data
and marks the validation as cross-session.

These cost estimates are used to inform
layout search. A predicted decoding time
must not be presented as a fresh measured
full-decoding time.

### Historical decode-cost calibration

The source defines a quadratic chunk-time
model of the form

\[
t_{\mathrm{quad}}(L)=cL^2,
\]

where the helper documents its output in
seconds per chunk.

The archived Stage 7 calibration records an
older coefficient of `0.000102` and a
fitted coefficient of `9.25933640728e-05`.

The calibration additionally stores measured
chunk latencies for lengths 32, 64, 128,
256 and 512, with an associated batch plan.

Historical cross-session validation used
Stage 6A measurements and reported these
mean absolute percentage errors:

- Old quadratic: 16.6348%.
- Fitted quadratic:
  5.8785%.
- Measured-latency:
  6.8977%.

The fitted quadratic had the lowest MAPE
among those three historical alternatives.

These values belong to `Stage7-Session01`.
They are not new Stage 11 measurements or
a guarantee of accuracy on untested data.

The source-level function defining a
quadratic model and the archived fitted
coefficient are separate pieces of evidence;
the coefficient alone does not establish
per-run selection. Stage 9 run metadata,
audited separately, identifies the selected
time-model label for each BC-DP result.

**Sources:** `stage5_tools.py`, lines 63–64;
`decode_cost_config.json`.

### Selected time-model and objective provenance

The Stage 9 search enumerated candidate layouts
using compression objectives, decode-cost models,
and lambda values. Each selected BC-DP result
retained its objective and time-model labels
in the serialized run metadata.

All 48 non-Fixed BC-DP configurations contained
parseable selected-candidate metadata. The
recorded selected layout SHA-256 agreed with the
final recorded artifact layout SHA-256 in every
case.

Across these 48 configurations, 24 selected
the `Fitted` decode-cost model and 24 selected
the `Measured` decode-cost model.

Similarly, the selected compression objective
was `NLL` in 24 configurations and `Rank`
in 24 configurations.

The two decode-cost labels refer to the
cost model associated with selection of a
candidate block layout. They do not indicate
different token-reconstruction algorithms
being executed by the decoder.

The observed distribution is descriptive
and should not be interpreted as evidence
that the two models have equal performance
or equal probability of selection on
unseen datasets.

The Fixed configurations do not have
BC-DP search-selection metadata and are
excluded from these 48 selections.

**Evidence:** Frozen Stage 9 results,
`selection` metadata and layout SHA-256;
`search_stage9` and `encode_stage9` source.

## 8. Compressed representation

The frozen `encode` implementation calculates
token ranks for the selected leaves and records
escape positions and associated token IDs.

For escape positions, a placeholder rank is
placed in the rank stream.

The codec then constructs:

- A header containing format and model-related
  metadata, token count and batch plan.
- A packed representation of the block layout.
- A BZip2-compressed rank stream.
- A BZip2-compressed escape stream when
  escape entries are present.

The escape-position sequence is converted
to successive differences before compression.

The stored rank width is selected according
to the language-model vocabulary size.

BZip2 is therefore part of the actual
FineZip28 storage format, not merely an
external compression baseline.

The artifact size includes the container
header and the compressed payloads.

## 9. Reconstruction and lossless verification

The decoder parses the stored header,
reconstructs the block layout and obtains
the batch plan recorded during encoding.

It processes groups of leaves with the
corresponding block length and invokes
`_decode_group` to reconstruct token blocks.

After reconstruction, the decoder returns
only the original number of tokens,
discarding the appended padding.

The Stage 10 experiment independently
verified exact token reconstruction,
exact byte reconstruction and matching
SHA-256 for the 1 MB sample.

This constitutes lossless verification for
the recorded experiment; it does not
establish correctness for arbitrary inputs
without additional testing.

### Detailed rank and escape reconstruction

During decoding, `_parse` reads the stored
header, reconstructs the block layout,
decompresses the BZip2 rank payload, and
decompresses the escape payload when present.

The escape payload stores delta-coded positions
and token identifiers. The parser reconstructs
the absolute positions by cumulative summation.

For blocks of the same length, `_decode_group`
forms a batch and initializes the model input
with beginning-of-sequence tokens.

At each position within a block, `lm.pick`
uses the stored rank and current model context
to select a token.

If the current absolute position is present
in the escape dictionary, its explicitly
stored token replaces the rank-selected token.

The reconstructed token is then supplied as
input for the following position in the block.
Thus, reconstruction proceeds autoregressively
within each block.

The public `decode` function combines these
reconstructed blocks and truncates the output
to the original token count stored in the file.

This description follows the implementation.
It does not independently prove that every
possible encoded input is recoverable.

**Source:** `adaptive_context_finezip_v3.py`,
lines 475–548.

### Model and environment compatibility checks

The encoder stores a model fingerprint formed
from the first eight bytes of a SHA-256 digest
of the serialized model configuration.

The decoder recomputes this fingerprint.
A mismatch raises `ValueError`, preventing
decoding with that mismatched model configuration.

A mismatch in stored rank width also raises
`ValueError`.

The serialized runtime environment is checked
separately. If the current environment differs
from the recorded environment, `_parse` issues
a `RuntimeWarning` describing the discrepancy.

An environment mismatch is therefore a
warning condition rather than an unconditional
rejection condition in this implementation.

The source warns that exact reconstruction
may not be guaranteed under some environment
differences, particularly when no escape
entries are present.

The archived Stage 10 byte-level verification
provides direct evidence of lossless recovery
for its tested artifact; fingerprint validation
alone is not a general proof of losslessness.

**Source:** `adaptive_context_finezip_v3.py`,
lines 415–418 and 475–514.

## 10. Implementation and evidence boundaries

The source-derived description is limited
to functionality verified in the frozen
implementation and archived records.

The binary-tree recurrence, rank/escape
reconstruction flow, and fingerprint checks
have now been examined against the frozen
implementation.

The following details still require additional
verification before journal submission:

- The complete mathematical interpretation
  and units of the NLL and rank-related
  cost functions.
- The complete definitions and applicability
  of the historical decoding-time cost models.
- General correctness across input distributions
  beyond the archived verification cases.
- Any formal optimality claim beyond the
  configured binary search tree.

The current draft does not claim formal
optimality of the layout-selection method,
statistical significance for single-run
timing differences or superiority over
unevaluated neural compression systems.

---

# Experimental Setup and Reproducibility

*FineZip28 — Stage 11 evidence-grounded draft*

## 1. Source implementation

The experiments use the FineZip28 implementation
associated with repository:

https://github.com/ThaoTo2806/FineZip28.git

Frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

The archived Stage 10 FINAL evidence contains
the source files, compression configuration,
historical summaries, and reproducibility records
used by the analysis.

## 2. Neural compression model

The tested neural compression workflow uses GPT-2
with a frozen context-adaptive FineZip implementation.

For the historical Stage 9 ablation measurements,
the recorded execution configuration specifies:

- GPU: Tesla T4
- PyTorch: 2.10.0+cu128
- Model tensor dtype: torch.float32
- Matrix multiplication precision:
  highest
- Maximum model batch tokens:
  1024

These values are explicitly associated with
Stage9-Session01. They are not assumed to be
identical across all historical sessions.

## 3. Traditional compression baselines

The traditional baselines are gzip, BZip2, XZ,
and Zstandard.

The archived Stage 10 benchmark records specify:

- Python: 3.12.13
- zlib: 1.2.11
- zstandard: 0.25.0
- Session: Stage10-Session01

Traditional baseline encode/decode times were
measured in three repetitions per configuration
and summarized using median elapsed times.

## 4. Dataset configuration

The evaluation includes six 100 KB datasets:

- enwik8_new
- english
- python_code
- csv_data
- vietnamese
- mixed

The 1 MB experiment uses a separate enwik8 sample.

The two enwik8-related samples are not
prefix-identical. Scaling observations therefore
reflect both input-size and sample differences.

## 5. Stage 10 neural compression verification

The Stage 10 Fast-BC-DP-64 experiment produced
a 273,990-byte
compressed artifact.

The original sequence contained
286,273 GPT-2 tokens,
and the padded coding sequence contained
286,304 tokens.

Measured end-to-end encoding time:
117.3890 seconds.

Measured full decoding time:
1386.1740 seconds.

The decoder reconstructed the original
1,000,000-byte input exactly, with a matching
SHA-256 hash.

## 6. Timing provenance and comparability

Stage 9 FineZip measurements and Stage 6A FineZip
measurements were preserved from historical runs.

Stage 10 traditional baseline measurements
and the fresh Stage 10 Fast-BC-DP experiment
belong to Stage10-Session01.

Cross-session timing differences are descriptive,
not controlled speedup evidence.

Moreover, the neural compressor and traditional
codecs have distinct computational workloads.
Compression-size comparisons alone do not
establish superior end-to-end performance.

## 7. Reproducibility limitations

The frozen source revision, compressed artifacts,
input samples, verification results, and
SHA-256 manifests are retained.

Historical software versions must be reported
only when supported by session-specific evidence.
Unrecorded versions are not inferred from
the current notebook.

The evaluated FineZip configurations generally
have only one timing observation per configuration.
No formal variance estimate or statistical
significance is claimed for those timings.

Independent external LLM compressor baselines
have not been executed.

The archived records establish verification
of the stated experimental outputs; they do not
establish that all experiments have been freshly
rerun in Stage 11.

---

# Results and Discussion

*FineZip28 — Stage 11 evidence-grounded draft*

## 1. Experimental Coverage

The evaluation combines previously verified FineZip
experiments with traditional compression baselines.
Six 100 KB datasets were evaluated using 84 compression
configurations, and a 1 MB enwik8 sample was evaluated
using 14 configurations.

The traditional baselines comprise gzip, BZip2, XZ,
and Zstandard. Traditional-codec timings in Stage 10
were recorded over three repetitions per configuration,
whereas most FineZip timings represent single-run
historical observations.

All compressed-size comparisons use complete artifact
sizes, including the relevant file-format overhead.

The timing provenance differs across some experiments.
Consequently, cross-session timing differences are
reported descriptively rather than interpreted as
controlled speedup measurements.

### Experimental provenance and timing comparability

The 100 KB FineZip results were obtained from frozen
Stage 9 experiments. The nine historical 1 MB FineZip
configurations originate from Stage 6A. Traditional
codec measurements and the fresh 1 MB Fast-BC-DP
experiment originate from Stage 10.

The traditional baseline timing summaries use the
median of three repetitions per configuration.
Most historical FineZip configurations, as well as
the fresh Fast-BC-DP experiment, have only one
recorded timing observation per configuration.

Compression sizes can be compared directly for the
same input bytes because they describe complete
stored artifacts. In contrast, timing comparisons
across sessions are descriptive, and the different
computational requirements of neural and traditional
compression must be considered.

The frozen FineZip source commit is
`62f09e3105296d62c39e8d95cf8b8775e63f2677`.
The neural compressor uses the frozen GPT-2-based
coding implementation, with its Stage 9 model
and context-selection configuration. The specific
runtime setup and calibration records are preserved
in the experimental evidence rather than inferred
from compression ratios.

## 2. Compression Performance on 100 KB Datasets

BZip2 produced the smallest compressed file on
5 of the six evaluated 100 KB datasets.

The exception was the enwik8_new sample, where
BC-DP-Full at target context
128
produced a compressed artifact of
27,608 bytes.

This represented a
11.8040% compressed-size reduction
relative to BZip2 on that sample.

FineZip did not outperform BZip2 in compressed size
on the other five datasets.

These results suggest that the relative performance
of the tested FineZip configurations is dependent
on the input data distribution. The current evaluation
does not establish compression superiority across
all text or structured-data categories.

**Evidence:** Table 1 (100 KB compression comparison), derived from the verified 84-configuration Stage 10 table.

## 3. Compression Performance on the 1 MB Sample

On the 1 MB enwik8 sample, the smallest compressed
artifact was generated by Fixed-512:
213,691 bytes.

This was
24.0407% smaller than the
281,323-byte BZip2 artifact.

Fast-BC-DP-64 generated an artifact of
273,990 bytes,
corresponding to a
2.6066% reduction relative to BZip2.

Compared with Fixed-64, Fast-BC-DP-64 generated
a 0.8414% larger artifact.

The newly measured Stage 10 Fast-BC-DP-64
end-to-end encoding time was
117.3890 seconds,
and its measured full decoding time was
1386.1740 seconds.

The decoder reconstructed all
286,273 original tokens and all
1,000,000 original bytes exactly.
SHA-256 verification confirmed lossless reconstruction.

The observed decode time of Fast-BC-DP-64 was
16.6318% lower than the
historically recorded Fixed-64 decode time.
However, those timings originated from different
experimental sessions, so this difference must
not be interpreted as a controlled speedup.

**Evidence:** Table 2 (1 MB compression and timing) and Stage 10 fresh encode/decode verification records.

### Token padding and decoding provenance

The 1 MB input produced
286,273 original GPT-2 tokens.
The coding input contained
286,304 tokens after padding.
Consequently, the two token counts describe
different stages of the coding pipeline.

The Stage 10 full decoding experiment verified
reconstruction of the original token sequence and
the original 1,000,000 input bytes. The original
and decoded byte sequences had matching SHA-256.

The Fast-BC-DP decoding time of
1386.1740 seconds is a
fresh, measured full-decoding observation.
The Stage 7 cost model also supplied a predicted
decoding duration of
1530.3757 seconds.
The prediction is not substituted for the measured
duration.

Other prediction-only decoding fields in the
historical optimization records must not be
interpreted as fresh measured decoding times.

## 4. Ablation of Search and Context Selection

A matched ablation analysis was performed on the
60 Stage 9 configurations, comprising five FineZip
methods evaluated over six datasets and two target
contexts (64 and 128).

The methods were Fixed, BC-DP-Full,
BC-DP-ReducedSearch, BC-DP-ReducedLevels,
and Fast-BC-DP.

Relative to BC-DP-Full, Fast-BC-DP had a median
observed encode-time reduction of
36.4528% across the 12 matched
dataset-context cases.

Fast-BC-DP exhibited a lower recorded encode
time in all 12 cases, with reductions ranging from
35.6272% to
38.8589%.

However, its compression-size advantage was mixed:
three cases produced smaller artifacts, one case
produced an equal-sized artifact, and eight cases
produced larger artifacts.

The median compressed-size saving relative to
BC-DP-Full was -0.1921%, indicating
a slight median size penalty.

Fast-BC-DP used 128 candidate proposals compared
with 488 for BC-DP-Full in the tested configurations.
This represents a reduction in the proposal count,
not an equivalent reduction in GPU runtime.

Although Fast-BC-DP was consistently faster than
BC-DP-Full in these observations, Fixed had the
lowest recorded encoding time in all 12 matched
cases. Fast-BC-DP should therefore not be described
as the fastest FineZip method overall.

**Evidence:** Table 3 (paired ablation), Table 4 (method summary), and Figures 5–7 (ablation).

## 5. Robustness Across Datasets and Contexts

At both target contexts, Fast-BC-DP had a lower
recorded encode time than BC-DP-Full for every
evaluated dataset.

The encode-time advantage was retained across all
six leave-one-dataset-out sensitivity analyses.

The size effects differed by target context.
At context 64, Fast-BC-DP did not produce a
smaller artifact in any of the six datasets.
At context 128, it produced smaller artifacts
in three of the six datasets.

These observations indicate that the measured
encoding advantage was consistent across the
tested data and context conditions, while the
compression-size effect varied.

The two context results from the same dataset
should not be treated as independent dataset
replicates. Furthermore, the measurements were
not repeated sufficiently to support formal
statistical significance claims.

The leave-one-dataset-out results are therefore
interpreted as descriptive sensitivity checks,
not hypothesis tests.

**Evidence:** Tables 7–9 (dataset-level, leave-one-dataset-out, and context-specific robustness).

### Interpretation of paired ablation observations

The twelve ablation cases correspond to six datasets
evaluated at two target contexts. They are matched
algorithm comparisons, not twelve independent
dataset replicates.

The reported median is a descriptive summary over
these twelve cases. Differences in these historical
single-run measurements are not confidence intervals,
and their signs alone do not establish statistical
significance.

In particular, Fast-BC-DP exhibits a consistent
observed encode-time advantage over BC-DP-Full,
but its compressed-size advantage is not consistent.
The method is not the globally fastest FineZip
configuration in the evaluated ablation set.

## 6. Descriptive Input-Size Scaling

Fast-BC-DP encoding was also observed on
100 KB and 1 MB enwik8-related samples.

The input size increased by a factor of ten.
The observed end-to-end encoding times were
11.9332
and
117.3890
seconds, respectively.

These two samples were not prefix-identical and
contained different token distributions.
The measurements comprise only one fresh
encoding run per sample size.

Accordingly, the resulting scaling factors
are descriptive and cannot establish
asymptotic time complexity.

**Evidence:** Stage 10 Figure 4 and its verified input-size scaling CSV.

## 7. Practical Trade-offs

The experiments reveal a fundamental trade-off
between compressed size and computational cost.

On the tested enwik8 samples, selected FineZip
configurations generated smaller artifacts than
BZip2. However, decoding the 1 MB Fast-BC-DP
artifact required approximately
1386.17 seconds,
while the traditional codecs decoded the same
sample on a substantially shorter time scale.

Thus, the observed compressed-size improvements
do not imply better end-to-end efficiency.

The practical suitability of GPT-2-based
compression depends on the relative importance
of storage efficiency, encoding cost, decoding
latency, model availability, and hardware resources.

## 8. Limitations

Several limitations constrain the conclusions.

First, most FineZip encoding and decoding timings
are single-run observations. The traditional
baselines provide repeated timings, but these
do not eliminate differences in computational
workflows.

Second, some comparisons combine historical
Stage 6A or Stage 9 results with measurements
from Stage 10. Cross-session timing comparisons
are descriptive only.

Third, the evaluation covers six 100 KB datasets
and one 1 MB sample. The reported effects cannot
be generalized to untested distributions.

Fourth, the two input sizes used for the scaling
analysis correspond to different samples.
Consequently, no asymptotic complexity claim
is supported.

Fifth, independent external LLM-based compressor
baselines were not executed in this experiment.
The results should not be interpreted as
superiority over other LLM compression systems.

Finally, the substantial decoding cost of the
tested GPT-2-based configuration remains a major
practical limitation.

### Reproducibility and outstanding reference review

The source-code revision, result tables, compressed
artifacts, byte-exact decoding records, and integrity
manifests are retained in the Stage 10 FINAL evidence
and artifact datasets.

The Stage 9 historical experiments and the Stage 10
fresh experiments must retain their separate timing
provenance. No unmeasured performance values are
introduced into this manuscript.

External literature citations, a comparison with
independently evaluated neural compression methods,
and journal-specific formatting remain outstanding.
These activities are necessary before the manuscript
can be regarded as submission-ready.

## 9. Discussion Summary

The results demonstrate that the evaluated
FineZip configurations can improve compressed
size on selected enwik8 samples, but they do
not consistently outperform traditional
compressors across the tested datasets.

The ablation experiments show that restricting
the BC-DP search process can improve observed
encoding efficiency while introducing a small
median compression-size penalty.

Together, these findings support a qualified
compression-versus-computation trade-off,
rather than a universal compression-performance
advantage.

This text is a draft derived from existing
experimental evidence and requires further
editorial and reference verification before
journal submission.

---

# 6. Conclusion

This study examined FineZip28 as a
GPT-2-based lossless text compression
workflow, focusing on how the configuration
of a binary-tree block-layout search affects
the practical balance between encoding
effort and compressed size.

The implementation audit established that
the evaluated search explores multiple
compression-related objectives and
estimated decoding-cost models. Layout
candidates are evaluated within a
restricted binary partition structure,
and repeated layouts are identified by
their hashes. The compressed representation
stores layout metadata alongside
BZip2-compressed rank and escape streams.

The ablation experiments provide evidence
that reducing the search space can decrease
encoding time for the evaluated
configurations. These reductions must be
interpreted together with the observed
size trade-offs rather than treated as
unconditional compression improvements.

The run-level provenance audit further
confirmed the selected objective and
decode-cost model labels for all 48
non-Fixed BC-DP configurations. Both the
Fitted and Measured time-cost models were
represented among the selected layouts.
These labels describe layout-search
decisions, not alternative decoding
algorithms.

The available larger-input experiment
also provides direct evidence of exact
reconstruction for the tested compressed
artifact. This result supports the
lossless behavior of that recorded run,
without constituting a formal correctness
proof for arbitrary input sequences or
runtime environments.

Several limitations remain. The principal
ablation measurements are historical
single-run observations, and cross-session
timing comparisons cannot establish a
controlled same-session speedup. The
tested methods do not include an
independently reproduced set of external
neural compression systems. Decoder-cost
predictions must also remain distinct
from measured full-decoding times.

Future work should examine repeated
same-session timing measurements,
additional datasets and input lengths,
broader neural baselines, and stronger
checks of cross-environment decoding
reproducibility. Further optimization
of candidate evaluation may also help
clarify the practical value of more
flexible block-layout searches.

Overall, the evidence supports
search-space reduction as a useful
engineering direction for the evaluated
FineZip28 implementation. Its benefits
should be reported as configuration-
specific trade-offs, not generalized
claims of optimality or universal
compression superiority.
