# Stage 11 — Ablation Robustness

## Source

Frozen Stage 9 evidence, analyzed in Stage 11.

Six datasets, two target contexts per dataset,
12 paired Fast-BC-DP versus BC-DP-Full observations.

## Encode-time results

- Fast-BC-DP had lower observed encode time
  in 12/12 paired cases.
- Median encode-time reduction:
  36.4528%.
- Range of observed encode-time reductions:
  35.6272% to
  38.8589%.
- All six datasets showed an encode-time reduction
  at both tested target contexts.
- All six leave-one-dataset-out subsets retained
  positive encode-time reductions in every case.

## Compression-size results

- Smaller artifacts: 3/12 cases.
- Equal-size artifacts: 1/12 cases.
- Larger artifacts: 8/12 cases.
- Median compressed-size saving relative to Full:
  -0.1921%.
- Observed range of compressed-size savings:
  -1.6729% to
  0.4097%.

A negative size-saving percentage indicates
that Fast-BC-DP produced a larger compressed file.

## Interpretation

The reduction in observed encode time is consistent
across the six tested datasets and two contexts.
However, the compression-size effect is mixed.

This supports a descriptive encode-efficiency
trade-off within the tested Stage 9 configurations.
It does not imply Fast-BC-DP is the fastest
FineZip variant overall: Fixed had the lowest
encode time in all 12 Stage 9 paired cases.

## Limitations

- Stage 9 timings are historical single-run observations.
- The two context results from the same dataset
  are not independent dataset replicates.
- Leave-one-dataset-out is a sensitivity analysis,
  not a statistical significance test.
- No confidence interval or p-value is inferred
  from the six datasets.
- No fresh encode or decode was run in Stage 11.
- These observations are limited to the tested
  data and frozen implementation.

## Source commit

62f09e3105296d62c39e8d95cf8b8775e63f2677
