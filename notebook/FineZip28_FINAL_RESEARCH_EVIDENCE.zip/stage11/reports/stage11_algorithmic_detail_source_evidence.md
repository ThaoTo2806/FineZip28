# FineZip28 — Algorithmic Detail Source Evidence

Frozen source inspection for Stage 11 Cell 16.

This report preserves relevant implementation
bodies with source-line numbering.

Static source inspection is not a correctness proof.

## TREE_DP

### TreeDP

Source: `provenance/stage5_tools.py`

Lines 67–92

```python
0067 | class TreeDP:
0068 |     """J(chunk) = cost[L][idx] + lam * t_chunk(L). Giao diện policy(toks, lm, batch) như fz.DPPolicy."""
0069 | 
0070 |     def __init__(self, cost, lam=0.0, t_chunk=None):
0071 |         self.cost, self.lam, self.t_chunk = cost, float(lam), t_chunk or t_dec_quadratic()
0072 | 
0073 |     def __call__(self, toks, lm=None, batch=None):
0074 |         n_pad, cost, lam, t = len(toks), self.cost, self.lam, self.t_chunk
0075 | 
0076 |         def solve(s, L):
0077 |             if s >= n_pad:
0078 |                 return 0.0, []
0079 |             split = None
0080 |             if L > fz.MIN_L:
0081 |                 (j1, l1), (j2, l2) = solve(s, L // 2), solve(s + L // 2, L // 2)
0082 |                 split = (j1 + j2, l1 + l2)
0083 |             if s + L <= n_pad and L in cost and s // L < len(cost[L]):
0084 |                 leaf = (cost[L][s // L] + lam * t(L), [(s, L)])
0085 |                 if split is None or leaf[0] <= split[0]:
0086 |                     return leaf
0087 |             return split
0088 | 
0089 |         leaves = []
0090 |         for s in range(0, n_pad, BLOCK):
0091 |             leaves += solve(s, BLOCK)[1]
0092 |         return leaves
```

### TreeDP.__init__

Source: `provenance/stage5_tools.py`

Lines 70–71

```python
0070 |     def __init__(self, cost, lam=0.0, t_chunk=None):
0071 |         self.cost, self.lam, self.t_chunk = cost, float(lam), t_chunk or t_dec_quadratic()
```

### TreeDP.__call__

Source: `provenance/stage5_tools.py`

Lines 73–92

```python
0073 |     def __call__(self, toks, lm=None, batch=None):
0074 |         n_pad, cost, lam, t = len(toks), self.cost, self.lam, self.t_chunk
0075 | 
0076 |         def solve(s, L):
0077 |             if s >= n_pad:
0078 |                 return 0.0, []
0079 |             split = None
0080 |             if L > fz.MIN_L:
0081 |                 (j1, l1), (j2, l2) = solve(s, L // 2), solve(s + L // 2, L // 2)
0082 |                 split = (j1 + j2, l1 + l2)
0083 |             if s + L <= n_pad and L in cost and s // L < len(cost[L]):
0084 |                 leaf = (cost[L][s // L] + lam * t(L), [(s, L)])
0085 |                 if split is None or leaf[0] <= split[0]:
0086 |                     return leaf
0087 |             return split
0088 | 
0089 |         leaves = []
0090 |         for s in range(0, n_pad, BLOCK):
0091 |             leaves += solve(s, BLOCK)[1]
0092 |         return leaves
```

### block_cost_matrix

Source: `provenance/stage5_tools.py`

Lines 123–131

```python
0123 | def block_cost_matrix(cost, lam, t_chunk=None, levels=LEVELS):
0124 |     """C[b, j] = J nếu cả khối 512 thứ b dùng chunk dài levels[j] (chỉ các khối đủ 512)."""
0125 |     t = t_chunk or t_dec_quadratic()
0126 |     nb = len(cost[BLOCK])
0127 |     C = np.zeros((nb, len(levels)))
0128 |     for j, L in enumerate(levels):
0129 |         k = BLOCK // L
0130 |         C[:, j] = cost[L][:nb * k].reshape(nb, k).sum(1) + lam * t(L) * k
0131 |     return C
```

## RANK_TOKEN_RECOVERY

### _parse

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 475–514

```python
0475 | def _parse(blob, lm):
0476 |     h = _read_header(blob)
0477 |     fp, cfg, env_now = _fingerprint(lm)
0478 |     if fp != h["fp"]:
0479 |         raise ValueError("mô hình khác lúc nén (tên/vocab/bos/dtype/attention). Cấu hình hiện tại: %s" % json.dumps(cfg))
0480 |     if h["rank_width"] != (2 if lm.V <= np.iinfo(np.uint16).max + 1 else 4):
0481 |         raise ValueError("rank width does not match the decoder vocabulary")
0482 |     if env_now != h["env"]:
0483 |         try:
0484 |             a, b = json.loads(h["env"]), json.loads(env_now)
0485 |             diff = {k: (a.get(k), b.get(k)) for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)}
0486 |         except ValueError:
0487 |             diff = {"env": (h["env"], env_now)}
0488 |         guard = "file có escape (eps=%.3g) nên có thể vẫn đúng" % h["eps"] if h["n_esc"] else \
0489 |                 "file KHÔNG có escape nên lossless không được đảm bảo"
0490 |         warnings.warn("môi trường giải nén khác lúc nén %s: %s" % (diff, guard), RuntimeWarning, stacklevel=3)
0491 |     n, nf, n_esc = h["n"], h["nf"], h["n_esc"]
0492 |     nb = (nf + 7) // 8
0493 |     flags = np.unpackbits(np.frombuffer(blob, np.uint8, nb, h["off"]))[:nf]
0494 |     n_pad = -(-n // MIN_L) * MIN_L
0495 |     try:
0496 |         leaves = flags_to_layout(flags.tolist(), n_pad)
0497 |     except (StopIteration, ValueError) as exc:
0498 |         raise ValueError("invalid FineZip layout") from exc
0499 |     off = h["off"] + nb
0500 |     (len_rk,) = struct.unpack_from("<I", blob, off); off += 4
0501 |     dt = np.dtype("<u2" if h["rank_width"] == 2 else "<u4")
0502 |     ranks = np.frombuffer(bz2.decompress(blob[off:off + len_rk]), dtype=dt).astype(np.int64)
0503 |     if len(ranks) != sum(L for _, L in leaves):
0504 |         raise ValueError("rank count does not match layout")
0505 |     esc = {}
0506 |     if n_esc:
0507 |         raw = bz2.decompress(blob[off + len_rk:])
0508 |         pos = np.cumsum(np.frombuffer(raw[:4 * n_esc], "<u4").astype(np.int64))
0509 |         tok = np.frombuffer(raw[4 * n_esc:], dtype=dt).astype(np.int64)
0510 |         esc = dict(zip(pos.tolist(), tok.tolist()))
0511 |     rk, o = {}, 0
0512 |     for s, L in leaves:
0513 |         rk[s] = ranks[o:o + L]; o += L
0514 |     return n, n_pad, leaves, rk, esc, h["plan"]
```

### _groups

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 517–522

```python
0517 | def _groups(leaves, plan):
0518 |     """Các nhóm batch theo đúng kế hoạch trong file: (L, [start,...])."""
0519 |     for L in sorted({l for _, l in leaves}):
0520 |         starts = [s for s, l in leaves if l == L]
0521 |         for i in range(0, len(starts), plan[L]):
0522 |             yield L, starts[i:i + plan[L]]
```

### _decode_group

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 525–537

```python
0525 | def _decode_group(ss, L, rk, esc, lm):
0526 |     R = np.stack([rk[s] for s in ss])
0527 |     inp = np.full((len(ss), L), lm.bos, np.int64)           # cùng shape [B,L] như encode
0528 |     dec = np.zeros((len(ss), L), np.int64)
0529 |     for p in range(L):                                        # tự hồi quy trong chunk, batch qua chunk
0530 |         dec[:, p] = lm.pick(inp, p, R[:, p])
0531 |         for j, s in enumerate(ss):                            # vị trí escape: dùng token đã lưu
0532 |             g = s + p
0533 |             if g in esc:
0534 |                 dec[j, p] = esc[g]
0535 |         if p + 1 < L:
0536 |             inp[:, p + 1] = dec[:, p]
0537 |     return dec
```

### decode

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 540–548

```python
0540 | def decode(blob, lm, batch=None):
0541 |     """Giải nén. `batch` được GIỮ để tương thích nhưng BỊ BỎ QUA: kế hoạch batch lấy từ header."""
0542 |     n, n_pad, leaves, rk, esc, plan = _parse(blob, lm)
0543 |     out = np.zeros(n_pad, np.int64)
0544 |     for L, ss in _groups(leaves, plan):
0545 |         dec = _decode_group(ss, L, rk, esc, lm)
0546 |         for j, s in enumerate(ss):
0547 |             out[s:s + L] = dec[j]
0548 |     return out[:n]
```

## MODEL_FINGERPRINT

### HFLM.adapter_fingerprint

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 93–104

```python
0093 |     def adapter_fingerprint(self):
0094 |         if self.adapter_path is None:
0095 |             return None
0096 |         digest = hashlib.sha256()
0097 |         for root, _, names in os.walk(self.adapter_path):
0098 |             for name in sorted(names):
0099 |                 path = os.path.join(root, name)
0100 |                 digest.update(os.path.relpath(path, self.adapter_path).encode())
0101 |                 with open(path, "rb") as stream:
0102 |                     for block in iter(lambda: stream.read(1024 * 1024), b""):
0103 |                         digest.update(block)
0104 |         return digest.hexdigest()
```

### _fingerprint

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 415–418

```python
0415 | def _fingerprint(lm):
0416 |     cfg, env = lm.describe()
0417 |     fp = hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).digest()[:8]
0418 |     return fp, cfg, json.dumps(env, sort_keys=True, separators=(",", ":"))
```

### _parse

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 475–514

```python
0475 | def _parse(blob, lm):
0476 |     h = _read_header(blob)
0477 |     fp, cfg, env_now = _fingerprint(lm)
0478 |     if fp != h["fp"]:
0479 |         raise ValueError("mô hình khác lúc nén (tên/vocab/bos/dtype/attention). Cấu hình hiện tại: %s" % json.dumps(cfg))
0480 |     if h["rank_width"] != (2 if lm.V <= np.iinfo(np.uint16).max + 1 else 4):
0481 |         raise ValueError("rank width does not match the decoder vocabulary")
0482 |     if env_now != h["env"]:
0483 |         try:
0484 |             a, b = json.loads(h["env"]), json.loads(env_now)
0485 |             diff = {k: (a.get(k), b.get(k)) for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)}
0486 |         except ValueError:
0487 |             diff = {"env": (h["env"], env_now)}
0488 |         guard = "file có escape (eps=%.3g) nên có thể vẫn đúng" % h["eps"] if h["n_esc"] else \
0489 |                 "file KHÔNG có escape nên lossless không được đảm bảo"
0490 |         warnings.warn("môi trường giải nén khác lúc nén %s: %s" % (diff, guard), RuntimeWarning, stacklevel=3)
0491 |     n, nf, n_esc = h["n"], h["nf"], h["n_esc"]
0492 |     nb = (nf + 7) // 8
0493 |     flags = np.unpackbits(np.frombuffer(blob, np.uint8, nb, h["off"]))[:nf]
0494 |     n_pad = -(-n // MIN_L) * MIN_L
0495 |     try:
0496 |         leaves = flags_to_layout(flags.tolist(), n_pad)
0497 |     except (StopIteration, ValueError) as exc:
0498 |         raise ValueError("invalid FineZip layout") from exc
0499 |     off = h["off"] + nb
0500 |     (len_rk,) = struct.unpack_from("<I", blob, off); off += 4
0501 |     dt = np.dtype("<u2" if h["rank_width"] == 2 else "<u4")
0502 |     ranks = np.frombuffer(bz2.decompress(blob[off:off + len_rk]), dtype=dt).astype(np.int64)
0503 |     if len(ranks) != sum(L for _, L in leaves):
0504 |         raise ValueError("rank count does not match layout")
0505 |     esc = {}
0506 |     if n_esc:
0507 |         raw = bz2.decompress(blob[off + len_rk:])
0508 |         pos = np.cumsum(np.frombuffer(raw[:4 * n_esc], "<u4").astype(np.int64))
0509 |         tok = np.frombuffer(raw[4 * n_esc:], dtype=dt).astype(np.int64)
0510 |         esc = dict(zip(pos.tolist(), tok.tolist()))
0511 |     rk, o = {}, 0
0512 |     for s, L in leaves:
0513 |         rk[s] = ranks[o:o + L]; o += L
0514 |     return n, n_pad, leaves, rk, esc, h["plan"]
```

### quick_check

Source: `provenance/adaptive_context_finezip_v3.py`

Lines 551–567

```python
0551 | def quick_check(blob, lm, tokens, batch=None, groups_per_L=1):
0552 |     """Giải nén THỬ vài nhóm batch đầu của mỗi mức L và so với token gốc (dùng đúng kế hoạch batch trong file).
0553 |     Chạy TRƯỚC decode đầy đủ (hàng giờ). `batch` bị bỏ qua như ở decode()."""
0554 |     tokens = np.asarray(tokens)
0555 |     n, n_pad, leaves, rk, esc, plan = _parse(blob, lm)
0556 |     seen, bad = {}, []
0557 |     for L, ss in _groups(leaves, plan):
0558 |         if seen.get(L, 0) >= groups_per_L:
0559 |             continue
0560 |         seen[L] = seen.get(L, 0) + 1
0561 |         dec = _decode_group(ss, L, rk, esc, lm)
0562 |         for j, s in enumerate(ss):
0563 |             e = min(s + L, n)
0564 |             if e > s and not np.array_equal(dec[j][:e - s], tokens[s:e]):
0565 |                 bad.append((s, L))
0566 |     print("quick_check:", "OK" if not bad else f"LỆCH ở {bad}")
0567 |     return not bad
```
