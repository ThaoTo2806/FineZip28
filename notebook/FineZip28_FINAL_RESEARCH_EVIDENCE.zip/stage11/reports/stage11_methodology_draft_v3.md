# Methodology

*FineZip28 — Stage 11 source-grounded draft v1*

## 1. Overview of the compression workflow

FineZip28 is a GPT-2-based compression workflow
that uses model-derived information to select
variable-length context blocks and to construct
a stored representation of token ranks.

The evaluated implementation combines:

1. GPT-2 analysis of token sequences.
2. A variable-length block-layout search.
3. A layout-selection objective incorporating
   compression-related cost and estimated
   decoding cost.
4. Rank and escape-stream serialization.
5. Lossless reconstruction using the stored
   compressed representation.

The algorithm description below refers to
the frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

It is not an independent reimplementation.

## 2. Language model and token representation

The Stage 9 configuration specifies the
pretrained `gpt2` model with a vocabulary size
of 50,257 and beginning-
of-sequence token ID
50256.

The Stage 9 runtime configuration specifies
FP32 tensors on a Tesla T4 GPU.

The input token sequence is extended to a
multiple of the codec's minimum supported
block length. The `pad_tokens` implementation
fills the additional positions with the model's
BOS token.

The original token count is retained separately
from the padded sequence length so that decoded
padding can be discarded.

The verified 1 MB Stage 10 example contained
286,273 original tokens and
286,304 padded tokens.

## 3. Candidate block layouts

The algorithm represents the token sequence
using a collection of variable-length leaves
or blocks.

The frozen configuration defines the following
candidate context lengths:

- BC-DP-Full: 32, 64, 128, 256 and 512.
- BC-DP-ReducedSearch: the same five lengths.
- BC-DP-ReducedLevels: 32, 64 and 128.
- Fast-BC-DP: 32, 64 and 128.

These candidate block lengths are distinct
from the target-context values of 64 and 128
used in the Stage 9 comparative experiments.

The evaluated layout is serialized into a
flag representation by `layout_to_flags`.
The inverse representation is handled by
`flags_to_layout` during decoding.

## 4. Compression-related objectives

The Stage 9 source constructs two objective
families, named `NLL` and `Rank`.

The NLL-family costs are derived through the
existing `cost_ac` function.

The Rank-family calculation uses a stored
rank-cost table for ranks within its supported
range and a logarithmic tail term for
larger rank values.

The numerical interpretation and complete
mathematical definition of `cost_ac`, the
rank table and the tail threshold must remain
consistent with the frozen source.

This draft does not substitute an assumed
entropy formula for those implementations.

### Source-grounded objective formulas

The Stage 9 implementation obtains its `NLL`
cost array directly from `analysis[L]["bits"]`
for each available block length \(L\):

\[
C_{\mathrm{NLL},L}[i]
=
\operatorname{analysis}[L]["bits"][i].
\]

This is the source's analysis-cost field.
It must not be equated automatically with the
final stored artifact size, because the actual
file format additionally contains metadata,
layout flags, and BZip2-compressed rank and
escape streams.

The `Rank` objective is computed using a frozen
rank-cost lookup table. For the ranks belonging
to a candidate block, the implementation sums
the table costs for ranks clipped at the
configured threshold `RMAX`, then adds
\(\log_2(\max(r,1))\) for each rank at or above
that threshold.

This is an estimated rank-related cost,
not a directly measured BZip2 output length.

A separate historical helper, `cost_rank_proxy`,
constructs a smoothed rank-frequency table
using a reference context, histogram counts,
and parameter `alpha`. That helper must not
be confused with the frozen rank table used
by the Stage 9 `Rank` objective.

The helper `cost_calibrated` multiplies the
analysis bits by a length-specific coefficient
\(\kappa_L\). Its presence in the source does
not establish that it was selected for every
Stage 9 search.

**Sources:** `stage5_tools.py`, lines 36–59;
`stage9_objective_function.py`, lines 1–27.

## 5. BC-DP layout search

The Stage 9 search function enumerates
combinations of:

- Compression-related objective family.
- A configured decoding-time cost model.
- A value from the selected lambda grid.

For each combination, the implementation
constructs an `s5.TreeDP` policy with the
corresponding cost, lambda and per-chunk
time function.

The policy proposes a sequence of leaves.
The source hashes the leaf sequence with
SHA-256 and evaluates each previously unseen
layout.

This deduplication step distinguishes the
number of searched configurations from the
number of unique candidate layouts.

The implementation's precise optimization
recurrence should be derived from `TreeDP`
before a mathematical recurrence is added
to the publication.

### Binary-tree layout recurrence

The frozen `TreeDP` implementation operates on
binary subdivisions of a configured root block
length, denoted by `BLOCK`.

For a candidate block beginning at position \(s\)
with length \(L\), the implementation defines
the leaf cost as

\[
J_{\mathrm{leaf}}(s,L)
=
C_L[s/L] + \lambda\,t(L),
\]

where \(C_L\) is the precomputed cost array for
block length \(L\), \(\lambda\) is the selected
search parameter, and \(t(L)\) is the configured
estimated time cost of a block of length \(L\).

Array indexing uses the integer position \(s/L\)
for aligned candidate blocks.

When \(L\) is greater than the minimum supported
block length, the alternative split cost is

\[
J_{\mathrm{split}}(s,L)
=
J(s,L/2)+J(s+L/2,L/2).
\]

The implementation chooses the lower-cost
available alternative. When the leaf and split
costs are equal, the leaf is preferred.

A leaf is considered only when its length and
index are valid in the precomputed cost array.
When a leaf cannot be used, the implementation
falls back to the split alternative.

For positions at or beyond the padded sequence
length, the recursive solver returns zero cost
and an empty leaf list.

The source invokes the solver independently
at root offsets separated by `BLOCK`.

Accordingly, the search selects a minimum-cost
layout within this implementation's configured
binary subdivision tree and supplied cost model.
This is not a claim of global optimality across
arbitrary segmentations or arbitrary cost models.

**Source:** `stage5_tools.py`, lines 67–92.

## 6. Search-space ablations

The full and reduced search configurations
differ along two recorded dimensions.

BC-DP-Full uses five allowed block lengths
and the dense grid of
122 lambda values.

BC-DP-ReducedSearch retains the five block
lengths but uses the reduced grid of
32 lambda values.

BC-DP-ReducedLevels uses three block lengths
and the dense lambda grid.

Fast-BC-DP combines the three-length
configuration and the reduced lambda grid.

The measured Stage 9 comparisons therefore
evaluate changes to the search configuration,
rather than a completely separate neural
language model.

## 7. Decoder-cost modeling

The archived decoder-cost configuration
contains historical measured chunk latencies
at lengths 32, 64, 128, 256 and 512.

The cost calibration is identified as
`Stage7-Session01`.

The record also identifies historical
Stage 6A measurements as validation data
and marks the validation as cross-session.

These cost estimates are used to inform
layout search. A predicted decoding time
must not be presented as a fresh measured
full-decoding time.

### Historical decode-cost calibration

The source defines a quadratic chunk-time
model of the form

\[
t_{\mathrm{quad}}(L)=cL^2,
\]

where the helper documents its output in
seconds per chunk.

The archived Stage 7 calibration records an
older coefficient of `0.000102` and a
fitted coefficient of `9.25933640728e-05`.

The calibration additionally stores measured
chunk latencies for lengths 32, 64, 128,
256 and 512, with an associated batch plan.

Historical cross-session validation used
Stage 6A measurements and reported these
mean absolute percentage errors:

- Old quadratic: 16.6348%.
- Fitted quadratic:
  5.8785%.
- Measured-latency:
  6.8977%.

The fitted quadratic had the lowest MAPE
among those three historical alternatives.

These values belong to `Stage7-Session01`.
They are not new Stage 11 measurements or
a guarantee of accuracy on untested data.

The source-level function defining a
quadratic model and the archived fitted
coefficient are separate pieces of evidence;
the presence of that coefficient does not
by itself establish which model was selected
for every historical encoder run.

**Sources:** `stage5_tools.py`, lines 63–64;
`decode_cost_config.json`.

## 8. Compressed representation

The frozen `encode` implementation calculates
token ranks for the selected leaves and records
escape positions and associated token IDs.

For escape positions, a placeholder rank is
placed in the rank stream.

The codec then constructs:

- A header containing format and model-related
  metadata, token count and batch plan.
- A packed representation of the block layout.
- A BZip2-compressed rank stream.
- A BZip2-compressed escape stream when
  escape entries are present.

The escape-position sequence is converted
to successive differences before compression.

The stored rank width is selected according
to the language-model vocabulary size.

BZip2 is therefore part of the actual
FineZip28 storage format, not merely an
external compression baseline.

The artifact size includes the container
header and the compressed payloads.

## 9. Reconstruction and lossless verification

The decoder parses the stored header,
reconstructs the block layout and obtains
the batch plan recorded during encoding.

It processes groups of leaves with the
corresponding block length and invokes
`_decode_group` to reconstruct token blocks.

After reconstruction, the decoder returns
only the original number of tokens,
discarding the appended padding.

The Stage 10 experiment independently
verified exact token reconstruction,
exact byte reconstruction and matching
SHA-256 for the 1 MB sample.

This constitutes lossless verification for
the recorded experiment; it does not
establish correctness for arbitrary inputs
without additional testing.

### Detailed rank and escape reconstruction

During decoding, `_parse` reads the stored
header, reconstructs the block layout,
decompresses the BZip2 rank payload, and
decompresses the escape payload when present.

The escape payload stores delta-coded positions
and token identifiers. The parser reconstructs
the absolute positions by cumulative summation.

For blocks of the same length, `_decode_group`
forms a batch and initializes the model input
with beginning-of-sequence tokens.

At each position within a block, `lm.pick`
uses the stored rank and current model context
to select a token.

If the current absolute position is present
in the escape dictionary, its explicitly
stored token replaces the rank-selected token.

The reconstructed token is then supplied as
input for the following position in the block.
Thus, reconstruction proceeds autoregressively
within each block.

The public `decode` function combines these
reconstructed blocks and truncates the output
to the original token count stored in the file.

This description follows the implementation.
It does not independently prove that every
possible encoded input is recoverable.

**Source:** `adaptive_context_finezip_v3.py`,
lines 475–548.

### Model and environment compatibility checks

The encoder stores a model fingerprint formed
from the first eight bytes of a SHA-256 digest
of the serialized model configuration.

The decoder recomputes this fingerprint.
A mismatch raises `ValueError`, preventing
decoding with that mismatched model configuration.

A mismatch in stored rank width also raises
`ValueError`.

The serialized runtime environment is checked
separately. If the current environment differs
from the recorded environment, `_parse` issues
a `RuntimeWarning` describing the discrepancy.

An environment mismatch is therefore a
warning condition rather than an unconditional
rejection condition in this implementation.

The source warns that exact reconstruction
may not be guaranteed under some environment
differences, particularly when no escape
entries are present.

The archived Stage 10 byte-level verification
provides direct evidence of lossless recovery
for its tested artifact; fingerprint validation
alone is not a general proof of losslessness.

**Source:** `adaptive_context_finezip_v3.py`,
lines 415–418 and 475–514.

## 10. Implementation and evidence boundaries

The source-derived description is limited
to functionality verified in the frozen
implementation and archived records.

The binary-tree recurrence, rank/escape
reconstruction flow, and fingerprint checks
have now been examined against the frozen
implementation.

The following details still require additional
verification before journal submission:

- The complete mathematical interpretation
  and units of the NLL and rank-related
  cost functions.
- The complete definitions and applicability
  of the historical decoding-time cost models.
- General correctness across input distributions
  beyond the archived verification cases.
- Any formal optimality claim beyond the
  configured binary search tree.

The current draft does not claim formal
optimality of the layout-selection method,
statistical significance for single-run
timing differences or superiority over
unevaluated neural compression systems.
