# Table 1. Compression comparison on six 100 KB datasets

| Dataset | Best FineZip | FineZip bytes | Best traditional | Traditional bytes | Overall winner | FineZip saving vs BZip2 |
| --- | --- | --- | --- | --- | --- | --- |
| csv_data | BC-DP-Full-128 | 35,724 | bz2 | 14,854 | bz2 | -140.50% |
| english | Fixed-128 | 29,911 | bz2 | 29,848 | bz2 | -0.21% |
| enwik8_new | BC-DP-Full-128 | 27,608 | bz2 | 31,303 | BC-DP-Full | +11.80% |
| mixed | BC-DP-ReducedLevels-128 | 37,430 | bz2 | 28,659 | bz2 | -30.60% |
| python_code | BC-DP-Full-128 | 25,878 | bz2 | 17,726 | bz2 | -45.99% |
| vietnamese | BC-DP-ReducedLevels-128 | 54,707 | bz2 | 26,832 | bz2 | -103.89% |

Note: Lower compressed size is better. Negative saving indicates that FineZip produces a larger file than BZip2. Stage 9 FineZip results are historical; Stage 10 traditional results were measured separately.
