# Table 2. Compression and timing on the 1 MB enwik8 sample

| Method | Compressed bytes | Ratio | BPB | Encode (s) | Decode (s) | Saving vs BZip2 | Timing source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Fixed-512 | 213,691 | 4.6797 | 1.7095 | 29.4712 | 12950.8678 | +24.04% | Historical Stage6A |
| Adaptive-DP-1000 | 216,534 | 4.6182 | 1.7323 | 176.2434 | 10103.9862 | +23.03% | Historical Stage6A |
| Fixed-256 | 228,006 | 4.3858 | 1.8240 | 29.0480 | 6356.6881 | +18.95% | Historical Stage6A |
| Adaptive-DP-5000 | 238,128 | 4.1994 | 1.9050 | 174.8895 | 3939.2909 | +15.35% | Historical Stage6A |
| Fixed-128 | 246,976 | 4.0490 | 1.9758 | 28.5877 | 3157.6798 | +12.21% | Historical Stage6A |
| Adaptive-DP-12000 | 258,127 | 3.8741 | 2.0650 | 175.2941 | 2104.7104 | +8.25% | Historical Stage6A |
| Fixed-64 | 271,704 | 3.6805 | 2.1736 | 28.9751 | 1662.7138 | +3.42% | Historical Stage6A |
| Fast-BC-DP-64 | 273,990 | 3.6498 | 2.1919 | 117.3890 | 1386.1740 | +2.61% | Measured Stage10-Session01 |
| bz2 | 281,323 | 3.5546 | 2.2506 | 0.0910 | 0.0410 | +0.00% | Measured Stage10-Session01 |
| Adaptive-DP-40000 | 288,012 | 3.4721 | 2.3041 | 176.7067 | 1020.1877 | -2.38% | Historical Stage6A |
| xz | 290,692 | 3.4401 | 2.3255 | 0.3438 | 0.0200 | -3.33% | Measured Stage10-Session01 |
| zstd | 300,111 | 3.3321 | 2.4009 | 0.3233 | 0.0016 | -6.68% | Measured Stage10-Session01 |
| Fixed-32 | 300,576 | 3.3269 | 2.4046 | 28.5648 | 838.8019 | -6.84% | Historical Stage6A |
| gzip | 355,791 | 2.8106 | 2.8463 | 0.0664 | 0.0052 | -26.47% | Measured Stage10-Session01 |

Note: All configurations have lossless evidence. Stage 6A FineZip timings are historical observations. Traditional baselines report Stage 10 median timings from three repeats. Fast BC-DP Stage 10 timings are single-run measurements. Timing comparisons across sessions are descriptive, not controlled speedup measurements.
