# FineZip28 — Objective and Decode-Cost Source

Verified frozen implementation, Stage 11 Cell 18.

All excerpts are static; no source was executed.

## stage5_tools.cost_ac

Source: `provenance/stage5_tools.py`

```python
0036 | def cost_ac(A):
0037 |     return {L: A[L]["bits"] for L in A}
```

## stage5_tools.cost_calibrated

Source: `provenance/stage5_tools.py`

```python
0045 | def cost_calibrated(A, kap):
0046 |     return {L: kap[L] * A[L]["bits"] for L in A}
```

## stage5_tools.cost_rank_proxy

Source: `provenance/stage5_tools.py`

```python
0049 | def cost_rank_proxy(A, ref=128, alpha=0.5, rmax=4096):
0050 |     """Mã tĩnh bậc 0 cho rank, dựng từ histogram rank ở mức `ref` (thô hơn bz2 nhưng cùng 'ngôn ngữ rank')."""
0051 |     r0 = np.minimum(A[ref]["ranks"].ravel(), rmax)
0052 |     cnt = np.bincount(r0, minlength=rmax + 1).astype(float)
0053 |     table = -np.log2((cnt + alpha) / (cnt.sum() + alpha * (rmax + 1)))
0054 |     out = {}
0055 |     for L in A:
0056 |         r = A[L]["ranks"]
0057 |         tail = np.where(r >= rmax, np.log2(np.maximum(r, 1)), 0.0)        # rank hiếm: + log2(rank) bit cho chỉ số trong đuôi
0058 |         out[L] = table[np.minimum(r, rmax)].sum(1) + tail.sum(1)
0059 |     return out
```

## stage5_tools.block_cost_matrix

Source: `provenance/stage5_tools.py`

```python
0123 | def block_cost_matrix(cost, lam, t_chunk=None, levels=LEVELS):
0124 |     """C[b, j] = J nếu cả khối 512 thứ b dùng chunk dài levels[j] (chỉ các khối đủ 512)."""
0125 |     t = t_chunk or t_dec_quadratic()
0126 |     nb = len(cost[BLOCK])
0127 |     C = np.zeros((nb, len(levels)))
0128 |     for j, L in enumerate(levels):
0129 |         k = BLOCK // L
0130 |         C[:, j] = cost[L][:nb * k].reshape(nb, k).sum(1) + lam * t(L) * k
0131 |     return C
```

## stage9_objectives.build_stage9_objectives

Source: `code/stage9_objective_function.py`

```python
0001 | def build_stage9_objectives(analysis):
0002 | 
0003 |     cost_nll = s5.cost_ac(analysis)
0004 | 
0005 |     cost_rank = {}
0006 | 
0007 |     for L, values in analysis.items():
0008 | 
0009 |         ranks = values["ranks"]
0010 | 
0011 |         tail = np.where(
0012 |             ranks >= RMAX,
0013 |             np.log2(np.maximum(ranks, 1)),
0014 |             0.0
0015 |         )
0016 | 
0017 |         cost_rank[L] = (
0018 |             rank_table[
0019 |                 np.minimum(ranks, RMAX)
0020 |             ].sum(axis=1)
0021 |             + tail.sum(axis=1)
0022 |         )
0023 | 
0024 |     return {
0025 |         "NLL": cost_nll,
0026 |         "Rank": cost_rank
0027 |     }
```

## stage9_helpers.evaluate_stage9_layout

Source: `code/stage9_helper_functions.py`

```python
0001 | def evaluate_stage9_layout(leaves, analysis, n_pad):
0002 | 
0003 |     cursor = 0
0004 |     rank_parts = []
0005 | 
0006 |     counts = {
0007 |         int(L): 0 for L in LEVELS
0008 |     }
0009 | 
0010 |     for start, L in leaves:
0011 | 
0012 |         assert start == cursor
0013 |         assert start + L <= n_pad
0014 |         assert L in analysis
0015 | 
0016 |         rank_parts.append(
0017 |             analysis[L]["ranks"][start // L]
0018 |         )
0019 | 
0020 |         counts[L] += 1
0021 |         cursor += L
0022 | 
0023 |     assert cursor == n_pad
0024 | 
0025 |     ranks = np.concatenate(
0026 |         rank_parts
0027 |     ).astype("<u2")
0028 | 
0029 |     payload_bytes = len(
0030 |         bz2.compress(
0031 |             ranks.tobytes(),
0032 |             compresslevel=9
0033 |         )
0034 |     )
0035 | 
0036 |     flags = fz.layout_to_flags(
0037 |         leaves, n_pad
0038 |     )
0039 | 
0040 |     layout_bytes = (len(flags) + 7) // 8
0041 | 
0042 |     predicted_decode_s = sum(
0043 |         counts[L] * measured_cost[L]
0044 |         for L in LEVELS
0045 |     )
0046 | 
0047 |     layout_hash = hashlib.sha256(
0048 |         np.asarray(
0049 |             leaves,
0050 |             dtype=np.int64
0051 |         ).tobytes()
0052 |     ).hexdigest()
0053 | 
0054 |     return {
0055 |         "layout_sha256": layout_hash,
0056 |         "payload_bytes": payload_bytes,
0057 |         "layout_bytes": layout_bytes,
0058 |         "variable_bytes":
0059 |             payload_bytes + layout_bytes,
0060 |         "predicted_decode_s":
0061 |             predicted_decode_s,
0062 |         "effective_L": sum(
0063 |             counts[L] * L**2
0064 |             for L in LEVELS
0065 |         ) / n_pad,
0066 |         "chunk_counts": counts
0067 |     }
```

## stage9_helpers.search_stage9

Source: `code/stage9_helper_functions.py`

```python
0073 | def search_stage9(
0074 |     toks_pad,
0075 |     analysis,
0076 |     lambda_grid
0077 | ):
0078 | 
0079 |     t0 = time.perf_counter()
0080 | 
0081 |     objectives = build_stage9_objectives(
0082 |         analysis
0083 |     )
0084 | 
0085 |     search_rows = []
0086 |     evaluated = {}
0087 |     layouts = {}
0088 | 
0089 |     for objective_name, cost in objectives.items():
0090 | 
0091 |         for time_name, time_fn in time_models.items():
0092 | 
0093 |             for lam in lambda_grid:
0094 | 
0095 |                 policy = s5.TreeDP(
0096 |                     cost=cost,
0097 |                     lam=float(lam),
0098 |                     t_chunk=time_fn
0099 |                 )
0100 | 
0101 |                 leaves = policy(toks_pad)
0102 | 
0103 |                 key = hashlib.sha256(
0104 |                     np.asarray(
0105 |                         leaves,
0106 |                         dtype=np.int64
0107 |                     ).tobytes()
0108 |                 ).hexdigest()
0109 | 
0110 |                 if key not in evaluated:
0111 | 
0112 |                     evaluated[key] = (
0113 |                         evaluate_stage9_layout(
0114 |                             leaves,
0115 |                             analysis,
0116 |                             len(toks_pad)
0117 |                         )
0118 |                     )
0119 | 
0120 |                     layouts[key] = leaves
0121 | 
0122 |                 search_rows.append({
0123 |                     "objective": objective_name,
0124 |                     "time_model": time_name,
0125 |                     "lambda": float(lam),
0126 |                     **evaluated[key]
0127 |                 })
0128 | 
0129 |     search_df = pd.DataFrame(search_rows)
0130 | 
0131 |     elapsed = time.perf_counter() - t0
0132 | 
0133 |     return search_df, layouts, elapsed
```

## stage5_tools.cost_calibrated

```python
0045 | def cost_calibrated(A, kap):
0046 |     return {L: kap[L] * A[L]["bits"] for L in A}
```

## stage5_tools.t_dec_quadratic

```python
0063 | def t_dec_quadratic(c=1.02e-4):
0064 |     return lambda L: c * L * L          # giây / chunk. Thay bằng bảng đo thật tdec[L] khi đã hiệu chuẩn.
```
