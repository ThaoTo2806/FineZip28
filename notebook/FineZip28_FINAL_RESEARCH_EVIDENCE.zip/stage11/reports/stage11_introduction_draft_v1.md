# 1. Introduction

Lossless text compression aims to represent a
sequence compactly while retaining the ability
to reconstruct its original content exactly.
Traditional compressors and language-model-based
approaches offer different mechanisms for
exploiting regularities in text. For neural
approaches, however, compression performance
must be considered alongside the computational
cost of model evaluation and decoding.

A language model can provide context-dependent
information about a token sequence, but using
that information within a practical lossless
codec introduces several design decisions.
These include how the input is partitioned,
how model-derived information is represented,
how encoding candidates are evaluated, and
how the resulting data can be decoded
reproducibly.

This study investigates these decisions in
FineZip28, a GPT-2-based compression workflow
that uses variable-length context blocks and
rank-based token representation. Its stored
format combines block-layout metadata with
BZip2-compressed rank and escape streams.
The decoder reconstructs tokens
autoregressively, using stored escape tokens
where necessary.

A central focus is the search procedure used
to determine the block layout. FineZip28
uses a binary-tree dynamic-programming
procedure that evaluates block-related costs
together with estimated decoding costs.
The search operates within a configured
set of block lengths, objective functions,
time-cost models, and trade-off parameters.

Because candidate evaluation itself requires
computation, increasing search flexibility
does not necessarily improve the practical
encoding workflow. This motivates the
evaluation of restricted search designs.
In particular, Fast-BC-DP combines a reduced
set of block lengths with a reduced grid of
trade-off parameters. The study compares
this design against a full-search
configuration and two intermediate ablations.

The experiments examine compression size,
encoding time, and available decoding
evidence across multiple text datasets.
Traditional lossless compressors provide
reference baselines. A separate larger-input
experiment examines an operationally
relevant configuration with exact
reconstruction verification.

The contributions of this study are:

1. An implementation-grounded examination of
   context-block layout selection under
   compression-related and estimated
   decoding-cost objectives.

2. A controlled-configuration ablation of
   the search space, separating reduced
   lambda search from reduced block-length
   choices.

3. An empirical analysis of the trade-offs
   between search effort, encoding time,
   and final compressed size on the
   available benchmark datasets.

4. A reproducibility-oriented account of
   the compressed representation, model
   compatibility checks, historical timing
   provenance, and verified reconstruction
   results.

The scope of these contributions is bounded
by the evaluated datasets, implementations,
and archived measurements. The study does
not claim universal compression superiority
or demonstrate a new language-model
architecture.

The remainder of the manuscript presents
related work, the FineZip28 methodology,
the experimental setup, the results and
their limitations, and the conclusions.

**Editorial note:** Insert verified scholarly
citations for background claims after the
Related Work and References audit.
