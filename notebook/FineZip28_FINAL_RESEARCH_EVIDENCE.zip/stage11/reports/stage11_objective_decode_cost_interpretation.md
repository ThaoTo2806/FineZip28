# FineZip28 — Objective and Decode-Cost Audit

## Source basis

Frozen commit:
`62f09e3105296d62c39e8d95cf8b8775e63f2677`

All inspected source files matched the archived
Stage 10 FINAL SHA-256 manifest.

## Compression objectives

The Stage 9 implementation constructs two
objective families:

- NLL, through `s5.cost_ac`.
- Rank, through a stored rank-cost lookup
  and logarithmic tail for larger ranks.

The complete source definitions are preserved
in the accompanying numbered-source report.

A numerical cost value must not automatically
be described as compressed bytes, measured
decode seconds or a normalized probability.

## Decode-time cost estimation

Decoder-cost calibration session:
`Stage7-Session01`

Validation data:
`Stage 6A historical measurements`

Cross-session validation:
`True`

Recorded historical MAPE:

- Old quadratic:
  16.6348%.
- Fitted quadratic:
  5.8785%.
- Measured-latency:
  6.8977%.

These MAPE values are historical calibration
records, not Stage 11 measurements.

## Scientific boundaries

- Cost formulas must be described with source-
  supported units and normalization.
- MAPE does not establish predictive accuracy
  for every untested dataset or context.
- Stage 7 cross-session validation must be
  distinguished from same-session validation.
- A decode-time estimate is not interchangeable
  with a measured full-decoding time.
- No new neural compression experiment was run.

## Pending integration

Review the extracted formulas and use them
to update Methodology v2 only when their
mathematical interpretation is confirmed.
