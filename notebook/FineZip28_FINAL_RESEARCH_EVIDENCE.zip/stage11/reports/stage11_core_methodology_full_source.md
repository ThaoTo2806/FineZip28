# FineZip28 — Core Methodology Source Evidence

Static extraction from SHA-256-verified source.
No source functions were executed.

## stage9_encode.encode_stage9

Source lines 1–318

```python
0001 | def encode_stage9(dataset_name, method, target):
0002 | 
0003 |     key = (dataset_name, method, target)
0004 | 
0005 |     raw = datasets[dataset_name]
0006 |     tokens = dataset_tokens[dataset_name]
0007 |     toks_pad = padded_tokens[dataset_name]
0008 | 
0009 |     artifact_path = (
0010 |         STAGE / "artifacts" /
0011 |         f"{dataset_name}_{method}_{target}.fzac"
0012 |     )
0013 | 
0014 |     if key in encode_completed9:
0015 | 
0016 |         previous = encode_completed9[key]
0017 | 
0018 |         assert artifact_path.is_file()
0019 | 
0020 |         assert hashlib.sha256(
0021 |             artifact_path.read_bytes()
0022 |         ).hexdigest() == previous["artifact_sha256"]
0023 | 
0024 |         print(f"SKIP | {key}")
0025 | 
0026 |         return previous
0027 | 
0028 |     print(
0029 |         f"\n=== ENCODE: {dataset_name} | "
0030 |         f"{method} | Target={target} ===",
0031 |         flush=True
0032 |     )
0033 | 
0034 |     gc.collect()
0035 |     torch.cuda.empty_cache()
0036 |     torch.cuda.reset_peak_memory_stats(0)
0037 |     torch.cuda.synchronize()
0038 | 
0039 |     analysis_seconds = 0.0
0040 |     search_seconds = 0.0
0041 | 
0042 |     selection = None
0043 | 
0044 |     start_total = time.perf_counter()
0045 | 
0046 |     # ==================== FIXED POLICY ====================
0047 | 
0048 |     if method == "Fixed":
0049 | 
0050 |         policy = fz.FixedPolicy(target)
0051 | 
0052 |         levels = [target]
0053 |         proposals = 0
0054 |         unique_layouts = 0
0055 | 
0056 |     # ==================== ADAPTIVE POLICY ====================
0057 | 
0058 |     else:
0059 | 
0060 |         config = ABLATION_CONFIGS[method]
0061 | 
0062 |         levels = config["levels"]
0063 | 
0064 |         lambda_grid = (
0065 |             DENSE_LAMBDAS
0066 |             if config["lambda_grid"] == "dense"
0067 |             else REDUCED_LAMBDAS
0068 |         )
0069 | 
0070 |         # Fresh GPU inference
0071 |         t0 = time.perf_counter()
0072 | 
0073 |         analysis = s5.analyze(
0074 |             toks_pad,
0075 |             lm,
0076 |             batch=8,
0077 |             levels=tuple(levels)
0078 |         )
0079 | 
0080 |         torch.cuda.synchronize()
0081 | 
0082 |         analysis_seconds = (
0083 |             time.perf_counter() - t0
0084 |         )
0085 | 
0086 |         # Fresh layout search
0087 |         t0 = time.perf_counter()
0088 | 
0089 |         fixed_leaves = fz.FixedPolicy(target)(
0090 |             toks_pad, lm, 8
0091 |         )
0092 | 
0093 |         fixed_reference = evaluate_stage9_layout(
0094 |             fixed_leaves,
0095 |             analysis,
0096 |             len(toks_pad)
0097 |         )
0098 | 
0099 |         search_df, layouts, _ = search_stage9(
0100 |             toks_pad,
0101 |             analysis,
0102 |             lambda_grid
0103 |         )
0104 | 
0105 |         feasible = search_df[
0106 |             search_df["predicted_decode_s"]
0107 |             <= fixed_reference["predicted_decode_s"]
0108 |         ]
0109 | 
0110 |         assert not feasible.empty
0111 | 
0112 |         best = feasible.sort_values([
0113 |             "variable_bytes",
0114 |             "predicted_decode_s"
0115 |         ]).iloc[0]
0116 | 
0117 |         chosen_leaves = layouts[
0118 |             best["layout_sha256"]
0119 |         ]
0120 | 
0121 |         search_seconds = (
0122 |             time.perf_counter() - t0
0123 |         )
0124 | 
0125 |         proposals = len(search_df)
0126 |         unique_layouts = len(layouts)
0127 | 
0128 |         # Verify against cached screening
0129 |         expected = ablation_layouts[
0130 |             dataset_name
0131 |         ][method][str(target)]["selection"]
0132 | 
0133 |         selection = {
0134 |             "objective": str(best["objective"]),
0135 |             "time_model": str(best["time_model"]),
0136 |             "lambda": float(best["lambda"]),
0137 | 
0138 |             "layout_sha256": str(
0139 |                 best["layout_sha256"]
0140 |             ),
0141 | 
0142 |             "variable_bytes": int(
0143 |                 best["variable_bytes"]
0144 |             ),
0145 | 
0146 |             "predicted_budget_s": float(
0147 |                 fixed_reference["predicted_decode_s"]
0148 |             ),
0149 | 
0150 |             "matches_cached_layout": bool(
0151 |                 best["layout_sha256"]
0152 |                 == expected["layout_sha256"]
0153 |             )
0154 |         }
0155 | 
0156 |         def policy(
0157 |             toks, model, batch,
0158 |             leaves=chosen_leaves
0159 |         ):
0160 |             return leaves
0161 | 
0162 |     # ==================== REAL CODEC ENCODE ====================
0163 | 
0164 |     torch.cuda.synchronize()
0165 | 
0166 |     t0 = time.perf_counter()
0167 | 
0168 |     blob, leaves = fz.encode(
0169 |         tokens,
0170 |         lm,
0171 |         policy,
0172 |         batch=8
0173 |     )
0174 | 
0175 |     torch.cuda.synchronize()
0176 | 
0177 |     codec_seconds = (
0178 |         time.perf_counter() - t0
0179 |     )
0180 | 
0181 |     total_encode_seconds = (
0182 |         time.perf_counter() - start_total
0183 |     )
0184 | 
0185 |     peak_mib = (
0186 |         torch.cuda.max_memory_allocated(0)
0187 |         / 1024**2
0188 |     )
0189 | 
0190 |     # ==================== LAYOUT VERIFICATION ====================
0191 | 
0192 |     counts = {
0193 |         int(L): int(sum(
0194 |             length == L
0195 |             for _, length in leaves
0196 |         ))
0197 |         for L in LEVELS
0198 |     }
0199 | 
0200 |     predicted_decode_s = sum(
0201 |         counts[L] * measured_cost[L]
0202 |         for L in LEVELS
0203 |     )
0204 | 
0205 |     layout_sha256 = hashlib.sha256(
0206 |         np.asarray(
0207 |             leaves, dtype=np.int64
0208 |         ).tobytes()
0209 |     ).hexdigest()
0210 | 
0211 |     if method != "Fixed":
0212 | 
0213 |         assert layout_sha256 == (
0214 |             selection["layout_sha256"]
0215 |         )
0216 | 
0217 |         assert predicted_decode_s <= (
0218 |             selection["predicted_budget_s"]
0219 |             + 1e-8
0220 |         )
0221 | 
0222 |         assert all(
0223 |             L in levels
0224 |             for _, L in leaves
0225 |         )
0226 | 
0227 |     # ==================== SAVE ARTIFACT ====================
0228 | 
0229 |     artifact_path.write_bytes(blob)
0230 | 
0231 |     artifact_sha256 = hashlib.sha256(
0232 |         blob
0233 |     ).hexdigest()
0234 | 
0235 |     assert hashlib.sha256(
0236 |         artifact_path.read_bytes()
0237 |     ).hexdigest() == artifact_sha256
0238 | 
0239 |     record = {
0240 |         "dataset": dataset_name,
0241 |         "method": method,
0242 |         "context": int(target),
0243 |         "levels": list(levels),
0244 |         "search_configurations": proposals,
0245 |         "unique_layouts": unique_layouts,
0246 | 
0247 |         "original_bytes": len(raw),
0248 |         "original_sha256": hashlib.sha256(
0249 |             raw
0250 |         ).hexdigest(),
0251 | 
0252 |         "tokens": len(tokens),
0253 |         "padded_tokens": len(toks_pad),
0254 | 
0255 |         "compressed_bytes": len(blob),
0256 |         "ratio": len(raw) / len(blob),
0257 |         "bpb": 8 * len(blob) / len(raw),
0258 | 
0259 |         "analysis_seconds": analysis_seconds,
0260 |         "search_seconds": search_seconds,
0261 |         "codec_seconds": codec_seconds,
0262 |         "total_encode_seconds": total_encode_seconds,
0263 |         "encode_peak_mib": peak_mib,
0264 | 
0265 |         "predicted_decode_s": predicted_decode_s,
0266 | 
0267 |         "effective_L": sum(
0268 |             int(L)**2 for _, L in leaves
0269 |         ) / len(toks_pad),
0270 | 
0271 |         "chunk_counts": counts,
0272 |         "layout_sha256": layout_sha256,
0273 | 
0274 |         "selection": selection,
0275 | 
0276 |         "artifact_path": str(artifact_path),
0277 |         "artifact_sha256": artifact_sha256,
0278 | 
0279 |         "encode_session_id": SESSION_ID,
0280 |         "gpu_name": torch.cuda.get_device_name(0),
0281 | 
0282 |         "full_decode": "PENDING"
0283 |     }
0284 | 
0285 |     encode_records9.append(record)
0286 |     encode_completed9[key] = record
0287 | 
0288 |     # Atomic checkpoint
0289 |     temp = ENCODE_JSON9.with_suffix(".tmp")
0290 | 
0291 |     temp.write_text(
0292 |         json.dumps(encode_records9, indent=2)
0293 |     )
0294 | 
0295 |     temp.replace(ENCODE_JSON9)
0296 | 
0297 |     pd.DataFrame(encode_records9).to_csv(
0298 |         ENCODE_CSV9,
0299 |         index=False
0300 |     )
0301 | 
0302 |     print("Compressed:", len(blob), "B")
0303 |     print("Analysis:", round(analysis_seconds, 4), "s")
0304 |     print("Search:", round(search_seconds, 4), "s")
0305 |     print("Codec:", round(codec_seconds, 4), "s")
0306 |     print("Total encode:", round(total_encode_seconds, 4), "s")
0307 | 
0308 |     print(
0309 |         "Peak GPU:",
0310 |         round(peak_mib, 2),
0311 |         "MiB"
0312 |     )
0313 | 
0314 |     print(
0315 |         f"CHECKPOINT: {len(encode_records9)}/60"
0316 |     )
0317 | 
0318 |     return record
```

## stage9_helpers.evaluate_stage9_layout

Source lines 1–67

```python
0001 | def evaluate_stage9_layout(leaves, analysis, n_pad):
0002 | 
0003 |     cursor = 0
0004 |     rank_parts = []
0005 | 
0006 |     counts = {
0007 |         int(L): 0 for L in LEVELS
0008 |     }
0009 | 
0010 |     for start, L in leaves:
0011 | 
0012 |         assert start == cursor
0013 |         assert start + L <= n_pad
0014 |         assert L in analysis
0015 | 
0016 |         rank_parts.append(
0017 |             analysis[L]["ranks"][start // L]
0018 |         )
0019 | 
0020 |         counts[L] += 1
0021 |         cursor += L
0022 | 
0023 |     assert cursor == n_pad
0024 | 
0025 |     ranks = np.concatenate(
0026 |         rank_parts
0027 |     ).astype("<u2")
0028 | 
0029 |     payload_bytes = len(
0030 |         bz2.compress(
0031 |             ranks.tobytes(),
0032 |             compresslevel=9
0033 |         )
0034 |     )
0035 | 
0036 |     flags = fz.layout_to_flags(
0037 |         leaves, n_pad
0038 |     )
0039 | 
0040 |     layout_bytes = (len(flags) + 7) // 8
0041 | 
0042 |     predicted_decode_s = sum(
0043 |         counts[L] * measured_cost[L]
0044 |         for L in LEVELS
0045 |     )
0046 | 
0047 |     layout_hash = hashlib.sha256(
0048 |         np.asarray(
0049 |             leaves,
0050 |             dtype=np.int64
0051 |         ).tobytes()
0052 |     ).hexdigest()
0053 | 
0054 |     return {
0055 |         "layout_sha256": layout_hash,
0056 |         "payload_bytes": payload_bytes,
0057 |         "layout_bytes": layout_bytes,
0058 |         "variable_bytes":
0059 |             payload_bytes + layout_bytes,
0060 |         "predicted_decode_s":
0061 |             predicted_decode_s,
0062 |         "effective_L": sum(
0063 |             counts[L] * L**2
0064 |             for L in LEVELS
0065 |         ) / n_pad,
0066 |         "chunk_counts": counts
0067 |     }
```

## stage9_helpers.search_stage9

Source lines 73–133

```python
0073 | def search_stage9(
0074 |     toks_pad,
0075 |     analysis,
0076 |     lambda_grid
0077 | ):
0078 | 
0079 |     t0 = time.perf_counter()
0080 | 
0081 |     objectives = build_stage9_objectives(
0082 |         analysis
0083 |     )
0084 | 
0085 |     search_rows = []
0086 |     evaluated = {}
0087 |     layouts = {}
0088 | 
0089 |     for objective_name, cost in objectives.items():
0090 | 
0091 |         for time_name, time_fn in time_models.items():
0092 | 
0093 |             for lam in lambda_grid:
0094 | 
0095 |                 policy = s5.TreeDP(
0096 |                     cost=cost,
0097 |                     lam=float(lam),
0098 |                     t_chunk=time_fn
0099 |                 )
0100 | 
0101 |                 leaves = policy(toks_pad)
0102 | 
0103 |                 key = hashlib.sha256(
0104 |                     np.asarray(
0105 |                         leaves,
0106 |                         dtype=np.int64
0107 |                     ).tobytes()
0108 |                 ).hexdigest()
0109 | 
0110 |                 if key not in evaluated:
0111 | 
0112 |                     evaluated[key] = (
0113 |                         evaluate_stage9_layout(
0114 |                             leaves,
0115 |                             analysis,
0116 |                             len(toks_pad)
0117 |                         )
0118 |                     )
0119 | 
0120 |                     layouts[key] = leaves
0121 | 
0122 |                 search_rows.append({
0123 |                     "objective": objective_name,
0124 |                     "time_model": time_name,
0125 |                     "lambda": float(lam),
0126 |                     **evaluated[key]
0127 |                 })
0128 | 
0129 |     search_df = pd.DataFrame(search_rows)
0130 | 
0131 |     elapsed = time.perf_counter() - t0
0132 | 
0133 |     return search_df, layouts, elapsed
```

## stage9_objectives.build_stage9_objectives

Source lines 1–27

```python
0001 | def build_stage9_objectives(analysis):
0002 | 
0003 |     cost_nll = s5.cost_ac(analysis)
0004 | 
0005 |     cost_rank = {}
0006 | 
0007 |     for L, values in analysis.items():
0008 | 
0009 |         ranks = values["ranks"]
0010 | 
0011 |         tail = np.where(
0012 |             ranks >= RMAX,
0013 |             np.log2(np.maximum(ranks, 1)),
0014 |             0.0
0015 |         )
0016 | 
0017 |         cost_rank[L] = (
0018 |             rank_table[
0019 |                 np.minimum(ranks, RMAX)
0020 |             ].sum(axis=1)
0021 |             + tail.sum(axis=1)
0022 |         )
0023 | 
0024 |     return {
0025 |         "NLL": cost_nll,
0026 |         "Rank": cost_rank
0027 |     }
```

## finezip_codec.pad_tokens

Source lines 212–215

```python
0212 | def pad_tokens(tokens, bos):
0213 |     n = len(tokens)
0214 |     n_pad = -(-n // MIN_L) * MIN_L
0215 |     return np.concatenate([np.asarray(tokens), np.full(n_pad - n, bos, dtype=np.asarray(tokens).dtype)])
```

## finezip_codec.layout_to_flags

Source lines 257–273

```python
0257 | def layout_to_flags(leaves, n_pad):
0258 |     leafset, out = set(leaves), []
0259 | 
0260 |     def rec(s, L):
0261 |         if s >= n_pad or L == MIN_L:
0262 |             return
0263 |         if s + L > n_pad:
0264 |             split = True                         # ép tách -> không cần ghi cờ
0265 |         else:
0266 |             split = (s, L) not in leafset
0267 |             out.append(int(split))
0268 |         if split:
0269 |             rec(s, L // 2); rec(s + L // 2, L // 2)
0270 | 
0271 |     for s in range(0, n_pad, MAX_L):
0272 |         rec(s, MAX_L)
0273 |     return out
```

## finezip_codec.flags_to_layout

Source lines 276–292

```python
0276 | def flags_to_layout(flags, n_pad):
0277 |     it, leaves = iter(flags), []
0278 | 
0279 |     def rec(s, L):
0280 |         if s >= n_pad:
0281 |             return
0282 |         if L == MIN_L:
0283 |             leaves.append((s, L)); return
0284 |         split = True if s + L > n_pad else bool(next(it))
0285 |         if split:
0286 |             rec(s, L // 2); rec(s + L // 2, L // 2)
0287 |         else:
0288 |             leaves.append((s, L))
0289 | 
0290 |     for s in range(0, n_pad, MAX_L):
0291 |         rec(s, MAX_L)
0292 |     return leaves
```

## finezip_codec.encode

Source lines 438–472

```python
0438 | def encode(tokens, lm, policy, batch=8):
0439 |     toks = pad_tokens(tokens, lm.bos)
0440 |     leaves = policy(toks, lm, batch)
0441 |     plan = {L: int(lm.batch_size(L, batch)) if hasattr(lm, "batch_size") else int(batch) for L in CTX_SIZES}
0442 |     rank_of, esc_pos, esc_tok = {}, [], []
0443 |     for L in sorted({l for _, l in leaves}):
0444 |         starts = [s for s, l in leaves if l == L]
0445 |         _, r, u = run_score(toks, starts, L, lm, batch, eff=plan[L])      # ép dùng đúng kế hoạch đã ghi
0446 |         for i, s in enumerate(starts):
0447 |             ri = r[i].copy()
0448 |             ri[u[i]] = 0                                   # vị trí escape: rank không dùng -> 0 cho dễ nén
0449 |             rank_of[s] = ri
0450 |             idx = np.nonzero(u[i])[0]
0451 |             esc_pos += (s + idx).tolist(); esc_tok += toks[s + idx].tolist()
0452 |     order = np.argsort(esc_pos, kind="stable") if esc_pos else np.empty(0, int)
0453 |     esc_pos = np.asarray(esc_pos, np.int64)[order]; esc_tok = np.asarray(esc_tok, np.int64)[order]
0454 |     rank_width = 2 if lm.V <= np.iinfo(np.uint16).max + 1 else 4
0455 |     rank_dtype = "<u2" if rank_width == 2 else "<u4"
0456 |     ranks = (np.concatenate([rank_of[s] for s, _ in leaves]).astype(rank_dtype)
0457 |              if leaves else np.empty(0, dtype=rank_dtype))
0458 |     flags = layout_to_flags(leaves, len(toks))
0459 |     delta = np.diff(esc_pos, prepend=0).astype("<u4")
0460 |     esc_blob = bz2.compress(delta.tobytes() + esc_tok.astype(rank_dtype).tobytes(), 9) if len(esc_pos) else b""
0461 |     rk_blob = bz2.compress(ranks.tobytes(), 9)
0462 |     fp, _, env = _fingerprint(lm)
0463 |     eps = float(getattr(lm, "eps", None) or 0.0)
0464 |     envb = env.encode("utf-8")
0465 |     head = struct.pack(_HDR, FILE_MAGIC, FILE_VERSION, rank_width, 0, len(tokens), len(flags), len(esc_pos),
0466 |                        fp, eps, *[plan[L] for L in CTX_SIZES])
0467 |     head += struct.pack("<H", len(envb)) + envb
0468 |     head += np.packbits(np.array(flags, np.uint8)).tobytes() + struct.pack("<I", len(rk_blob))
0469 |     encode.last_stats = {"escapes": int(len(esc_pos)), "escape_pct": 100.0 * len(esc_pos) / max(1, len(toks)),
0470 |                          "esc_bytes": len(esc_blob), "total_bytes": len(head) + len(rk_blob) + len(esc_blob),
0471 |                          "header_bytes": len(head), "batch_plan": plan, "eps": eps}
0472 |     return head + rk_blob + esc_blob, leaves
```

## finezip_codec._decode_group

Source lines 525–537

```python
0525 | def _decode_group(ss, L, rk, esc, lm):
0526 |     R = np.stack([rk[s] for s in ss])
0527 |     inp = np.full((len(ss), L), lm.bos, np.int64)           # cùng shape [B,L] như encode
0528 |     dec = np.zeros((len(ss), L), np.int64)
0529 |     for p in range(L):                                        # tự hồi quy trong chunk, batch qua chunk
0530 |         dec[:, p] = lm.pick(inp, p, R[:, p])
0531 |         for j, s in enumerate(ss):                            # vị trí escape: dùng token đã lưu
0532 |             g = s + p
0533 |             if g in esc:
0534 |                 dec[j, p] = esc[g]
0535 |         if p + 1 < L:
0536 |             inp[:, p + 1] = dec[:, p]
0537 |     return dec
```

## finezip_codec.decode

Source lines 540–548

```python
0540 | def decode(blob, lm, batch=None):
0541 |     """Giải nén. `batch` được GIỮ để tương thích nhưng BỊ BỎ QUA: kế hoạch batch lấy từ header."""
0542 |     n, n_pad, leaves, rk, esc, plan = _parse(blob, lm)
0543 |     out = np.zeros(n_pad, np.int64)
0544 |     for L, ss in _groups(leaves, plan):
0545 |         dec = _decode_group(ss, L, rk, esc, lm)
0546 |         for j, s in enumerate(ss):
0547 |             out[s:s + L] = dec[j]
0548 |     return out[:n]
```

## stage5_cost_tools.cost_ac

Source lines 36–37

```python
0036 | def cost_ac(A):
0037 |     return {L: A[L]["bits"] for L in A}
```

## stage5_cost_tools.cost_calibrated

Source lines 45–46

```python
0045 | def cost_calibrated(A, kap):
0046 |     return {L: kap[L] * A[L]["bits"] for L in A}
```

## stage5_cost_tools.cost_rank_proxy

Source lines 49–59

```python
0049 | def cost_rank_proxy(A, ref=128, alpha=0.5, rmax=4096):
0050 |     """Mã tĩnh bậc 0 cho rank, dựng từ histogram rank ở mức `ref` (thô hơn bz2 nhưng cùng 'ngôn ngữ rank')."""
0051 |     r0 = np.minimum(A[ref]["ranks"].ravel(), rmax)
0052 |     cnt = np.bincount(r0, minlength=rmax + 1).astype(float)
0053 |     table = -np.log2((cnt + alpha) / (cnt.sum() + alpha * (rmax + 1)))
0054 |     out = {}
0055 |     for L in A:
0056 |         r = A[L]["ranks"]
0057 |         tail = np.where(r >= rmax, np.log2(np.maximum(r, 1)), 0.0)        # rank hiếm: + log2(rank) bit cho chỉ số trong đuôi
0058 |         out[L] = table[np.minimum(r, rmax)].sum(1) + tail.sum(1)
0059 |     return out
```

## stage5_cost_tools.block_cost_matrix

Source lines 123–131

```python
0123 | def block_cost_matrix(cost, lam, t_chunk=None, levels=LEVELS):
0124 |     """C[b, j] = J nếu cả khối 512 thứ b dùng chunk dài levels[j] (chỉ các khối đủ 512)."""
0125 |     t = t_chunk or t_dec_quadratic()
0126 |     nb = len(cost[BLOCK])
0127 |     C = np.zeros((nb, len(levels)))
0128 |     for j, L in enumerate(levels):
0129 |         k = BLOCK // L
0130 |         C[:, j] = cost[L][:nb * k].reshape(nb, k).sum(1) + lam * t(L) * k
0131 |     return C
```
