# FineZip28 — Integrated Manuscript Core

**Stage:** 11

**Source commit:** `62f09e3105296d62c39e8d95cf8b8775e63f2677`

**Status:** Working manuscript, not submission-ready.

This file combines two independently audited parts:

1. Experimental Setup and Reproducibility v1.
2. Results and Discussion v2.

The original texts are retained without scientific
rewriting. Final publication numbering, literature
citations, Introduction and Conclusion remain pending.

---

# Experimental Setup and Reproducibility

*FineZip28 — Stage 11 evidence-grounded draft*

## 1. Source implementation

The experiments use the FineZip28 implementation
associated with repository:

https://github.com/ThaoTo2806/FineZip28.git

Frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

The archived Stage 10 FINAL evidence contains
the source files, compression configuration,
historical summaries, and reproducibility records
used by the analysis.

## 2. Neural compression model

The tested neural compression workflow uses GPT-2
with a frozen context-adaptive FineZip implementation.

For the historical Stage 9 ablation measurements,
the recorded execution configuration specifies:

- GPU: Tesla T4
- PyTorch: 2.10.0+cu128
- Model tensor dtype: torch.float32
- Matrix multiplication precision:
  highest
- Maximum model batch tokens:
  1024

These values are explicitly associated with
Stage9-Session01. They are not assumed to be
identical across all historical sessions.

## 3. Traditional compression baselines

The traditional baselines are gzip, BZip2, XZ,
and Zstandard.

The archived Stage 10 benchmark records specify:

- Python: 3.12.13
- zlib: 1.2.11
- zstandard: 0.25.0
- Session: Stage10-Session01

Traditional baseline encode/decode times were
measured in three repetitions per configuration
and summarized using median elapsed times.

## 4. Dataset configuration

The evaluation includes six 100 KB datasets:

- enwik8_new
- english
- python_code
- csv_data
- vietnamese
- mixed

The 1 MB experiment uses a separate enwik8 sample.

The two enwik8-related samples are not
prefix-identical. Scaling observations therefore
reflect both input-size and sample differences.

## 5. Stage 10 neural compression verification

The Stage 10 Fast-BC-DP-64 experiment produced
a 273,990-byte
compressed artifact.

The original sequence contained
286,273 GPT-2 tokens,
and the padded coding sequence contained
286,304 tokens.

Measured end-to-end encoding time:
117.3890 seconds.

Measured full decoding time:
1386.1740 seconds.

The decoder reconstructed the original
1,000,000-byte input exactly, with a matching
SHA-256 hash.

## 6. Timing provenance and comparability

Stage 9 FineZip measurements and Stage 6A FineZip
measurements were preserved from historical runs.

Stage 10 traditional baseline measurements
and the fresh Stage 10 Fast-BC-DP experiment
belong to Stage10-Session01.

Cross-session timing differences are descriptive,
not controlled speedup evidence.

Moreover, the neural compressor and traditional
codecs have distinct computational workloads.
Compression-size comparisons alone do not
establish superior end-to-end performance.

## 7. Reproducibility limitations

The frozen source revision, compressed artifacts,
input samples, verification results, and
SHA-256 manifests are retained.

Historical software versions must be reported
only when supported by session-specific evidence.
Unrecorded versions are not inferred from
the current notebook.

The evaluated FineZip configurations generally
have only one timing observation per configuration.
No formal variance estimate or statistical
significance is claimed for those timings.

Independent external LLM compressor baselines
have not been executed.

The archived records establish verification
of the stated experimental outputs; they do not
establish that all experiments have been freshly
rerun in Stage 11.

---

# Results and Discussion

*FineZip28 — Stage 11 evidence-grounded draft*

## 1. Experimental Coverage

The evaluation combines previously verified FineZip
experiments with traditional compression baselines.
Six 100 KB datasets were evaluated using 84 compression
configurations, and a 1 MB enwik8 sample was evaluated
using 14 configurations.

The traditional baselines comprise gzip, BZip2, XZ,
and Zstandard. Traditional-codec timings in Stage 10
were recorded over three repetitions per configuration,
whereas most FineZip timings represent single-run
historical observations.

All compressed-size comparisons use complete artifact
sizes, including the relevant file-format overhead.

The timing provenance differs across some experiments.
Consequently, cross-session timing differences are
reported descriptively rather than interpreted as
controlled speedup measurements.

### Experimental provenance and timing comparability

The 100 KB FineZip results were obtained from frozen
Stage 9 experiments. The nine historical 1 MB FineZip
configurations originate from Stage 6A. Traditional
codec measurements and the fresh 1 MB Fast-BC-DP
experiment originate from Stage 10.

The traditional baseline timing summaries use the
median of three repetitions per configuration.
Most historical FineZip configurations, as well as
the fresh Fast-BC-DP experiment, have only one
recorded timing observation per configuration.

Compression sizes can be compared directly for the
same input bytes because they describe complete
stored artifacts. In contrast, timing comparisons
across sessions are descriptive, and the different
computational requirements of neural and traditional
compression must be considered.

The frozen FineZip source commit is
`62f09e3105296d62c39e8d95cf8b8775e63f2677`.
The neural compressor uses the frozen GPT-2-based
coding implementation, with its Stage 9 model
and context-selection configuration. The specific
runtime setup and calibration records are preserved
in the experimental evidence rather than inferred
from compression ratios.

## 2. Compression Performance on 100 KB Datasets

BZip2 produced the smallest compressed file on
5 of the six evaluated 100 KB datasets.

The exception was the enwik8_new sample, where
BC-DP-Full at target context
128
produced a compressed artifact of
27,608 bytes.

This represented a
11.8040% compressed-size reduction
relative to BZip2 on that sample.

FineZip did not outperform BZip2 in compressed size
on the other five datasets.

These results suggest that the relative performance
of the tested FineZip configurations is dependent
on the input data distribution. The current evaluation
does not establish compression superiority across
all text or structured-data categories.

**Evidence:** Table 1 (100 KB compression comparison), derived from the verified 84-configuration Stage 10 table.

## 3. Compression Performance on the 1 MB Sample

On the 1 MB enwik8 sample, the smallest compressed
artifact was generated by Fixed-512:
213,691 bytes.

This was
24.0407% smaller than the
281,323-byte BZip2 artifact.

Fast-BC-DP-64 generated an artifact of
273,990 bytes,
corresponding to a
2.6066% reduction relative to BZip2.

Compared with Fixed-64, Fast-BC-DP-64 generated
a 0.8414% larger artifact.

The newly measured Stage 10 Fast-BC-DP-64
end-to-end encoding time was
117.3890 seconds,
and its measured full decoding time was
1386.1740 seconds.

The decoder reconstructed all
286,273 original tokens and all
1,000,000 original bytes exactly.
SHA-256 verification confirmed lossless reconstruction.

The observed decode time of Fast-BC-DP-64 was
16.6318% lower than the
historically recorded Fixed-64 decode time.
However, those timings originated from different
experimental sessions, so this difference must
not be interpreted as a controlled speedup.

**Evidence:** Table 2 (1 MB compression and timing) and Stage 10 fresh encode/decode verification records.

### Token padding and decoding provenance

The 1 MB input produced
286,273 original GPT-2 tokens.
The coding input contained
286,304 tokens after padding.
Consequently, the two token counts describe
different stages of the coding pipeline.

The Stage 10 full decoding experiment verified
reconstruction of the original token sequence and
the original 1,000,000 input bytes. The original
and decoded byte sequences had matching SHA-256.

The Fast-BC-DP decoding time of
1386.1740 seconds is a
fresh, measured full-decoding observation.
The Stage 7 cost model also supplied a predicted
decoding duration of
1530.3757 seconds.
The prediction is not substituted for the measured
duration.

Other prediction-only decoding fields in the
historical optimization records must not be
interpreted as fresh measured decoding times.

## 4. Ablation of Search and Context Selection

A matched ablation analysis was performed on the
60 Stage 9 configurations, comprising five FineZip
methods evaluated over six datasets and two target
contexts (64 and 128).

The methods were Fixed, BC-DP-Full,
BC-DP-ReducedSearch, BC-DP-ReducedLevels,
and Fast-BC-DP.

Relative to BC-DP-Full, Fast-BC-DP had a median
observed encode-time reduction of
36.4528% across the 12 matched
dataset-context cases.

Fast-BC-DP exhibited a lower recorded encode
time in all 12 cases, with reductions ranging from
35.6272% to
38.8589%.

However, its compression-size advantage was mixed:
three cases produced smaller artifacts, one case
produced an equal-sized artifact, and eight cases
produced larger artifacts.

The median compressed-size saving relative to
BC-DP-Full was -0.1921%, indicating
a slight median size penalty.

Fast-BC-DP used 128 candidate proposals compared
with 488 for BC-DP-Full in the tested configurations.
This represents a reduction in the proposal count,
not an equivalent reduction in GPU runtime.

Although Fast-BC-DP was consistently faster than
BC-DP-Full in these observations, Fixed had the
lowest recorded encoding time in all 12 matched
cases. Fast-BC-DP should therefore not be described
as the fastest FineZip method overall.

**Evidence:** Table 3 (paired ablation), Table 4 (method summary), and Figures 5–7 (ablation).

## 5. Robustness Across Datasets and Contexts

At both target contexts, Fast-BC-DP had a lower
recorded encode time than BC-DP-Full for every
evaluated dataset.

The encode-time advantage was retained across all
six leave-one-dataset-out sensitivity analyses.

The size effects differed by target context.
At context 64, Fast-BC-DP did not produce a
smaller artifact in any of the six datasets.
At context 128, it produced smaller artifacts
in three of the six datasets.

These observations indicate that the measured
encoding advantage was consistent across the
tested data and context conditions, while the
compression-size effect varied.

The two context results from the same dataset
should not be treated as independent dataset
replicates. Furthermore, the measurements were
not repeated sufficiently to support formal
statistical significance claims.

The leave-one-dataset-out results are therefore
interpreted as descriptive sensitivity checks,
not hypothesis tests.

**Evidence:** Tables 7–9 (dataset-level, leave-one-dataset-out, and context-specific robustness).

### Interpretation of paired ablation observations

The twelve ablation cases correspond to six datasets
evaluated at two target contexts. They are matched
algorithm comparisons, not twelve independent
dataset replicates.

The reported median is a descriptive summary over
these twelve cases. Differences in these historical
single-run measurements are not confidence intervals,
and their signs alone do not establish statistical
significance.

In particular, Fast-BC-DP exhibits a consistent
observed encode-time advantage over BC-DP-Full,
but its compressed-size advantage is not consistent.
The method is not the globally fastest FineZip
configuration in the evaluated ablation set.

## 6. Descriptive Input-Size Scaling

Fast-BC-DP encoding was also observed on
100 KB and 1 MB enwik8-related samples.

The input size increased by a factor of ten.
The observed end-to-end encoding times were
11.9332
and
117.3890
seconds, respectively.

These two samples were not prefix-identical and
contained different token distributions.
The measurements comprise only one fresh
encoding run per sample size.

Accordingly, the resulting scaling factors
are descriptive and cannot establish
asymptotic time complexity.

**Evidence:** Stage 10 Figure 4 and its verified input-size scaling CSV.

## 7. Practical Trade-offs

The experiments reveal a fundamental trade-off
between compressed size and computational cost.

On the tested enwik8 samples, selected FineZip
configurations generated smaller artifacts than
BZip2. However, decoding the 1 MB Fast-BC-DP
artifact required approximately
1386.17 seconds,
while the traditional codecs decoded the same
sample on a substantially shorter time scale.

Thus, the observed compressed-size improvements
do not imply better end-to-end efficiency.

The practical suitability of GPT-2-based
compression depends on the relative importance
of storage efficiency, encoding cost, decoding
latency, model availability, and hardware resources.

## 8. Limitations

Several limitations constrain the conclusions.

First, most FineZip encoding and decoding timings
are single-run observations. The traditional
baselines provide repeated timings, but these
do not eliminate differences in computational
workflows.

Second, some comparisons combine historical
Stage 6A or Stage 9 results with measurements
from Stage 10. Cross-session timing comparisons
are descriptive only.

Third, the evaluation covers six 100 KB datasets
and one 1 MB sample. The reported effects cannot
be generalized to untested distributions.

Fourth, the two input sizes used for the scaling
analysis correspond to different samples.
Consequently, no asymptotic complexity claim
is supported.

Fifth, independent external LLM-based compressor
baselines were not executed in this experiment.
The results should not be interpreted as
superiority over other LLM compression systems.

Finally, the substantial decoding cost of the
tested GPT-2-based configuration remains a major
practical limitation.

### Reproducibility and outstanding reference review

The source-code revision, result tables, compressed
artifacts, byte-exact decoding records, and integrity
manifests are retained in the Stage 10 FINAL evidence
and artifact datasets.

The Stage 9 historical experiments and the Stage 10
fresh experiments must retain their separate timing
provenance. No unmeasured performance values are
introduced into this manuscript.

External literature citations, a comparison with
independently evaluated neural compression methods,
and journal-specific formatting remain outstanding.
These activities are necessary before the manuscript
can be regarded as submission-ready.

## 9. Discussion Summary

The results demonstrate that the evaluated
FineZip configurations can improve compressed
size on selected enwik8 samples, but they do
not consistently outperform traditional
compressors across the tested datasets.

The ablation experiments show that restricting
the BC-DP search process can improve observed
encoding efficiency while introducing a small
median compression-size penalty.

Together, these findings support a qualified
compression-versus-computation trade-off,
rather than a universal compression-performance
advantage.

This text is a draft derived from existing
experimental evidence and requires further
editorial and reference verification before
journal submission.
