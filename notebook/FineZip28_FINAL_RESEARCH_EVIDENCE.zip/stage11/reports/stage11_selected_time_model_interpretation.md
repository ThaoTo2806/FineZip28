# FineZip28 — Selected Time-Model Audit

## Source

Frozen Stage 9 historical run records.

Total configurations: 60.

Fixed configurations without BC-DP search
selection: 12.

BC-DP configurations: 48.

## Run-level selection evidence

Successfully confirmed selection records:
48/48.

Records requiring review:
0.

The selected model names originate directly
from each run's serialized `selection` field.

Where confirmed, the selected layout SHA-256
was checked against the artifact layout SHA-256.

The source serializer explicitly records
the objective and time-model names.

## Scientific interpretation

A selected time model identifies the
decode-cost model associated with the
chosen BC-DP layout-search candidate.

It does not necessarily mean that the final
artifact was decoded using that time model.

The actual decoder performs token
reconstruction using the language model,
stored ranks and escape information.

Historical predicted decode durations
remain distinct from measured full-decode
durations.

## Remaining limitations

This audit does not rerun model inference.

Selection records that cannot be reconciled
with the archived layout hash remain
marked REVIEW.

No statistical performance claim is inferred
from the frequency of selected cost models.
