# FineZip28 — Run-Level Decode-Cost Audit

## Scope

This report inspects frozen historical source
and run summaries. It does not execute
compression, decoding or model inference.

## Distinctions

Three distinct claims must not be confused:

1. A decode-cost model was defined in code.
2. A decode-cost model was included in
   candidate layout searches.
3. A particular decode-cost model generated
   the selected final artifact.

Evidence for (1) and (2) does not
automatically establish (3).

## Source records

The source-reference table identifies code
locations mentioning time models, selection
and predicted decoding cost.

The historical schema table inventories
available columns across Stages 6A–9.

The Stage 9 run table preserves the
unmodified `selection` field for all 60
configurations.

## Scientific boundary

No run has been automatically assigned a
confirmed decoder-cost model solely from a
non-null `selection` field.

Run-level assignment requires checking
the exact serialization convention used
by `search_stage9` and `encode_stage9`.

Predicted decode cost must remain separate
from measured full-decoding time.

## Next review

Interpret the printed search logic and
selection examples before finalizing the
run-level decoder-cost model description.
