# Frozen FineZip28 Methodology Source Excerpts

### evaluate_stage9_layout

Source: `code/stage9_helper_functions.py`, lines 1–67

```python
0001: def evaluate_stage9_layout(leaves, analysis, n_pad):
0002: 
0003:     cursor = 0
0004:     rank_parts = []
0005: 
0006:     counts = {
0007:         int(L): 0 for L in LEVELS
0008:     }
0009: 
0010:     for start, L in leaves:
0011: 
0012:         assert start == cursor
0013:         assert start + L <= n_pad
0014:         assert L in analysis
0015: 
0016:         rank_parts.append(
0017:             analysis[L]["ranks"][start // L]
0018:         )
0019: 
0020:         counts[L] += 1
0021:         cursor += L
0022: 
0023:     assert cursor == n_pad
0024: 
0025:     ranks = np.concatenate(
0026:         rank_parts
0027:     ).astype("<u2")
0028: 
0029:     payload_bytes = len(
0030:         bz2.compress(
0031:             ranks.tobytes(),
0032:             compresslevel=9
0033:         )
0034:     )
0035: 
```

### search_stage9

Source: `code/stage9_helper_functions.py`, lines 73–133

```python
0073: def search_stage9(
0074:     toks_pad,
0075:     analysis,
0076:     lambda_grid
0077: ):
0078: 
0079:     t0 = time.perf_counter()
0080: 
0081:     objectives = build_stage9_objectives(
0082:         analysis
0083:     )
0084: 
0085:     search_rows = []
0086:     evaluated = {}
0087:     layouts = {}
0088: 
0089:     for objective_name, cost in objectives.items():
0090: 
0091:         for time_name, time_fn in time_models.items():
0092: 
0093:             for lam in lambda_grid:
0094: 
0095:                 policy = s5.TreeDP(
0096:                     cost=cost,
0097:                     lam=float(lam),
0098:                     t_chunk=time_fn
0099:                 )
0100: 
0101:                 leaves = policy(toks_pad)
0102: 
0103:                 key = hashlib.sha256(
0104:                     np.asarray(
0105:                         leaves,
0106:                         dtype=np.int64
0107:                     ).tobytes()
```

### build_stage9_objectives

Source: `code/stage9_objective_function.py`, lines 1–27

```python
0001: def build_stage9_objectives(analysis):
0002: 
0003:     cost_nll = s5.cost_ac(analysis)
0004: 
0005:     cost_rank = {}
0006: 
0007:     for L, values in analysis.items():
0008: 
0009:         ranks = values["ranks"]
0010: 
0011:         tail = np.where(
0012:             ranks >= RMAX,
0013:             np.log2(np.maximum(ranks, 1)),
0014:             0.0
0015:         )
0016: 
0017:         cost_rank[L] = (
0018:             rank_table[
0019:                 np.minimum(ranks, RMAX)
0020:             ].sum(axis=1)
0021:             + tail.sum(axis=1)
0022:         )
0023: 
0024:     return {
0025:         "NLL": cost_nll,
0026:         "Rank": cost_rank
0027:     }
0028: 
0029: 
0030: # ==================== ABLATION SEARCH ====================
```

### pad_tokens

Source: `provenance/adaptive_context_finezip_v3.py`, lines 212–215

```python
0212: def pad_tokens(tokens, bos):
0213:     n = len(tokens)
0214:     n_pad = -(-n // MIN_L) * MIN_L
0215:     return np.concatenate([np.asarray(tokens), np.full(n_pad - n, bos, dtype=np.asarray(tokens).dtype)])
0216: 
0217: 
0218: def make_batch(toks, starts, L, bos):
0219:     tgt = np.stack([toks[s:s + L] for s in starts])
0220:     inp = np.concatenate([np.full((len(starts), 1), bos, dtype=tgt.dtype), tgt[:, :-1]], axis=1)
0221:     return inp, tgt
0222: 
0223: 
0224: def run_score(toks, starts, L, lm, batch, eff=None):
0225:     """-> bits[N], ranks[N,L], unstable[N,L] cho các chunk (start, L).
0226:     eff = batch hiệu dụng ÉP DÙNG (kế hoạch batch lưu trong file). None -> suy ra từ lm.batch_size."""
0227:     bits, ranks, uns = [], [], []
0228:     if eff is None:
0229:         eff = lm.batch_size(L, batch) if hasattr(lm, "batch_size") else batch
0230:     for i in range(0, len(starts), eff):
0231:         inp, tgt = make_batch(toks, starts[i:i + eff], L, lm.bos)
0232:         b, r, u = lm.score(inp, tgt)
0233:         bits.append(b.sum(1)); ranks.append(r); uns.append(u)
0234:     return np.concatenate(bits), np.concatenate(ranks), np.concatenate(uns)
0235: 
0236: 
0237: # ----------------------------------------------------------------------------
0238: # 4. Layout = danh sách lá (start, L) + (de)serialize bằng cờ tách đôi (preorder)
0239: # ----------------------------------------------------------------------------
0240: def walk(n_pad, decide):
0241:     """Duyệt cây. decide(s, L) -> True nếu nút (s,L) là LÁ. Trả danh sách lá."""
0242:     leaves = []
0243: 
0244:     def rec(s, L):
0245:         if s >= n_pad:
0246:             return
```

### encode

Source: `provenance/adaptive_context_finezip_v3.py`, lines 438–472

```python
0438: def encode(tokens, lm, policy, batch=8):
0439:     toks = pad_tokens(tokens, lm.bos)
0440:     leaves = policy(toks, lm, batch)
0441:     plan = {L: int(lm.batch_size(L, batch)) if hasattr(lm, "batch_size") else int(batch) for L in CTX_SIZES}
0442:     rank_of, esc_pos, esc_tok = {}, [], []
0443:     for L in sorted({l for _, l in leaves}):
0444:         starts = [s for s, l in leaves if l == L]
0445:         _, r, u = run_score(toks, starts, L, lm, batch, eff=plan[L])      # ép dùng đúng kế hoạch đã ghi
0446:         for i, s in enumerate(starts):
0447:             ri = r[i].copy()
0448:             ri[u[i]] = 0                                   # vị trí escape: rank không dùng -> 0 cho dễ nén
0449:             rank_of[s] = ri
0450:             idx = np.nonzero(u[i])[0]
0451:             esc_pos += (s + idx).tolist(); esc_tok += toks[s + idx].tolist()
0452:     order = np.argsort(esc_pos, kind="stable") if esc_pos else np.empty(0, int)
0453:     esc_pos = np.asarray(esc_pos, np.int64)[order]; esc_tok = np.asarray(esc_tok, np.int64)[order]
0454:     rank_width = 2 if lm.V <= np.iinfo(np.uint16).max + 1 else 4
0455:     rank_dtype = "<u2" if rank_width == 2 else "<u4"
0456:     ranks = (np.concatenate([rank_of[s] for s, _ in leaves]).astype(rank_dtype)
0457:              if leaves else np.empty(0, dtype=rank_dtype))
0458:     flags = layout_to_flags(leaves, len(toks))
0459:     delta = np.diff(esc_pos, prepend=0).astype("<u4")
0460:     esc_blob = bz2.compress(delta.tobytes() + esc_tok.astype(rank_dtype).tobytes(), 9) if len(esc_pos) else b""
0461:     rk_blob = bz2.compress(ranks.tobytes(), 9)
0462:     fp, _, env = _fingerprint(lm)
0463:     eps = float(getattr(lm, "eps", None) or 0.0)
0464:     envb = env.encode("utf-8")
0465:     head = struct.pack(_HDR, FILE_MAGIC, FILE_VERSION, rank_width, 0, len(tokens), len(flags), len(esc_pos),
0466:                        fp, eps, *[plan[L] for L in CTX_SIZES])
0467:     head += struct.pack("<H", len(envb)) + envb
0468:     head += np.packbits(np.array(flags, np.uint8)).tobytes() + struct.pack("<I", len(rk_blob))
0469:     encode.last_stats = {"escapes": int(len(esc_pos)), "escape_pct": 100.0 * len(esc_pos) / max(1, len(toks)),
0470:                          "esc_bytes": len(esc_blob), "total_bytes": len(head) + len(rk_blob) + len(esc_blob),
0471:                          "header_bytes": len(head), "batch_plan": plan, "eps": eps}
0472:     return head + rk_blob + esc_blob, leaves
```

### decode

Source: `provenance/adaptive_context_finezip_v3.py`, lines 540–548

```python
0540: def decode(blob, lm, batch=None):
0541:     """Giải nén. `batch` được GIỮ để tương thích nhưng BỊ BỎ QUA: kế hoạch batch lấy từ header."""
0542:     n, n_pad, leaves, rk, esc, plan = _parse(blob, lm)
0543:     out = np.zeros(n_pad, np.int64)
0544:     for L, ss in _groups(leaves, plan):
0545:         dec = _decode_group(ss, L, rk, esc, lm)
0546:         for j, s in enumerate(ss):
0547:             out[s:s + L] = dec[j]
0548:     return out[:n]
0549: 
0550: 
0551: def quick_check(blob, lm, tokens, batch=None, groups_per_L=1):
0552:     """Giải nén THỬ vài nhóm batch đầu của mỗi mức L và so với token gốc (dùng đúng kế hoạch batch trong file).
0553:     Chạy TRƯỚC decode đầy đủ (hàng giờ). `batch` bị bỏ qua như ở decode()."""
0554:     tokens = np.asarray(tokens)
0555:     n, n_pad, leaves, rk, esc, plan = _parse(blob, lm)
0556:     seen, bad = {}, []
0557:     for L, ss in _groups(leaves, plan):
0558:         if seen.get(L, 0) >= groups_per_L:
0559:             continue
0560:         seen[L] = seen.get(L, 0) + 1
0561:         dec = _decode_group(ss, L, rk, esc, lm)
0562:         for j, s in enumerate(ss):
0563:             e = min(s + L, n)
0564:             if e > s and not np.array_equal(dec[j][:e - s], tokens[s:e]):
0565:                 bad.append((s, L))
0566:     print("quick_check:", "OK" if not bad else f"LỆCH ở {bad}")
0567:     return not bad
0568: 
0569: 
0570: def inspect_blob(blob):
0571:     """Đọc header + layout, không cần mô hình."""
0572:     h = _read_header(blob)
0573:     n_pad = -(-h["n"] // MIN_L) * MIN_L
0574:     nb = (h["nf"] + 7) // 8
```
