# FineZip28 — Stage 11 Ablation Analysis

## Experimental design

- Source: frozen Stage 9 FINAL evidence.
- Six 100 KB datasets.
- Two target contexts: 64 and 128.
- Five FineZip methods.
- Twelve paired dataset-context cases.
- Sixty encoded configurations.
- All artifact lossless claims originate from Stage 9 historical verification.

## Method-level ablation summary

| Method | Median size saving vs Full | Median encode reduction vs Full | Smaller cases | Faster encode cases |
|---|---:|---:|---:|---:|
| Fixed | -0.031% | +84.720% | 4/12 | 12/12 |
| BC-DP-Full | +0.000% | +0.000% | 0/12 | 0/12 |
| BC-DP-ReducedSearch | -0.784% | +5.142% | 0/12 | 12/12 |
| BC-DP-ReducedLevels | +0.000% | +31.799% | 3/12 | 12/12 |
| Fast-BC-DP | -0.192% | +36.453% | 3/12 | 12/12 |

## Interpretation guidance

- Size saving is positive when the method generates a smaller artifact than BC-DP-Full.
- Encode reduction is positive when the method's historically recorded encode time is shorter.
- Paired cases use the same dataset and target context.
- Encode measurements are historical single-run values; do not claim statistical significance.
- Search configurations and unique layouts are algorithm-level workload indicators, not GPU time.
- Predicted decode seconds are model-based estimates and are not treated as measured decode time.
- These ablations do not establish general behavior on datasets outside the six tested samples.

## Source provenance

FineZip28 pinned commit: `62f09e3105296d62c39e8d95cf8b8775e63f2677`.

