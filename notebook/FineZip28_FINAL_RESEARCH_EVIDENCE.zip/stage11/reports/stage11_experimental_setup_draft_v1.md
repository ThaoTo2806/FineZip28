# Experimental Setup and Reproducibility

*FineZip28 — Stage 11 evidence-grounded draft*

## 1. Source implementation

The experiments use the FineZip28 implementation
associated with repository:

https://github.com/ThaoTo2806/FineZip28.git

Frozen source revision:

`62f09e3105296d62c39e8d95cf8b8775e63f2677`

The archived Stage 10 FINAL evidence contains
the source files, compression configuration,
historical summaries, and reproducibility records
used by the analysis.

## 2. Neural compression model

The tested neural compression workflow uses GPT-2
with a frozen context-adaptive FineZip implementation.

For the historical Stage 9 ablation measurements,
the recorded execution configuration specifies:

- GPU: Tesla T4
- PyTorch: 2.10.0+cu128
- Model tensor dtype: torch.float32
- Matrix multiplication precision:
  highest
- Maximum model batch tokens:
  1024

These values are explicitly associated with
Stage9-Session01. They are not assumed to be
identical across all historical sessions.

## 3. Traditional compression baselines

The traditional baselines are gzip, BZip2, XZ,
and Zstandard.

The archived Stage 10 benchmark records specify:

- Python: 3.12.13
- zlib: 1.2.11
- zstandard: 0.25.0
- Session: Stage10-Session01

Traditional baseline encode/decode times were
measured in three repetitions per configuration
and summarized using median elapsed times.

## 4. Dataset configuration

The evaluation includes six 100 KB datasets:

- enwik8_new
- english
- python_code
- csv_data
- vietnamese
- mixed

The 1 MB experiment uses a separate enwik8 sample.

The two enwik8-related samples are not
prefix-identical. Scaling observations therefore
reflect both input-size and sample differences.

## 5. Stage 10 neural compression verification

The Stage 10 Fast-BC-DP-64 experiment produced
a 273,990-byte
compressed artifact.

The original sequence contained
286,273 GPT-2 tokens,
and the padded coding sequence contained
286,304 tokens.

Measured end-to-end encoding time:
117.3890 seconds.

Measured full decoding time:
1386.1740 seconds.

The decoder reconstructed the original
1,000,000-byte input exactly, with a matching
SHA-256 hash.

## 6. Timing provenance and comparability

Stage 9 FineZip measurements and Stage 6A FineZip
measurements were preserved from historical runs.

Stage 10 traditional baseline measurements
and the fresh Stage 10 Fast-BC-DP experiment
belong to Stage10-Session01.

Cross-session timing differences are descriptive,
not controlled speedup evidence.

Moreover, the neural compressor and traditional
codecs have distinct computational workloads.
Compression-size comparisons alone do not
establish superior end-to-end performance.

## 7. Reproducibility limitations

The frozen source revision, compressed artifacts,
input samples, verification results, and
SHA-256 manifests are retained.

Historical software versions must be reported
only when supported by session-specific evidence.
Unrecorded versions are not inferred from
the current notebook.

The evaluated FineZip configurations generally
have only one timing observation per configuration.
No formal variance estimate or statistical
significance is claimed for those timings.

Independent external LLM compressor baselines
have not been executed.

The archived records establish verification
of the stated experimental outputs; they do not
establish that all experiments have been freshly
rerun in Stage 11.
