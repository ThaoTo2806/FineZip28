FineZip28 — Final Research Evidence Package

Source commit:
62f09e3105296d62c39e8d95cf8b8775e63f2677

Contents:

1. stage10-final-evidence/
   Frozen Stage 10 experimental evidence,
   code, provenance, reference material,
   figures and original SHA-256 manifest.

2. stage10-final-artifacts/
   Frozen Stage 10 artifacts.

3. stage11/
   Stage 11 experiment-analysis outputs,
   audit records, CSV tables, figures,
   and historical manuscript working drafts.

4. EXPORT_MANIFEST.json
   SHA-256 and byte length of each source file.

Scientific status:

- Archived experimental evidence verified.
- Stage 11 manuscript-core automated checks passed.
- Manuscript is NOT submission-ready.
- Related Work, References and editorial review
  remain outside the Kaggle experiment workflow.

Do not interpret this ZIP as a new experiment.
No GPU inference was executed during export.
